TVAppConfig = {
  // So we try to do a
  speedTestUrl: null,
}

/******************************************************************
 UI Configuration
 *******************************************************************/

Gaiam = {
  utils: {
    LoadingOverlay: {
      on: function() {
        $("#loadingSpinner").show();
      },
      off: function() {
        $("#loadingSpinner").fadeOut();
      },
    },


    stripslashes: function(str) {
      return (str + '').replace(/\\(.?)/g, function(s, n1) {
        switch (n1) {
          case '\\':
            return '\\';
          case '0':
            return '\0';
          case '':
            return '';
          default:
            return n1;
        }
      });
    },

    keydump: function(obj) {
      for (key in obj) {
        log("Got KEY: " + key);
      }
    },
    normalizeSpace: function(text) {
      text = text || "";
      text = text.replace(/[\t\f]/g, ' ');
      text = text.replace(/\r\n/g, "\n");
      text = text.replace(/\r/g, "\n");
      text = text.replace(/\n[\\s\n]*\n/g, "\n\n");
      text = text.replace("/^[\n\r\s]*/", "");
      text = text.replace(/\\n/g, "\n");
      return text.trim();
    },

    stripNewLines: function(text) {
      text = text || "";
      text = this.stripNonAscii(text);
      text = this.normalizeSpace(text);
      return text.replace(/\n/ig, "").replace("\t", "").replace(/\s+/ig, " ")
    },

    showErrorDialog: function(title, msg) {
      var d = new KONtx.dialogs.Alert({
        title: title,
        message: msg,
        buttons: [{
          label: "Ok",
          callback: arguments[2]
        }]
      });
      d.show();
    }
  }
}


window.Category = Backbone.Model.extend({

});
window.Categories = Backbone.Collection.extend({
  model: Category,
});

window.CategoriesSelectionView = Backbone.View.extend({
  render: function() {
    var template = Handlebars.compile($("#mainCatSelectionView").html());
    this.$el.empty();
    this.$el.html(template({
      terms: this.collection.map(function(m) {
        return m.attributes
      })
    }))
    var catMenu = TVEngine.Navigation.getMenu("gaiam:catselection");
    catMenu.reset(this.el);
  }
});

window.Video = Backbone.Model.extend({
  initialize: function() {
    // Dirty but consistent rating and year.
    // umm, we're not actually getting real data, i've requested that gaiam return this data with their API call to api/videos/term

    // $log('this.attributes:', this.attributes)

  }
});

window.VideoCategory = Backbone.Collection.extend({
  model: Video,
  comparator: function(item) {
    return item.get('title');
  }
})

window.VideoGridView = Backbone.View.extend({
  el: "#vidSelectionWrapper",
  initialize: function() {
    this.collection.on('reset', this.render, this);
  },
  render: function() {
    $(this.el).empty();
    $log(" RENDERING VIDEO GRID VIEW ", this)
    var pages = Math.ceil(this.collection.models.length / 14);
    var template = Handlebars.compile($("#categoryVideosPage").html());

    for (var i = 0; i < pages; i++) {
      var page = this.collection.models.slice(i * 14, i * 14 + 14);
      _(page).each(function(m) {
        m.set('page', i)
      });
      $(this.el).append(template({
        videos: _(page).map(function(m) {
          return m.attributes
        }),
        klass: (i == 0) ? 'on' : (i == 1) ? 'right blurred' : 'right off',
        page: i,
      }))
    }
    var gridMenu = TVEngine.Navigation.getMenu("gaiam:videogrid");
    gridMenu.reset();
  }
})

window.featuredVideosView = Backbone.View.extend({
  el: "#featured",
  render: function() {
    var template = Handlebars.compile($("#featuredTemplate").html());
    this.$el.empty();
    this.$el.html(template({
      titles: this.collection.map(function(m) {
        return m.attributes
      }),
    }));
  }
})


window.PlaylistVideosView = Backbone.View.extend({
  el: "#playlistVideos",
  render: function() {
    var template = Handlebars.compile($("#playlistVideosTemplate").html());
    this.$el.empty();
    this.$el.html(template({
      titles: this.collection.map(function(m) {
        return m.attributes
      }),
    }));
  }
});

window.seriesVideosView = Backbone.View.extend({
  el: "#seriesVideos",
  render: function() {
    var template = Handlebars.compile($("#seriesTemplate").html());
    this.$el.empty();
    this.$el.html(template({
      titles: this.collection.map(function(m) {
        return m.attributes
      }),
    }));
  }
})

window.moreVideosView = Backbone.View.extend({
  el: "#moreVideosHolder",
  render: function() {
    var template = Handlebars.compile($("#moreVideosHolderTemplate").html());
    this.$el.empty();
    this.$el.html(template({
      titles: this.collection.map(function(m) {
        return m.attributes
      }),
    }));
  }
});


window.recentVideosView = Backbone.View.extend({
  el: "#recentVideos",
  render: function() {
    var template = Handlebars.compile($("#recentTemplate").html());
    this.$el.empty();
    this.$el.html(template({
      titles: this.collection.map(function(m) {
        return m.attributes
      }),
    }));
  }
})



Handlebars.registerHelper("getTrueOrFalseForLeaf", function() {
  return (this.isLeaf) ? "true" : "false";
})
Handlebars.registerHelper("imageIfVisible", function() {
  //  $log(" IMAGE IF VISIBLE ", this);
  if (this.page <= 1) return this.coverart_image.roku_158x204;
  else return "images/trans.png";
})
Handlebars.registerHelper("firstCatItemImage", function() {
  $log("FIRST CAT ITEM", this);
  if (this.terms && this.terms.length) {
    return this.terms[0].term_image.roku_306x214;
  }
});

Handlebars.registerHelper("getColspan", function() {
  if (this == 'DEL' || this == 'SPC') {
    return " colspan='2'";
  }
});
Handlebars.registerHelper("debug", function(optionalValue) {
  console.log("Current Context");
  console.log("====================");
  console.log(this);
  if (optionalValue) {
    console.log("Value");
    console.log("====================");
    console.log(optionalValue);
  }
});
var networkIsDisconnected = false;
var platform = TVEngine.getPlatform();
TVEngine.bind("tvengine:appready", function() {

  _.extend(platform, Backbone.Events);
  $log('platform is: ', platform)
  platform.bind("network:disconnected", function() {
    networkIsDisconnected = true;
  //  ErrorModal.show();
  Gaiam.errorModalHandler.trigger('show','Unable to connect to network at this time.')
  });

  platform.bind("network:connected", function() {
    if (networkIsDisconnected == true) {
  Gaiam.errorModalHandler.trigger('hide')
    //  ErrorModal.hide();
      networkIsDisconnected = false;


    }

  });

  var errorOldMenu;
  var tmpErrorMenu;
  ErrorModal = {
    show: function(title, description, callback) {

      $("#errorModal").show();

    },

    hide: function() {
      $("#errorModal").hide();
      $log('errorOldMenu is: ', errorOldMenu);


    }
  }


  //loader functions
  showLoader = function() {

    $('#loadLogo').show();
    $('#loader').show();
  };
  hideLoader = function() {


    $('#loadLogo').hide();
    $('#loader').hide()
  };

  //some hover zones for LG

 oldLeft=null;

  LGHoverRightHandlerIn = function() {

    LGHoverRightInterval = setInterval(function() {


      //$log('hover right!')

      if ((TVEngine.Navigation.currentMenu.name == 'gaiam:featured') || (TVEngine.Navigation.currentMenu.name == 'gaiam:preauthMainMenu') || (TVEngine.Navigation.currentMenu.name == 'gaiam:mainmenu')) {
        hoverMenuName = 'featured'
      } else if (TVEngine.Navigation.currentMenu.name == 'gaiam:recent') {
        //$log('gaiam recent hover right')
        hoverMenuName = 'recent'
      } else if (TVEngine.Navigation.currentMenu.name == 'gaiam:playlists') {
      //  $log('gaiam playlists hover right')
        hoverMenuName = 'myPlaylist'
      }

      if(typeof window.oldLeft!=='undefined'){
        oldLeft = $('#' + hoverMenuName + ' ').css('left');
      oldLeft.replace(/[^-\d\.]/g, '');
      oldLeft = parseInt(oldLeft);
      oldLeft = oldLeft - 3;
     // $log('oldLeft is:'+oldLeft)
      newLeft = oldLeft;
      howWide = $('#' + hoverMenuName + 'Wrapper div div').width()
      howLong = $('#' + hoverMenuName + 'Wrapper div div').length;
      howLong = howLong - 1;
      limiter = howLong * howWide;
      //$log('limiter value is:' + limiter)
      if (-limiter < oldLeft) {

        $('#' + hoverMenuName + ' ').css({
          'left': newLeft
        })
      } else {
        //      $log('HIT LIMITER')
        $('#' + hoverMenuName + ' ').css({
          'left': -limiter
        })
        return
      }

      $('#' + hoverMenuName + ' ').css({
        'left': newLeft
      })
      }
      



    }, 10)
    return false;
  };

  LGHoverRightHandlerOut = function() {
    clearInterval(LGHoverRightInterval);

    return false;
  };


  LGHoverLeftHandlerIn = function() {


 LGHoverLeftInterval = setInterval(function() {
    //$log('hover left!')
      if ((TVEngine.Navigation.currentMenu.name == 'gaiam:featured') || (TVEngine.Navigation.currentMenu.name == 'gaiam:preauthMainMenu') || (TVEngine.Navigation.currentMenu.name == 'gaiam:mainmenu')) {
        hoverMenuName = 'featured'
      } else if (TVEngine.Navigation.currentMenu.name == 'gaiam:recent') {
        //  $log('gaiam recent hover left')
        hoverMenuName = 'recent'
      } else if (TVEngine.Navigation.currentMenu.name == 'gaiam:playlists') {
        //   $log('gaiam playlists hover left')
        hoverMenuName = 'myPlaylist'
      }
      //$log('hover left!')
if(typeof window.oldLeft!=='undefined'){
   oldLeft = $('#' + hoverMenuName + ' ').css('left');
      oldLeft.replace(/[^-\d\.]/g, '');
      oldLeft = parseInt(oldLeft);
      oldLeft = oldLeft + 3;
      //$log('oldLeft is:'+oldLeft)
      newLeft = oldLeft;
      howWide = $('#' + hoverMenuName + 'Wrapper div div').width()
      howLong = $('#' + hoverMenuName + 'Wrapper div div').length;
      howLong = howLong - 2;
      limiter = 950;
      //$log('limiter value is:' + limiter)
      if (limiter >= oldLeft) {

        $('#' + hoverMenuName + ' ').css({
          'left': newLeft
        })
      } else {
        $log('HIT LIMITER')
        $('#' + hoverMenuName + ' ').css({
          'left': limiter
        })
        return
      }

      $('#' + hoverMenuName + ' ').css({
        'left': newLeft
      })

}
     


    }, 10)
    return false;
  };

  LGHoverLeftHandlerOut = function() {
    clearInterval(LGHoverLeftInterval);

    return false;
  };

  LGHoverBottomHandlerIn = function() {

    LGHoverBottomInterval = setInterval(function() {

      //$log('bottom hover')

    }, 10)
    return false;
  };

  LGHoverBottomHandlerOut = function() {
    clearInterval(LGHoverBottomInterval);

    return false;
  };

  LGHoverTopHandlerIn = function() {

    LGHoverTopInterval = setInterval(function() {

      //$log('top hover')

    }, 10)
    return false;
  };

  LGHoverTopHandlerOut = function() {
    clearInterval(LGHoverTopInterval);

    return false;
  };
  //loader bindings for between scenes -- too fast for now we might need this later

  // TVEngine.StageManager.on('beforescenechange', function() {
  //   $log('beforescenechange loader')
  //   showLoader();

  // }, this)

  // TVEngine.StageManager.on('afterscenechange', function() {
  //   $log('afterscenechange loader')
  //   hideLoader();

  // }, this)

 disableDragging = function() {

       $(document).bind("dragover", function(e) {
            e.preventDefault();
            return false;
       });

       $(document).bind("drop", function(e){
            e.preventDefault();
            return false;
        });

    };
    disableDragging();
    $log('jquery version: '+$().jquery);



Gaiam.errorModalHandler={};
  _.extend(Gaiam.errorModalHandler, Backbone.Events);
Gaiam.errorModalHandler.on('show',function(modalText,callback){

   $log('show the error modal');
   $log('modalText',modalText);
   $('#errorModal').show();
   $('#errorModalInner').text(modalText);
      hideLoader();
 // oldMenu = TVEngine.Navigation.currentMenu;
  dummyMenu = TVEngine.Navigation.menus['ade:dummymenu'];
  dummyMenu.focus();
  dummyMenu.on('onselect',function(){Gaiam.errorModalHandler.trigger('hide')},this)
   // TVEngine.Navigation.setFocus("ade:dummymenu", null, {
   //        storeInHistory: false
   //      });
},this);
Gaiam.errorModalHandler.on('hide',function(){
  $log('hiding the error modal')
   $('#errorModal').hide();
  $('#loginWrapper').show();
    $('#keyboard').show();
    dummyMenu.off();
    TVEngine.Navigation.back();
},this);


//need flag for first entry into app after login
 mainFirstEntry = true;


//  idTokenExists = Gaiam.API._readCookie('idToken')
//  uid = Gaiam.API._readCookie('uid');
// $log('idExists: ',idTokenExists);
// $log('uid: ',uid);
// if(uid)
// {
//   Gaiam.API.md5login();
// }

//bind some keys


    var _to_ascii = {
      '188': '44',
      '109': '45',
      '190': '46',
      '191': '47',
      '192': '96',
      '220': '92',
      '222': '39',
      '221': '93',
      '219': '91',
      '173': '45',
      '187': '61', //IE Key codes
      '186': '59', //IE Key codes
      '189': '45' //IE Key codes
    }

    var shiftUps = {
      "96": "~",
      "49": "!",
      "50": "@",
      "51": "#",
      "52": "$",
      "53": "%",
      "54": "^",
      "55": "&",
      "56": "*",
      "57": "(",
      "48": ")",
      "45": "_",
      "61": "+",
      "91": "{",
      "93": "}",
      "92": "|",
      "59": ":",
      "39": "\"",
      "44": "<",
      "46": ">",
      "47": "?"
    };


    $(document).on('keypress', function(e) {

      if (TVEngine.StageManager.scene.name == "loginKeyboard") {
        $log('keypress val:' + String.fromCharCode(e.which));
        var value = String.fromCharCode(e.which);

        TVEngine.Navigation.menus['gaiam:loginKeyboardMenu'].addChar(value)
      }
  if (TVEngine.StageManager.scene.name == "search") {
      $log('keypress val:' + String.fromCharCode(e.which));
  var value = String.fromCharCode(e.which);
 
     if (verticalListMenu.firstKeyEntry == true) {
      $('#searchField').text("")
 
    verticalListMenu.firstKeyEntry = false;
   }
   if (verticalListMenu.firstKeyEntry == false) {
    $('#searchField').append(value);
   }


      }


    });


if(TVEngine.Platforms.platformName()=="lg"){

  $('#LGQuickMenu').css({'visibility':'visible'})
}
  //end appready calls
})