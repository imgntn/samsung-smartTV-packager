tmpMute = function() {
	TVEngine.MediaPlayer._videoElement.volume = 0
}

debugLogin = function(){

Gaiam.User.username="jpollack";
Gaiam.User.password="adeade";
TVEngine.StageManager.changeScene('loginKeyboard')
Gaiam.API.login();

}


Gaiam.User = {
	username: "default",
	password: "default",
	loginData: "",
	searchResults: "",
	loggedIn:false
};