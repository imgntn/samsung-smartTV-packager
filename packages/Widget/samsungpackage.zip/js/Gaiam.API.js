Gaiam.API = {
	_urls: {
		// James this is just a category with videos, we should sub this out
		// with a real call later.
		categoryUrl: function(id) {
			$log(" CATEGORY URL", arguments);
			var id = id || 1;
			return "http://www.gaiamtv.com/api/vocabulary/" + id;
		},
		subCategoryUrl: function(id) {
			return "http://www.gaiamtv.com/api/vocabulary/1/" + id;
		},
		mediaDetailsUrl: function(id) {
			return "http://www.gaiamtv.com/api/node/" + id;
		},
		videosForCategoryUrl: function(id) {
			return "http://www.gaiamtv.com/api/videos/term/" + id;
		},

		renditionsUrl: function(id) {
			if (TVEngine.Platforms.platformName()=="Samsung"||TVEngine.Platforms.platformName()=="Samsung2012"||TVEngine.Platforms.platformName()=="samsung")
			{$log('this is a samsung, use QA URL')
				return "http://www.gaiamtv-qa.gaiam.com/api/media/" + id;
			}
		else{
			$log('not  a samsung, use regular URL')
			return "http://www.gaiamtv.com/api/media/" + id;
		}
		},

		renditionsPreviewUrl: function(id) {
			return "http://www.gaiamtv.com/api/media/" + id;
		},

		userNodeUrl: function(id) {
			return "http://www.gaiamtv.com/api/user/node/" + id;
		},

		searchUrl: function(searchterm, page, perpage) {
			return "http://www.gaiamtv.com/api/videos/search/" + searchterm + '?p=' + page + '&pp=' + perpage;
		},

		logSearchUrl: function(searchterm) {
			return "http://www.gaiamtv.com/api/user/searched/" + searchterm;
		},

		seriesUrl: function(nid) {
			return "http://www.gaiamtv.com/api/videos/series/" + nid;
		},

		analyticsInitUrl: function(nid) {
			return "http://www.gaiamtv.com/api/analytics/st/add/" + nid;
		},

		analyticsUpdateUrl: function(nid, analyticsToken) {
			return "http://www.gaiamtv.com/api/analytics/st/upd/" + nid + "/" + analyticsToken;
		},

		addVideoToPlaylistUrl: function(nid) {
			return "http://www.gaiamtv.com/api/user/node/" + nid + "/playlist";
		},



		featured: "http://www.gaiamtv-qa.gaiam.com/api/videos/featured",
		//featured: "js/featuredStub.json",
		login: "http://www.gaiamtv.com/api/s/login",
		md5Login: "https://www.gaiamtv.com/api/s/md5login",
		renew: "https://www.gaiamtv.com/api/s/renew",
		myPlaylist: "http://www.gaiamtv.com/api/user/playlist",
		mySearches: "http://www.gaiamtv.com/api/user/searches",
		daytimeUrl: "http://www.gaiamtv.com/api/daytime",
		recentVideos: "http://www.gaiamtv.com/api/user/plays"

	},

	getUrl: function(key, params) {
		if (_.isFunction(this._urls[key])) {
			$log(" ARGUMENTS ARARAY ", Array.prototype.slice.call(arguments, 1))
			return this._urls[key].apply(this, Array.prototype.slice.call(arguments, 1));
		} else {
			return this._urls[key];
		}
	},

	 _readCookie: function(name)
{
  name += '=';
  var parts = document.cookie.split(/;\s*/);
  for (var i = 0; i < parts.length; i++)
  {
    var part = parts[i];
    if (part.indexOf(name) == 0)
      return part.substring(name.length)
  }
  return null;
},

	_createCookie: function(name, value, days) {
		if (days) {
			var date = new Date();
			date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
			var expires = "; expires=" + date.toGMTString();
		} else var expires = "";
		document.cookie = name + "=" + value + expires + "; path=/";
	},

	_eraseCookie: function(name) {
		this._createCookie(name, "", -1);
		return "Erased that cookie."
	},

	fetchItem: function(url, parser, callback, options) {
		$log(" FETCHING ITEM FROM URL " + url);
		options = _.defaults(options || {}, {
			type: "get",
			contentType: "json",
			 dataType: "json",
		// beforeSend : function (xhr) {
  //       xhr.setRequestHeader('Accept', 'application/json');
       
  //   },
		// 	  accepts: {
  //       json: 'application/json',
  //       text: 'application/json'
  //   },
  // headers:{Accept:'application/json; charset=utf-8','Content-Type':'application/json'},
			success: function(data) {
				// $log(" AJAX SUCCESS DATA: ", data);
				if (_.isString(data)) {
					$log('pretrim data', data)
					data = data.trim();
						$log('posttrim data', data)
					try {
						data = $.parseJSON(data);
					} catch (e) {
						$error("Tried to parse, JSON Error Parsing " + e);
					}

				}
				if (_.isFunction(parser)) data = parser(data);
				if (_.isFunction(callback)) callback(data);
			},
			error: function() {

				_.each(arguments, function(val,key){
					$log('error val, key: ', val, key)
				});
				$log(" AJAX ERROR ", arguments)
				callback(null);
			},
		});
		$.ajax(url, options);
	},
	login: function(callback) {
		this.fetchItem(this.getUrl("login"), this._parseLogin, callback, {
			type: 'post',
			contentType: 'application/x-www-form-urlencoded',
			data: {
				username: Gaiam.User.username,
				password: Gaiam.User.password
			},

			// dataType: "json",
			// headers:{"Authorization": 'auth'},
			// 	  xhrFields: {
   //    withCredentials: true
   // }
		});
	},

	_parseLogin: function(data) {
		$log("LOGIN PARSE ", data);
		Gaiam.User.loginData = data;
		$log("GAIAM USERDATA idToken AFTER LOGIN", Gaiam.User.loginData.idToken)
		Gaiam.User.tokenExpiration = data.idExpires * 1000;
		//Gaiam.API.daytime();
		Gaiam.User.escapedToken = escape(Gaiam.User.loginData.idToken);
		Gaiam.API._createCookie("idToken", Gaiam.User.loginData.idToken, 365);
		Gaiam.API._createCookie("passwordHash", data.passwordHash, 365);
		Gaiam.API._createCookie("uid", data.uid, 365);

		if (data.success == true) {
			$log('logintrigger fired');
			successfulLogin.trigger('loggedin');
		} else {
			$log('logintrigger fired');
			successfulLogin.trigger('badlogin');
			return
		}

		if (data.subscriptions.length == 0) {
			alert('Unauthorized user -- It might be time to renew your Gaiam subscription.')
			return
		}

	},

	md5login: function(callback) {

		this.fetchItem(this.getUrl("md5Login"), this._parsemd5Login, callback, {
			type: 'post',
			contentType: 'application/x-www-form-urlencoded',
			data: {
				uid: Gaiam.API._readCookie("uid"),
				passwordHash: Gaiam.API._readCookie("passwordHash"),
			},

			dataType: "text",
		});
	},

	_parsemd5Login: function(data) {
		$log('Parsing md5 login: ', data);
		Gaiam.User.loginData = data;
		Gaiam.User.escapedToken = escape(Gaiam.User.loginData.idToken);
		Gaiam.API._createCookie("idToken", Gaiam.User.loginData.idToken, 365);
		Gaiam.API._createCookie("passwordHash", data.passwordHash, 365);
		Gaiam.API._createCookie("uid", data.uid, 365);

		if (data.success == true) {
			$log('logintrigger fired');
			TVEngine.StageManager.changeScene('loginKeyboard')
			$log('successfull trigger')
			setTimeout(function(){successfulLogin.trigger('loggedin')},1000)
			
		} else {
			$log('logintrigger fired');
			TVEngine.StageManager.changeScene('loginKeyboard')
			setTimeout(function(){successfulLogin.trigger('badlogin')},1000)
			return
		}

		if (data.subscriptions.length == 0) {
			alert('Unauthorized user -- It might be time to renew your Gaiam subscription.')
			return
		}
	},

	renew: function(callback) {

		this.fetchItem(this.getUrl("renew"), this._parseRenew, callback, {
			type: 'post',
			contentType: 'application/x-www-form-urlencoded',
			data: {

			},

			dataType: "text",
		});
	},

	_parseRenew: function(data) {
		$log('Parsing renew: ', data)
		Gaiam.User.loginData = data;
		Gaiam.User.escapedToken = escape(Gaiam.User.loginData.idToken);
		Gaiam.API._createCookie("idToken", Gaiam.User.loginData.idToken, 365);
	},


	fetchVideosForCategory: function(id, callback) {
		this.fetchItem(this.getUrl("videosForCategoryUrl", id), this._parseVideosForCategory, callback)
	},
	_parseVideosForCategory: function(data) {
		$log(" PARSING VIDEOS FOR CATEGORY ", data);


		return new VideoCategory(data.titles);
	},

	fetchMoreVideos: function(id, callback) {

		this.fetchItem(this.getUrl("videosForCategoryUrl", id), this._parseMoreVideos, callback)
	},
	_parseMoreVideos: function(data) {
		$log('parsing MOREVIDEOS: ', data);
		return data
	},

	fetchUserNode: function(id, callback) {
		this.fetchItem(this.getUrl("userNodeUrl", id), this._parseUserNode, callback)
	},

	_parseUserNode: function(data) {
		$log('PARSING USER NODE', data);

	},

	addPlaylistFlag: function(id, callback) {
		$.post('http://www.gaiamtv.com/api/user/node/' + id + '/playlist', {
			flag_action: 'flag'
		}, function(data) {
			console.log('Did it Work?: ', data)
			callback(data.success);
		});
	},

	removePlayListFlag: function(id, callback) {
		$.post('http://www.gaiamtv.com/api/user/node/' + id + '/playlist', {
			flag_action: 'unflag'
		}, function(data) {
			console.log('Did it Work?: ', data)
			callback(data.success);
		});
	},

	checkPlayListFlag: function(id, callback) {
		this.fetchItem(this.getUrl("userNodeUrl", id), this._parsePlaylistflag, callback)
	},

	_parsePlaylistflag: function(data) {
		console.log('Is it on my playlist? ', data, data.playlist);
		return !!data.playlist;
	},

	fetchMyPlaylist: function(callback) {
		this.fetchItem(this.getUrl("myPlaylist"), this._parseMyPlaylist, callback)
	},

	_parseMyPlaylist: function(data) {
		return (data && data.titles && data.titles.length) ? data.titles : [];
	},
	fetchFeatured: function(callback) {
		this.fetchItem(this.getUrl("featured"), this._parseFeatured, callback);
	},

	_parseFeatured: function(data) {
		$log("Got Featured", data);
		return data
	},

	searchThis: function(searchterm, logsearchterm, page, perpage, callback) {
		this.fetchItem(this.getUrl("searchUrl", searchterm, page, perpage), this._parseSearchResults, callback);

		searchTermArray = logsearchterm.split(' ');
		$log('combinedSearchTerm is: ', searchTermArray);
		this.logThisSearch(searchTermArray);

	},

	_parseSearchResults: function(data) {
		console.log('search results: ', data)
		return data
	},

	fetchMySearches: function(callback) {
		this.fetchItem(this.getUrl("mySearches"), this._parseMySearches, callback);

	},

	_parseMySearches: function(data) {
		$log('my Searches: ', data);

		if (Gaiam.User.username!=='default'){

			out = data;

		myTransformedSearches = [];
		$.each(out.searches, function(index, value) {
			preTransformValue = value;
			if (preTransformValue !== null) {
				postTransformValue = preTransformValue.split(",").join(" ");
			}
			//		console.log('postTransformValue is:', postTransformValue);
			myTransformedSearches.push(postTransformValue);

		})

		out.searches = myTransformedSearches;
		recentSearchesObject = out;
		$log('out from mysearches parser is: ', out)
		// out.searches[0]='working recent search parser';
		return out
	}
	else{
			 out={}; recentSearchesObject=[];
			 out.searches=[];recentSearchesObject.searches=[];
			 out.searches[0]='No recent searches';
			 recentSearchesObject.searches[0]='Please login to view recent searches.'
			
		
			 return out
	}
	
		// return data
	},


	logThisSearch: function(searchterm, callback) {
		this.fetchItem(this.getUrl("logSearchUrl", searchterm), this._parseLoggedThisSearch, callback)
	},

	_parseLoggedThisSearch: function(data) {
		$log('did we log this search? : ', data);
	},

	fetchRecent: function(callback) {
		this.fetchItem(this.getUrl("recentVideos"), this._parseRecent, callback)
	},

	_parseRecent: function(data) {
		$log('my Recent videos: ', data);
		return data;
	},

	fetchSeries: function(nid, callback) {

		this.fetchItem(this.getUrl("seriesUrl", nid), this._parseSeries, callback)
	},

	_parseSeries: function(data) {
	console.log('parsing series :', data);
	return data;
	



	},

	initAnalytics: function(nid, callback) {

		var url = this.getUrl('analyticsInitUrl', nid);
		this.fetchItem(url, this._parseAnalyticsInit, callback, {
			type: 'post',
			data: {
				viewerId: Gaiam.User.loginData.uid,
				idToken: Gaiam.User.loginData.idToken
			},
			dataType: "json",
		});
	},

	_parseAnalyticsInit: function(data) {

		console.log('parsing analytics :', data)
		Gaiam.Analytics.initData = data;
		Gaiam.Analytics.nid = data.row.id;
		Gaiam.Analytics.analyticsToken = data.token;

		return data;
	},

	updateAnalytics: function(nid, analyticsToken, dataObject, callback) {

		myDataString = JSON.stringify(dataObject);

		$log('myDataString is: ', myDataString)
		var url = this.getUrl('analyticsUpdateUrl', nid, analyticsToken);
		this.fetchItem(url, this._parseAnalyticsUpdate, callback, {
			type: 'post',
			data: {
				//needs to be called JSON for the Gaiam API
				JSON: myDataString
			},
			dataType: "text",
			//contentType: 'application/json',
			processData: false
		});
	},

	_parseAnalyticsUpdate: function(data) {

		console.log('parsing analytics update', data);

		return data
	},


	fetchRenditions: function(id, callback) {
		var url = this.getUrl('renditionsUrl', id);
		$log('COOKIE IDTOKEN IS:',this._readCookie('idToken'));
		$log('platformName:',TVEngine.Platforms.platformName())
	
		
		$log('GAIAM USER LOGIN IDTOKEN IN RENDITIONFETCH:',Gaiam.User.loginData.idToken)
		this.fetchItem(url, this._parseRenditions, callback, {
			type: 'post',
			contentType: 'application/x-www-form-urlencoded',
			data: 
			{
				idToken:Gaiam.User.loginData.idToken}
				

			

		});
	},

		
			// dataType: "json",
			//    xhrFields: {
   //    withCredentials: true
   // }

	_parseRenditions: function(data) {
		$log('rendition dataobject', data);

		if (data && data.mediaUrls && data.mediaUrls.bcHLS) {
			$log('rendition mediaurls', data.mediaUrls);
			$log('Got renditions: ', data.mediaUrls.bcHLS);

			if(TVEngine.Platforms.platformName()=="lg"){
			//var m3u8Url="http://kooky-reef-9997.herokuapp.com/?url=" + escape(data.mediaUrls.bcHLS);
		var m3u8Url =data.mediaUrls.bcHLS+'&bandwidth=100%2C10000';
		$log('m3u8 parser url: ', m3u8Url);
		return currentVideoData.bcHLSURL=m3u8Url;
			}
	else{	
		return currentVideoData.bcHLSURL = data.mediaUrls.bcHLS}
		}
	},

	fetchPreviewRenditions: function(id, callback) {
	this.fetchItem(this.getUrl("renditionsPreviewUrl", id), this._parsePreviewRenditions, callback)

	//$.get('http://www.gaiamtv.com/api/media/'+id,function(data){Gaiam.API._parsePreviewRenditions(data)})
	},

	_parsePreviewRenditions: function(data) {
			$log('Got Preview Data: ', data);
		$log('rendition preview mediaurls', data.mediaUrls);
		$log('Got Preview Renditions: ', data.mediaUrls.bcHLS);
		if(TVEngine.Platforms.platformName()=="lg" ||TVEngine.Platforms.platformName()=="Samsung2012"||TVEngine.Platforms.platformName()=="Samsung"
			||TVEngine.Platforms.platformName()=="samsung"||TVEngine.Platforms.platformName()=="samsung2012"){
	//="http://kooky-reef-9997.herokuapp.com/?url=" +
		var m3u8Url =data.mediaUrls.bcHLS+'&bandwidth=100%2C10000';
		$log('m3u8 parser url: ', m3u8Url);
		return currentVideoData.bcPreviewHLSURL=m3u8Url;
		}
			else{return currentVideoData.bcPreviewHLSURL = data.mediaUrls.bcHLS}
		
		
		
	},

	fetchCategory: function(id, callback) {
		$log("FETCH CATEGORY ", id);
		var url = this.getUrl('categoryUrl', id);
		$log(" GOT CATEGORY URL ", url);
		this.fetchItem(url, this._parseCategory, callback);
	},

	fetchSubCategory: function(id, callback) {
		$log("FETCH CATEGORY ", id);
		var url = this.getUrl('subCategoryUrl', id);
		$log(" GOT CATEGORY URL ", url);
		this.fetchItem(url, this._parseCategory, callback);
	},


	_parseCategory: function(data) {
		$log(" PARSING CATEGORY DATA ", data);
		var titles = data.terms;
		var newtitles = titles.filter(function(el){
				$log('el is: ',el);
			return el.name!="Gaiam TV News" && el.name!="Audio"
		});
		$log('newtitles is:', newtitles)
	
		if (!data || !data.terms || data.terms.length == 0) return null;
		return new Categories(newtitles);
	},

	secondsToTime: function(secs) {
		var hours = Math.floor(secs / (60 * 60));

		var divisor_for_minutes = secs % (60 * 60);
		var minutes = Math.floor(divisor_for_minutes / 60);

		var divisor_for_seconds = divisor_for_minutes % 60;
		var seconds = Math.ceil(divisor_for_seconds);

		var obj = {
			"h": hours,
			"m": minutes,
			"s": seconds
		};
		return obj;
	},

	fetchMediaDetails: function(id, category, callback) {
		// Need to pass in the category to append it if necessary
		$log(" FETCHING MEDIA DETAILS FOR ID " + id);
		var _t = this;
		this.fetchItem(this.getUrl("mediaDetailsUrl", id), function(data) {
			return _t._parseMediaDetails(data, category);
		}, callback);

	},

	_parseMediaDetails: function(data, category) {
		var lengthString;
		$log("parsing media details ", data);
		if (data.feature) { //convert the length to something nice instead of pure seconds
			lengthString = this.formatLengthString(data.feature.duration);

		} else {
			console.log('NO FEATURE!!!');
			data.feature = "";
			lengthString = "";
		}

		if (data) {
			//return the data
			return {
				title: data.title,
				//with our string from above
				length: lengthString,
				rating: data.fivestar.average.value / 20,
				talent: data.cast,
				instructor: (data && data.instructor) ? data.instructor.value : null,
				genre: category,
				type: data.type,
				previewAvailable: !! (data.preview && data.preview.mediaAvailability && data.preview.mediaAvailability.bcHLS),
				previewNid: (data.preview && data.preview.nid) ? data.preview.nid : null,
				synopsis: data.fields.body[0].value,
				boxart: data.coverart_image.roku_158x204,
				feature: (data && data.feature) ? data.feature : null
			}
		}
	},

	fetchMediaPreviewID: function(id, category, callback) {
		// Need to pass in the category to append it if necessary
		$log(" FETCHING MEDIA DETAILS FOR ID " + id);
		var _t = this;
		this.fetchItem(this.getUrl("mediaDetailsUrl", id), function(data) {
			return _t._parseMediaPreviewID(data, category);
		}, callback);

	},

	_parseMediaPreviewID: function(data, category) {
		//$log(" parsing media details ", data);
		if (data.preview) {
			return {
				preview: data.preview
			}
		} else {
			return "No Preview Here!"
		}


	},

	daytime: function(callback) {
		timestamp = Date.now()
		this.fetchItem(this.getUrl("daytimeUrl"), this._parseDaytime, callback, {
			type: 'post',
			data: {
				clientTime: timestamp,

			},
			dataType: "json",
		});
	},

	_parseDaytime: function(data) {
		Gaiam.User.serverTime = data.serverTime * 1000;
		$log('Parsing daytime: ', data);
		$log('localnow is: ' + timestamp);
		$log('servernow is:' + data.serverTime * 1000);
		$log('token expiration is:' + Gaiam.User.tokenExpiration);
		if (typeof Gaiam.User.tokenExpiration != 'undefined' && (Gaiam.User.tokenExpiration <= Gaiam.User.serverTime)) {
			$log('renewing login token because it expired');
			Gaiam.API.renew();
		} else if (typeof Gaiam.User.tokenExpiration == 'undefined') {
			$log('No login token yet!')
		} else {
			$log('token is still fresh!!!')
		}
	},

	formatLengthString: function(featureDuration) {

		var lengthString;
		xTime = Gaiam.API.secondsToTime(featureDuration);
		timeMinute = xTime.m;
		timeSecond = xTime.s;
		$log('xTime is:', xTime)
		if (xTime.m == 1) {
			minuteString = " minute ";
		} else {
			if (xTime.m == 0) {
				timeMinute = "";
				minuteString = " ";
			} else {
				if (xTime.s != 0) {
					minuteString = " minutes, ";
				} else {
					minuteString = " minutes ";
				}
			}
		}

		if (xTime.s == 1) {
			secondString = " second";
		} else {
			if (xTime.s == 0) {
				timeSecond = "";
				secondString = " ";
			} else {
				secondString = " seconds"
			}

		}
		//don't show hours if they're zero because it looks bad
		if (xTime.h > 0 && xTime.h != 1) {
			lengthString = " " + xTime.h + " hours, " + timeMinute + minuteString + timeSecond + secondString;
		} else if (xTime.h == 0) {
			lengthString = " " + timeMinute + minuteString + timeSecond + secondString;
		} else if (xTime.h == 1) {
			lengthString = " " + xTime.h + " hour, " + timeMinute + minuteString + timeSecond + secondString;
		}

		return lengthString
	}


}