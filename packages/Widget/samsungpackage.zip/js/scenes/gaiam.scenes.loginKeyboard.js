(function() {

  var loginKeyboardScene = new Scene({
    defaultScene: false,
    name: "loginKeyboard",
    target: "#wrapper",
    view: "views/gaiam.views.loginkeyboard.html",
  });

  loginKeyboardScene.handlesback = function() {
    $log(" HANDLES BACK ")

    TVEngine.StageHistory.back();
    // this.s.landing();

    // return true;

  }

  var mainState = loginKeyboardScene.createState("main"),
    currentFocus = null,
    keyboardState = loginKeyboardScene.createState("keyboard", true)



    mainState.onenterstate = function() {
      // $log(" Entering login scene")

    }
  mainState.onleavestate = function() {

  }



  keyboardState.onenterstate = function() {
    TVEngine.Navigation.setFocus("gaiam:loginKeyboardMenu");
  }

  keyboardState.onleavestate = function() {
    // TVEngine.Navigation.menus.keyboardMenu.off(null, null, this);
  }

  loginKeyboardScene.onenterscene = function() {

    // $('body').keypress(function(event) {

    //   $log('event is: ' + event.which);
    // var c = String.fromCharCode(event.keycode)
    // var value = c;
    // $log('letter is: ' + c);
    // });
    // var $kp = $('#keyPress');
    // var $kd = $('#keyDown');
    // var $ku = $('#keyUp');




    // // qa keys for doing this...
    //     $(window).keypress(function(event) {
    //   if (event.which == 113) {
    //        debugLogin();
    //      // event.preventDefault();

    //    }


    // });

    //   $(window).keypress(function(event) {
    //     $log('event.which: '+ event.which)
    //   if (event.which == 119) {
    //          TVEngine.StageManager.changeScene('preauthMain');

    //      // event.preventDefault();
    //    }


    // });

    var _t = this;

    keyboardMenu = TVEngine.Navigation.getMenu("gaiam:loginKeyboardMenu");


    loginMenu = TVEngine.Navigation.getMenu("gaiam:login");
    backMenu = TVEngine.Navigation.getMenu("gaiam:backmenu");

    backMenu.on('ondown', function() {
      loginMenu.focus();
    }, this);
    backMenu.on('onselect', function() {
      TVEngine.StageHistory.back();
    }, this)



    $("#vignette").hide();
    $("#purple_vignette").show();


    usernameObject = $('#usernameField');
    passwordObject = $('#passwordField');
    submitButtonObject = $('#submitButton');
    inputfieldObject = $("#inputTextInput");
    usernameObject.addClass('loginActive');
    //make the username object something we can attach events to
    _.extend(usernameObject, Backbone.Events);

    usernameObject.on('change', function(textValue) {
      $log('username change')
      var oldStringWidth = TVEngine.util.getStringWidth($('#usernameText'), 23, 'HelveticaNeueLight');
      $('#usernameText').text(textValue);
      Gaiam.User.username = textValue;
      var newStringWidth = TVEngine.util.getStringWidth($('#usernameText'), 23, 'HelveticaNeueLight');
      var characterDifference = newStringWidth - oldStringWidth;
      var currentMarginLeft = parseInt($('#usernameText').css('margin-left'));
      var newMarginLeft = currentMarginLeft - characterDifference * 1.35;
      $log(' newStringWidth characterDifference currentMarginLeft newMarginLeft', newStringWidth, characterDifference, currentMarginLeft, newMarginLeft)
      if (newStringWidth >= 270) {
        $('#usernameText').css({
          'margin-left': newMarginLeft
        })
      }
    }, this);

    //and now the password object
    _.extend(passwordObject, Backbone.Events);
    //change events
    passwordObject.on('change', function(textValue) {
      $log('password change')
      var oldStringWidth = TVEngine.util.getStringWidth($('#passwordText'), 23, 'HelveticaNeueLight');
      $('#passwordText').text(textValue);
      Gaiam.User.password = textValue;
      var newStringWidth = TVEngine.util.getStringWidth($('#passwordText'), 23, 'HelveticaNeueLight');
      var characterDifference = newStringWidth - oldStringWidth;
      var currentMarginLeft = parseInt($('#passwordText').css('margin-left'));
      var newMarginLeft = currentMarginLeft - characterDifference * 1.35;
      $log(' newStringWidth characterDifference currentMarginLeft newMarginLeft', newStringWidth, characterDifference, currentMarginLeft, newMarginLeft)
      if (newStringWidth >= 270) {
        $('#passwordText').css({
          'margin-left': newMarginLeft
        })
      }
    }, this);

    //and the submit buttonr
    _.extend(submitButtonObject, Backbone.Events);

    submitButtonObject.on('select', function() {
      $log('submitbutton selected');
      $('#loginWrapper').hide();
      $('#keyboard').hide();
      showLoader();
      if (Gaiam.User.username !== 'default' && Gaiam.User.username !== "" && Gaiam.User.password !== 'default') {
        $log('in gaiam login loop')
        Gaiam.API.login();
      } else {
        Gaiam.errorModalHandler.trigger('show', 'Please enter your username and password')
      }

    }, this)

    //make an object to do things when we login (not always successfully but for naming sake we'll call it that)
    successfulLogin = new Object();
    _.extend(successfulLogin, Backbone.Events);
    successfulLogin.on('loggedin', function() {
      $log('SUCCESSFUL LOGIN!')
      hideLoader();
      TVEngine.StageManager.changeScene('main');
      Gaiam.User.loggedIn = true;

    }, this)
    successfulLogin.on('badlogin', function() {
      $log('BAD LOGIN!')
      // $('#badLoginContainer').show()
      Gaiam.errorModalHandler.trigger('show', 'Please enter a valid username and password')

    }, this)

    _.extend(inputfieldObject, Backbone.Events);
    inputfieldObject.whichInput = "username";
    inputfieldObject.on('change', function(value) {
      $log('inputfield changed ', value)
      if (inputfieldObject.whichInput == 'username') {
        // usernameObject.lastUsername = value;
        usernameObject.trigger('change', value);
        inputfieldObject.lastUsername = usernameObject.text();

      } else if (inputfieldObject.whichInput == 'password') {
        // passwordObject.lastPassword = value;
        passwordObject.trigger('change', value);
        inputfieldObject.lastPassword = passwordObject.text();

      }

    }, this);



    //end onenterscene

  }

  loginKeyboardScene.onleavescene = function() {

    $("#vignette").show();
    //  $("#purple_vignette").hide();
  };

  TVEngine.StageManager.addScene(loginKeyboardScene);


})(this);