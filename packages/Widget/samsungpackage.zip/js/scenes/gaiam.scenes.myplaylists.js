(function(TVEngine, window, undefined) {

    var playlistScene = new Scene({
        defaultScene: false,
        name: "myplaylists",
        target: "#wrapper",
        view: "views/gaiam.views.myplaylists.html"
    });
    var playlistVideos, playlistMenu;
    playlistScene.onenterscene = function() {
        var _t = this;
        playlistMenu = TVEngine.Navigation.getMenu("gaiam:playlists");
        backMenu = TVEngine.Navigation.getMenu("gaiam:backmenu");
        playlistMenu.on('onup', function() {
            backMenu.focus();
        }, this)
        backMenu.on('ondown', function () {
            playlistMenu.focus();
        }, this);
        backMenu.on('onselect', function() {
            TVEngine.StageHistory.back();
        }, this)
        showLoader();
        Gaiam.API.fetchMyPlaylist(function(data) {
            $log(" My Playlist",data)
            playlistVideos = new VideoCategory(data);
            var view = new PlaylistVideosView({
                collection: playlistVideos, el: "#myPlaylist",
            })
            hideLoader();
            view.render();
            playlistMenu.on('newfocus', function(idx) {
                var item = playlistVideos.at(idx);
                $log(" GOT ITEM ", item.attributes);
                $("#playlistVideoDetailsWrapper span").eq(0).text(item.get('title'));

        featureDuration=item.get('feature')['duration']
fields=item.get('fields');
         teaser=fields.teaser[0].value;
          $("#playlistVideoDetailsWrapper span").eq(1).text('| Length: ');
                   $("#playlistVideoDetailsWrapper span").eq(3).text(teaser);
      
            newLength=Gaiam.API.formatLengthString(featureDuration)
            $("#playlistVideoDetailsWrapper span").eq(2).text(newLength);;
            


            });
            playlistMenu.on('selected', function(idx) {
                TVEngine.StageManager.changeScene("videodetails", {
                    currentCategory: "My Playlists", video: playlistVideos.at(idx)
                });
            });
            _t.trigger("playlist:loadedplaylist");
            playlistMenu.focus();
        });
$('#LGRightHoverZone').hover(LGHoverRightHandlerIn, LGHoverRightHandlerOut);
$('#LGLeftHoverZone').hover(LGHoverLeftHandlerIn, LGHoverLeftHandlerOut);
        $("#vignette").hide();
        $("#purple_vignette").show();
        return "playlist:loadedplaylist";
    }
    playlistScene.onleavescene = function () {
        $("#vignette").show();
        $("#purple_vignette").hide();
    }



    TVEngine.StageManager.addScene(playlistScene);



})(TVEngine, window);