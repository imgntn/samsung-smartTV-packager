(function(TVEngine, window, undefined) {


    var recent = new Scene({
        defaultScene: false, name: "recent",
        target : "#wrapper", view: "views/gaiam.views.recent.html"
    });


   // var searchState = search.createState("searching", true);
	  var recentState = recent.createState("recentstate",true);


    recent.onenterscene = function() {
         $('#loader').show()
        $('#loadLogo').show();
       var _t = this;
      var firstEntry=true;
        recentMenu = TVEngine.Navigation.getMenu("gaiam:recent");
        backMenu = TVEngine.Navigation.getMenu("gaiam:backmenu");
        recentMenu.on('onup', function() {
            backMenu.focus();
        }, this)
        backMenu.on('ondown', function () {
            recentMenu.focus();
        }, this);
        backMenu.on('onselect', function() {
            TVEngine.StageHistory.back();
        }, this);

$('#LGRightHoverZone').hover(LGHoverRightHandlerIn, LGHoverRightHandlerOut);
$('#LGLeftHoverZone').hover(LGHoverLeftHandlerIn, LGHoverLeftHandlerOut);
 
        $log('RECENT onenterscene');
        $log(" GOT TO RECENT WITH PARAMS" , this.persist.params);
        showLoader();
        Gaiam.API.fetchRecent(function(data){

         recentVideos = new VideoCategory(data.titles);
         $log('RECENT VIDEOS COLLECTION IS: ', recentVideos);
          var view = new recentVideosView({
                    collection: recentVideos, el: "#recent",
                });

        view.render();
        hideLoader();
        recentMenu.on('newfocus', function(idx) {
                var item = recentVideos.at(idx);
                $log(" GOT ITEM ", item.attributes);
                $("#recentDetailsWrapper span").eq(0).text(item.get('title'));
                fields=item.get('fields');
                teaser=fields.teaser[0].value;
                   $("#recentDetailsWrapper span").eq(1).text('| Length: ');
                   $("#recentDetailsWrapper span").eq(3).text(teaser);
                 

                 featureDuration=item.get('feature')['duration'];
            newLength=Gaiam.API.formatLengthString(featureDuration);
            $("#recentDetailsWrapper span").eq(2).text(newLength);
             
            });
            recentMenu.on('selected', function(idx) {
                TVEngine.StageManager.changeScene("videodetails", {
                    currentCategory: "Recently Watched", video: recentVideos.at(idx)
                });
            });
            _t.trigger("recent:loadedrecent");
             $('#loader').hide()
        $('#loadLogo').hide();
            recentMenu.focus();
        });
       $("#vignette").hide();
        $("#purple_vignette").show();
return "recent:loadedrecent";
   }

    recent.onleavescene = function() {
        $log('LEAVING SEARCH SCENE');
                $("#vignette").show();
        $("#purple_vignette").hide();
}

   recentState.onenterstate = function() {
    $log('enter recent state')

    }
    recentState.onleavestate = function() {
    $log('leave recent state')
    }






    TVEngine.StageManager.addScene(recent);

})(TVEngine, window);