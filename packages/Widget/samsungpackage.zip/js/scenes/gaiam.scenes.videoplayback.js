(function(TVEngine, window, undefined) {

    var videoPlayback = new Scene({
        defaultScene: false,
        name: "videoplayback",
        target: "#wrapper",
        view: "views/gaiam.views.videoplayback.html"
    });

    videoPlayback.handlesback = function() {
        if (videoPlayback.currentState.name == "vidplayback") {
            videoPlayback.s.vidplayback();
            return false;
        } else {
            return true;
        }
    }

    var preloader = videoPlayback.createState("preloader");
    var vidplayback = videoPlayback.createState("vidplayback");
    var videoinfo = videoPlayback.createState("videoinfo");
    var morevideos = videoPlayback.createState("morevideos");

    var currentPage = 0,
        numPages = 0,
        backMenu, tabMenu, subCategoryName, categoryName;
    var currentVideoData;
    var details;
    var isPreview;
    var hideTimeout = null,
        isFavorite = false,
        currentNid = null;

     innerstateToPlayback = false;



    videoPlayback.onenterscene = function() {
        $log('GETTING RENDITIONS IN PLAYBACK ONENTERSCENE');
        $('#purple_vignette').hide();
        isFavorite = this.persist.params.isFavorite;
        if (isFavorite) $("#videoplayback_nav > div").eq(1).text("Remove from Playlist");
        else $("#videoplayback_nav > div").eq(1).text("Add to Playlist");
        $log(" GOT TO VIDEO PLAYBACK WITH PARAMS", this.persist.params);

        isFeatured = this.persist.params.isFeatured;
        $log('isfeatured?', isFeatured)
        if (isFeatured) {
            $log('in isfeatured')
            $("#videoplayback_nav > div").eq(2).hide();
        }
        //currentNid = this.persist.params.currentVideoData.feature.nid;
        this.persist.params.playPreview ? isPreview = true : isPreview = false;
        videoPlayback.s.vidplayback();
        details = this.persist.params;
        $log('DETAILS IN VIDPLAYBACK ARE: ', this.persist.params);
        backMenu = TVEngine.Navigation.getMenu("gaiam:backmenu"); //close menu
        tabMenu = TVEngine.Navigation.getMenu("gaiam:videoplayback:bottomtabs"); //bottom tabs
        pagingMenu = TVEngine.Navigation.getMenu("gaiam:videodetails:paging"); //paging in the info pane
        infoMenu = TVEngine.Navigation.getMenu("ade:dummymenu"); //info pane open menu
        moreVideosMenu = TVEngine.Navigation.getMenu("gaiam:morevideos");
        trickPlayMenu = TVEngine.Navigation.getMenu("gaiam:trickplay");
        //set the info tab up state to same position as on load
        var infoTabPosition = $(".bottomtabnav div").eq(0).offset();
        $("#bottomInfoTab").css("left", infoTabPosition.left);
        if (Gaiam.User.loggedIn !== true) {
            $("#videoplayback_nav > div").eq(1).hide()
        }

        //same thing for morevideos tab

        var moreVideosTabPosition = $(".bottomtabnav div").eq(2).offset();
        $("#bottomMoreVideosTab").css("left", moreVideosTabPosition.left);

        //set up menu event handling

        trickPlayMenu.on('all', function() {
            showAndHidePanes();
        }, this);

        backMenu.on('onfocus', function() {
            $log('BACKMENU FOCUSED')
            $(".backMenu > img").attr('src', "images/back_button_focus.png");
            showAndHidePanes();
        }, this);

        backMenu.on('ondown', function() {
            if ($("#videoplayback_nav").is(":visible")) {
                tabMenu.focus();
            }
            showAndHidePanes();
        }, this);

        backMenu.on('onup', function() {
            showAndHidePanes();
        }, this)

        backMenu.on('onright', function() {
            if ($("#videoplayback_nav").is(":visible")) {
                trickPlayMenu.focus();
            }
            showAndHidePanes();
        }, this);
        backMenu.on('onselect', function() {
            clearHideTimeouts();
            $log('BACKMENU SELECTED')
                $log('stagehistoryback3')
            TVEngine.StageHistory.back();
        }, this)

        tabMenu.on('onup', function() {
            if ($("#videoplayback_nav").is(":visible")) {
                trickPlayMenu.focus();
            }
            showAndHidePanes();
        })
        tabMenu.on('ondown', function() {
            showAndHidePanes();
        })
        tabMenu.on('selecteditem', function(action) {
            $log(" Tab Menu Action: ", action);
            switch (action) {
                case 'info':
                    //videoinfoOnenterstate();

                    videoPlayback.changeState("videoinfo");
                    break;

                case 'more-videos':
                    videoPlayback.changeState("morevideos");
                    break;
                case 'favorite':
                    //$log(" FAVORITING VIDEO ", isFavorite);
                    $("#videoplayback_nav> div").eq(1).html("<em>Saving</em>");
                    if (isFavorite) {
                        Gaiam.API.removePlayListFlag(currentNid, function() {
                            isFavorite = false;
                            $("#videoplayback_nav > div").eq(1).html("Add To Playlist");
                        });
                    } else {
                        Gaiam.API.addPlaylistFlag(currentNid, function() {
                            isFavorite = true;
                            $("#videoplayback_nav > div").eq(1).html("Remove From Playlist");
                        });
                    }
                    break;
            }
        })
        tabMenu.on('onright', function() {


            // $log('maxpage:' + tabMenu.maxPage);
            // $log('currentindex:' + tabMenu.currentIndex)



            if (Gaiam.User.loggedIn !== true && tabMenu.currentIndex < tabMenu.maxPage - 1) {
                tabMenu.currentIndex++;
                tabMenu.setFocus();
            } else if (Gaiam.User.loggedIn == true && tabMenu.currentIndex < tabMenu.maxPage) {
                tabMenu.currentIndex++;
                tabMenu.setFocus();
            }

            showAndHidePanes();

        }, this);

        tabMenu.on('onleft', function() {
            // $log('currentindex:' + tabMenu.currentIndex)
            if ($("#videoplayback_nav").is(":visible")) {
                if (tabMenu.currentIndex > 0) {
                    tabMenu.currentIndex--;
                    tabMenu.setFocus();
                }
            }
            showAndHidePanes();
        }, this)
        tabMenu.on('onfocus', function() {
            $log('currentindex:' + tabMenu.currentIndex)
            tabMenu.maxPage = $(".bottomtabnav > div:visible").last().index();
            tabMenu.setFocus();
            if ($("#videoplayback_nav").is(":visible")) {
                showAndHidePanes();
            }
        }, this)



        //paging menu for the info tab
        pagingMenu.on('onfocus', function() {
            $("#videoplayback_infopane").addClass("focused")
        }, this)
        pagingMenu.on('onblur', function() {
            $("#videoplayback_infopane").removeClass("focused")
        }, this)
        pagingMenu.on('onup', function() {
            infoMenu.focus();
        }, this)
        pagingMenu.on("newpage", function(page) {
            $log(" PAGING MENU NEW PAGE", page)
            $(".videoInfoSynopsis > div").css({
                top: -(Math.ceil($(".videoInfoSynopsis").outerHeight()) * page)
            })
            $(".videoInfoRightOverflow > div").css({
                top: -(Math.ceil($(".videoInfoSynopsis").outerHeight()) * (page + 1)),
            })
        }, this)


        //bindings
        $log('BINDING KEYS IN VIDEOPLAYBACK');

        TVEngine.KeyHandler.on('keyhandler:onPause', function() {
            $log('this keyhandler onPlay')
            if (TVEngine.MediaPlayer.playing()) {
                TVEngine.MediaPlayer.pause();
            } else {
                TVEngine.MediaPlayer.play()
            }

        }, this);

        TVEngine.KeyHandler.on('keyhandler:onPlay', function() {
            $log('this keyhandler onPlay')
            if (TVEngine.MediaPlayer.playing()) {
                TVEngine.MediaPlayer.pause();
            } else {
                TVEngine.MediaPlayer.play()
            }

        }, this);

        TVEngine.KeyHandler.on('keyhandler:onFF', function() {
            $log('this keyhandler onFF')
            // if(typeof window.video !=='undefined'){
            var video = $('video')[0];
            video.currentTime = video.currentTime + 10;
            // }


        }, this);

        TVEngine.KeyHandler.on('keyhandler:onRW', function() {
            $log('this keyhandler onFF')
            // if(typeof window.video !=='undefined'){
            var video = $('video')[0];
            video.currentTime = video.currentTime - 10;
            // }


        }, this);

        TVEngine.KeyHandler.on('keyhandler:onStop', function() {
            $log('this keyhandler onStop')
            TVEngine.MediaPlayer.stop();
            $log('stagehistoryback1')
            TVEngine.StageHistory.back();

        }, this);


    };

    var clearHideTimeouts = function() {
        //$log("CLEARING HIDE TIMOUTS")
        clearTimeout(hideTimeout);
    }
    var showAndHidePanes = function() {
        //$log("show and hide panes");
        clearTimeout(hideTimeout);
        if ($("#videoplayback_nav").is(":visible")) {
            hideTimeout = setTimeout(hideVideoPanes, 4000);
        } else {
            showVideoPanes();
        }
    }
    var showVideoPanes = function() {
        $(".videoPlaybackDetails:hidden").fadeIn();
        $("#videoplayback_nav:hidden").fadeIn();
        $(".backMenu:hidden").fadeIn();
        showAndHidePanes();
    }
    var hideVideoPanes = function() {
        clearHideTimeouts();
        $(".videoPlaybackDetails:visible").fadeOut();
        $("#videoplayback_nav:visible").fadeOut();
        $(".backMenu:visible").fadeOut();
    }
    videoPlayback.onleavescene = function() {
        $log('LEAVING VIDEOPLAYBACK SCENE');
        $("#purple_vignette").show();
        $('#categorySelectBackground').show();
        backMenu.off(null, null, this);
        tabMenu.off(null, null, this);
        TVEngine.MediaPlayer.stop();
        TVEngine.MediaPlayer.off(null, null, this);
        $log('unbinding keyhandler');
        TVEngine.KeyHandler.off(null, null, this)
        Gaiam.Analytics.clearAnalyticsIntervals();
      $log("leaving vidplayback state");
              var pluginPlayer = $('#pluginPlayer');
            pluginPlayer.css({
                 'visibility': 'hidden'
             })

         innerstateToPlayback = false;

    }

    /* VIDEO PLAYBACK STATE */
    vidplayback.onenterstate = function() {
        $log('innerstateToPlayback:', innerstateToPlayback)
        if (innerstateToPlayback == false) {
            _t = this;
            $log('vidplayback params3', TVEngine.StageManager.scene.persist.params);
            if (!isPreview) { thisNid = TVEngine.StageManager.scene.persist.params.currentVideoData.feature.nid}

            Gaiam.Analytics.analyticsData.events = [];
            if (!isPreview) {
                $log('it is a full length')
                Gaiam.API.fetchRenditions(thisNid, function(data) {
                    console.log('playback renditions data is: ', data);

                    $log('ENTERING VIDEO PLAYBACK, currentVideoData is: ', TVEngine.StageManager.scene.persist.params.currentVideoData)
                    TVEngine.MediaPlayer.on("all", mediaEventHandler, this);
                    $(".background").hide();
                    var playbackPlaylist = new Playlist();
                    var item = new PlaylistItem();
                    currentVideoData = TVEngine.StageManager.scene.persist.params.currentVideoData;
                    currentVideoData.bcHLSURL =data;
                    item.set(currentVideoData);
                    if (!isPreview) {
                        item.addRendition({
                            url: currentVideoData.bcHLSURL
                        })
                    }
                    playbackPlaylist.addItem(item);
                    TVEngine.MediaPlayer.setPlaylist(playbackPlaylist);
                    TVEngine.MediaPlayer.play();


                    //hide the branded background
                    $('#brandedBackground').hide();
                    //hide the catselect background

       //             $('#categorySelectBackground').hide();
        //            $("#vignette").hide();
        //            $("#purple_vignette").hide();


                })
            } else {
                $log('it is a preview')

               thisNid = TVEngine.StageManager.scene.persist.params.currentVideoData.previewNid
                Gaiam.API.fetchPreviewRenditions(thisNid, function(data) {
                    console.log('playback preview renditions data is: ', data);

                   // $log('ENTERING VIDEO PLAYBACK, currentVideoData is: ', TVEngine.StageManager.scene.persist.params.currentVideoData)
                    TVEngine.MediaPlayer.on("all", mediaEventHandler, this);
                    $(".background").hide();
                    var playbackPlaylist = new Playlist();
                    var item = new PlaylistItem();
                    currentVideoData = TVEngine.StageManager.scene.persist.params.currentVideoData;
                    currentVideoData.bcPreviewHLSURL =data;
$log('ENTERING VIDEO PLAYBACK, currentVideoData is: ',currentVideoData);
                    item.set(currentVideoData);

                    item.addRendition({
                        url: currentVideoData.bcPreviewHLSURL
                    })

                    playbackPlaylist.addItem(item);
                    TVEngine.MediaPlayer.setPlaylist(playbackPlaylist);
                    TVEngine.MediaPlayer.play();


                    //hide the branded background
                    $('#brandedBackground').hide();
                    //hide the catselect background

    //                $('#categorySelectBackground').hide();
     //               $("#vignette").hide();
      //              $("#purple_vignette").hide();


                })
            }

            //only init analytics if we're logged in
            if (Gaiam.User.loggedIn == true) {
                Gaiam.API.initAnalytics(TVEngine.StageManager.scene.persist.params.currentVideoData.feature.nid, function(data) {
                    console.log('init analytics in playback with this data ', data)
                });
                Gaiam.Analytics.setAnalyticsIntervals();
                //  Gaiam.Analytics.startPositionClock();
            }

        }



    }

    vidplayback.onleavestate = function() {
  
        // Gaiam.Analytics.stopPositionClock();
    }

    /* VIDEO INFO STATE */
    videoinfo.onenterstate = function() {
        //populate the info tab and
        renderMediaDetails(details);
        $('span.stars').stars();
        infoMenu.on('onfocus', function() {
            hideVideoPanes();
            $(".upfeaturenav").addClass("focused");
        })
        infoMenu.on('onblur', function() {
            $(".upfeaturenav").removeClass("focused");
        })
        infoMenu.on("ondown", function() {
            pagingMenu.focus();
        }, this)

        infoMenu.on("onselect", function() {
            $log('info ONSELECT');


            videoPlayback.changeState("vidplayback");
            $('.backMenu').show();
        }, this)

        $('#bottomInfoTab').on('mouseover', function() {
            infoMenu.focus();
        })
        $('#bottomInfoTab').on('click', function() {
            backMenu.focus();
            videoPlayback.changeState("vidplayback");
        })

        infoMenu.focus();
        innerstateToPlayback = true;
    }
    videoinfo.onleavestate = function() {
        infoMenu.off(null, null, this);
        pagingMenu.off(null, null, this);
        tabMenu.focus()
    }

    morevideos.onenterstate = function() {
        $log('enter morevideos state');

        moreVideosTID = TVEngine.DataStore.get('lastSubCategoryTID');
        $log('moreVideosTID is: ', moreVideosTID);
        moreVideosTitle = TVEngine.DataStore.get('lastSubCategoryName');
        $log('moreVideosName is: ', moreVideosTitle);

        Gaiam.API.fetchMoreVideos(moreVideosTID, function(data) {
            $log(" morevideos: ", data)
            moreVideosVideos = new VideoCategory(data.titles);
            $log('MOREVIDEOSVIDEOS IS:', moreVideosVideos);
            var view = new moreVideosView({
                collection: moreVideosVideos,
                el: "#moreVideosHolder",
            })
            $log('rendering morevideos view');
            view.render();
            //need to bind these after the view is rendered so they have something to latch onto
            $('#moreVideosButtonTarget').on('mouseover', function() {
                $log('over morevideos target')
                moreVideosMenu.currentIndex = -1;
                $(".morevideos-list > div").removeClass('focused');
                $('#bottomMoreVideosTab').css({
                    'background-color': '#61b14c'
                })
                $('#moreVideosDiv').css({
                    'border-top': '5px solid #61b14c'
                })

            });
            $('#moreVideosButtonTarget').on('mouseout', function() {
                $log('AWAY FROM morevideostarget')
                $('#bottomMoreVideosTab').css({
                    'background-color': '#1d8ed3'
                })
                $('#moreVideosDiv').css({
                    'border-top': '5px solid #1d8ed3'
                })


            });

            $('#moreVideosButtonTarget').on('click', function() {
                if (moreVideosMenu.currentIndex == -1) {
                    $log('MOREVIDEOS BACK TO PLAYBACK SELECTED');
                    videoPlayback.changeState("vidplayback");
                    tabMenu.focus();
                } else {
                    videoPlayback.changeState("vidplayback");
                    TVEngine.StageManager.changeScene("videodetails", {
                        currentCategory: "",
                        video: moreVideosVideos.at(idx)
                    })
                }
            });

            $('#moreVideosTitle').text(moreVideosTitle)


            moreVideosMenu.on('newfocus', function(idx) {
                var item = moreVideosVideos.at(idx);
                //$log(" GOT ITEM ", item.attributes);
                $log('idx: ' + idx)
                moreVideosMenu.currentIndex = idx;
                $(".morevideos-list > div").eq(moreVideosMenu.currentIndex).addClass('focused');
                $("#moreVideosDetailsWrapper span").eq(0).text(item.get('title'));
                fields = item.get('fields');
                teaser = fields.teaser[0].value;
                $("#moreVideosDetailsWrapper span").eq(1).text(teaser);
            });

            moreVideosMenu.on('selected', function(idx) {
                if (idx == -1) {
                    $log('MOREVIDEOS BACK TO PLAYBACK SELECTED');
                    videoPlayback.changeState("vidplayback");
                } else {
                    videoPlayback.changeState("vidplayback");
                    TVEngine.StageManager.changeScene("videodetails", {
                        currentCategory: "",
                        video: moreVideosVideos.at(idx)
                    });
                }
            });



            //       _t.trigger("morevideos:loadedmorevideos");
            moreVideosMenu.focus();
        });
        innerstateToPlayback = true;
    }

    //this is a stub, sub this out for the real object 
    //moreVideos=[{"title":"video1"},{"title":"video2"},{"title":"video3"}];
    morevideos.onleavestate = function() {
        $log('leave morevideos state');

        backMenu.focus();
        $('tabmenu index1: ' + tabMenu.currentIndex)
        tabMenu.currentIndex = 0;
        $('tabmenu index2: ' + tabMenu.currentIndex)
        tabMenu.focus()

    }


    var renderMediaDetails = function(details) {
        //$log("Rendering Media Details with from video playback: ", details)
        var template = Handlebars.compile($("#videoInfoTemplate").html());
        $("#videoplayback_infopane").html(template({
            video: details.currentVideoData
        }))
        currentPage = 0;
        numPages = Math.ceil($(".videoInfoSynopsis > div").outerHeight() / $(".videoInfoSynopsis").outerHeight());
        if (numPages > 1) {
            $("#viddetails_page_indicators").show();
            $("#viddetails_page_indicators > div").hide();
            $("#viddetails_page_indicators > div").slice(0, numPages).show();
            $("#viddetails_page_indicators > div").removeClass('active');
            $("#viddetails_page_indicators > div").eq(currentPage).addClass('active');
        } else {
            $("#viddetails_page_indicators").hide();
        }

    }


    var mediaEventHandler = function(event, param) {
        //$log("event: ", event)
        switch (event) {
            case 'timeupdate':
                var d = TVEngine.MediaPlayer.duration();

                if (_.isNumber(d)) {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(param) + " / " + TVEngine.util.convertMstoHumanReadable(d));
                    $(".progressBar").css({
                        width: Math.ceil((param / d) * 800)
                    });
                } else {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(param));
                }
                break;
            case 'play':
                $(".videoPlaybackDetails").fadeIn();
                videoActive = true;
                break;
            case 'playlist:newplaylistitem':
                //$log(" GOT NEW PLAYLIST ITEM ", param)
                updateCurrentVideo(param);
                break;
            case 'bufferingend':
                var pluginPlayer = $('#pluginPlayer');
                pluginPlayer.css({
                    'visibility': 'visible'
                })
                if (TVEngine.Platforms.platformName() !== "lg") {
                    $('.videoPreloader').hide();
                } else {

                    $('#canvasPreloader').hide();
                }

                // var pluginPlayer = $('#pluginPlayer');
                // pluginPlayer.css({'visibility':'visible'})
                showAndHidePanes();
                tabMenu.focus(); //this will trigger the menus to hide
                break;
            case 'bufferingstart':
                if (TVEngine.Platforms.platformName() !== "lg") {
                    $('.videoPreloader').show();
                } else {

                    $('#canvasPreloader').show();
                }



                break;
            case 'playlist:ended':
                $log('stagehistoryback2')
                TVEngine.StageHistory.back();
                break;
        }
    }


    var updateCurrentVideo = function(playlistItem) {
        $log(" UPDATE CURRENT VIDEO ", playlistItem);
        $(".vidDeetsNowPlaying").html(playlistItem.get("title").trunc(45, true).toString());
    }

    $.fn.stars = function() {
        return $(this).each(function() {
            // Get the value
            var val = parseFloat($(this).html());
            // Make sure that the value is in 0 - 5 range, multiply to get width
            var size = Math.max(0, (Math.min(5, val))) * 16;
            // Create stars holder
            var $span = $('<span  />').width(size);
            // Replace the numerical value with stars
            $(this).html($span);
        });
    }

    TVEngine.StageManager.addScene(videoPlayback);

})(TVEngine, window);