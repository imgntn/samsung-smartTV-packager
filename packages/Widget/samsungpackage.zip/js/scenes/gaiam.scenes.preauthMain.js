(function(TVEngine, window, undefined) {

    var preauthMainScene = new Scene({
        defaultScene: true,
        name: "preauthMain",
        target: "#wrapper",
        view: "views/gaiam.views.preauthMain.html"
    });

    var featuredDown = preauthMainScene.createState("featuredDown", true);

    var mainMenu, featuredItems, featuredItemsView, featuredMenu, dummyMenu, searchMenu, featuredVideosMenu;

    preauthMainScene.onenterscene = function() {

        $log(" ENTERING PREAUTH SCENE ");

        var pluginPlayer = $('#pluginPlayer');
        pluginPlayer.css({
            'visibility': 'hidden'
        })

        $('#brandedBackground').show();
        $('#categorySelectBackground').hide();



        mainMenu = TVEngine.Navigation.getMenu("gaiam:preauthMainMenu");
        featuredMenu = TVEngine.Navigation.getMenu("gaiam:featured");
        featuredMenu.whichMenu = 'preauth';
        dummyMenu = TVEngine.Navigation.getMenu("ade:dummymenu");
        $("#mainLogo").show();



        TVEngine.MediaPlayer.on("all", mediaEventHandler, this);

        $('#loader').show();
        $('#loadLogo').show();
        Gaiam.API.fetchFeatured(function(data) {

            if (data && (data.totalCount > 0)) {
                featuredVideos = new VideoCategory(data.titles);

                $log('featuredvideos are: ', featuredVideos);

                renderFeatured(featuredVideos);
            } else {
                TVEngine.Navigation.menus['gaiam:preauthMainMenu'].focus()
            }


            $('#loader').hide();
            $('#loadLogo').hide();


            $('#preauth-bottom-featured-nav').addClass('focusedblue');
        })


        featuredMenu.on('newfocus', function(idx) {
            var item = featuredVideos.at(idx);
            $log(" GOT ITEM ", item.attributes);
            currentVideoData = {};


            $("#featuredDetailsWrapper span").eq(0).text(item.get('title'));

            // fields=item.get('fields');
            // teaser=fields.teaser[0].value;
            $log('currentIndex is:' + featuredMenu.currentIndex)

            //    $("#featuredDetailsWrapper span").eq(3).text(teaser);



        }, this);
        featuredMenu.on('onselect', function(idx) {
            $log('item selected at index: ' + featuredMenu.currentIndex);
            //var item = featuredVideos.at(idx);
            $log('FEATURED ONSELECT!');
            $('#featuredWrapper').empty();
            $('#featuredDetailsWrapper').empty();
            showLoader();
            var item = featuredVideos.models[featuredMenu.currentIndex];
            if (item.attributes['preview']) {
                $log('inside preview loop')
                featuredDetails = Gaiam.API.fetchMediaDetails(item.attributes.nid, "Featured Video", function(data) {
                    $log('got media deets')
                    $log('data iz : ', data)
                    currentVideoDataOut = data;
                    // Gaiam.API.fetchPreviewRenditions(item.attributes['preview'].nid, function() {
                    //     $log('preauth fetch preview loop');
                    //     currentVideoDataOut.bcPreviewHLSURL = currentVideoData.bcPreviewHLSURL;

                        TVEngine.StageManager.changeScene("videoplayback", {
                            currentVideoData: currentVideoDataOut,
                            playPreview: true,
                            isFeatured: true
                            // isFavorite: isFavorite
                        });
                        hideLoader();
                    //})
                })

            }

        }, this)

        $('#LGRightHoverZone').hover(LGHoverRightHandlerIn, LGHoverRightHandlerOut);

        $('#LGLeftHoverZone').hover(LGHoverLeftHandlerIn, LGHoverLeftHandlerOut);
        //end onenterscene
        // $("#purple_vignette").hide();
    }
    preauthMainScene.onleavescene = function() {
        $("#mainLogo").hide();
        TVEngine.MediaPlayer.off(null, mediaEventHandler, this);
    }

    var renderFeatured = function(items) {
        $log(" RENDERING ITEMS ", items)
        var featuredItemsView = new featuredVideosView({
            collection: items
        })
        featuredItemsView.render();
        featuredMenu.focus()
        // featuredMenu.focus();
    }



    featuredDown.onenterstate = function() {

        $('#featuredNav').show();
        // mainMenu.focus();

        mainMenu.on("featured:onselect", function() {
            TVEngine.Navigation.menus['gaiam:featured'].focus()
        }, this);

        mainMenu.on("categories:onselect", function() {
            TVEngine.StageManager.changeScene("catselection");
        }, this);

        mainMenu.on("search:onselect", function() {
            TVEngine.StageManager.changeScene("search");
        }, this);

        mainMenu.on("login:onselect", function() {
            TVEngine.StageManager.changeScene("loginKeyboard");
        }, this);
        mainMenu.setFeaturedOnly(false);
    }

    featuredDown.onleavestate = function() {
        mainMenu.off(null, null, this);
    }

    var mediaEventHandler = function(event, param) {

        switch (event) {
            case 'timeupdate':
                var d = TVEngine.MediaPlayer.duration();
                $(".videoPlaybackDetails").not(":visible").fadeIn();
                if (_.isNumber(d)) {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(param) + " / " + TVEngine.util.convertMstoHumanReadable(d));
                    $(".progressBar").css({
                        width: Math.ceil((param / d) * 800)
                    });
                } else {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(param));
                }
                break;
            case 'play':
                videoActive = true;
                break;
            case 'playlist:newplaylistitem':
                //$log(" GOT NEW PLAYLIST ITEM ", param)
                updateCurrentVideo(param);
                var d = TVEngine.MediaPlayer.duration();

                if (_.isNumber(d)) {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(0) + " / " + TVEngine.util.convertMstoHumanReadable(d));
                    $(".progressBar").css({
                        width: Math.ceil(0)
                    });
                } else {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(0));
                }
                break;
        }
    }


    var updateCurrentVideo = function(playlistItem) {
        $log(" UPDATE CURRENT VIDEO ", playlistItem);
        $(".vidDeetsNowPlaying").html(playlistItem.get("title").trunc(45, true).toString());

    }

    TVEngine.StageManager.addScene(preauthMainScene);

    TVEngine.bind("tvengine:appready", function() {
        $log('tvengine:appready caled');
      
    });

})(TVEngine, window);