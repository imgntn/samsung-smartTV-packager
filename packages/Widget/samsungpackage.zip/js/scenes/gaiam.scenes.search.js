(function(TVEngine, window, undefined) {

  var search = new Scene({
    defaultScene: false,
    name: "search",
    target: "#wrapper",
    view: "views/gaiam.views.search.html"
  });


  
  var searchResultsState = search.createState("searchresults");
  var searchingState = search.createState("searching", true);

  search.onenterscene = function() {
//bind for LG
$log('enter search scene')
$('#purple_vignette').show()
$('#LGHoverTopZone').hover(LGHoverBottomHandlerIn, LGHoverBottomHandlerOut);

$('#LGHoverBottomZone').hover(LGHoverTopHandlerIn, LGHoverTopHandlerOut);

listUp = $('.catSelectionUpArrow');
listUp.css({'z-index':'99'})
listDown = $('.catSelectionDownArrow');
listDown.css({'z-index':'99'})





  keyboardMenu = TVEngine.Navigation.getMenu("gaiam:keyboard");



    //getting menus


    //back menu functionality

    backMenu = TVEngine.Navigation.getMenu("gaiam:backmenu");

    //vertical menu
    verticalListMenu = TVEngine.Navigation.getMenu("gaiam:verticalList");

    verticalListMenu.setHandlers();
    keyboardMenu.setHandlers();

$('#submitButton').on('mouseover',function(){
  $log('mouseover submitbutton')
   $('.full-circle').removeClass('keyboardFocused')
   keyboardMenu.currentIndex=28;
  $(this).addClass('focused')
  keyboardMenu.focus();
  //Gaiam.User.searchTerm = $(searchField).text();
});

$('#submitButton').on('mouseout',function(){
  $(this).removeClass('focused')
});


 $('.catSelectionUpArrowDiv').hover(function(){$('.catSelectionUpArrowDiv').addClass('searchUpArrowDivFocused');$('.catSelectionUpArrow').addClass('searchUpArrowFocused')}, function(){$('.catSelectionUpArrowDiv').removeClass('searchUpArrowDivFocused');$('.catSelectionUpArrow').removeClass('searchUpArrowFocused')});

 $('.catSelectionDownArrowDiv').hover(function(){$('.catSelectionDownArrowDiv').addClass('searchDownArrowDivFocused');$('.catSelectionDownArrow').addClass('searchDownArrowFocused')}, function(){$('.catSelectionDownArrowDiv').removeClass('searchDownArrowDivFocused');$('.catSelectionDownArrow').removeClass('searchDownArrowFocused')});

    //load keyboard menus

$('#submitButton').on('click',function(){
         if($('#searchField').text()=="Enter a Search"){return}
         $('#searchResultsTable').hide()
        $log('PRESSED SUBMIT!')
        Gaiam.User.searchTerm = $('#searchField').text();

   var searchScene = TVEngine.StageManager.scene;
         $log('changed state before')

     if($('#searchResultsTable li').length!==0){
       searchScene.currentState.onenterstate();
     }
       else{ search.changeState("searchresults");}
        $log('changed state after')
         $('#searchResultsTable').show()
        $('#recentSearchesTable').hide()
        //$('#submitButton').removeClass('focused');

      //  TVEngine.Navigation.menus["gaiam:keyboard"].onBlur();

        //TVEngine.Navigation.menus['gaiam:verticalList'].focus()
});


    $log('search onenterscene');
    $log(" GOT TO SEARCH WITH PARAMS", this.persist.params);

  


    keyboardMenu.on('onselect', function() {
      $log('KEYBOARD IN SCENE SELECT!', this.currentX, this.currentY);
      //get the value of the key
      x = this.currentX;
      y = this.currentY;
      thisKeyValue = keyboardObject['row' + (y + 1)][x];

      //get the searchfield as an object so we can do stuff to it
      searchField = $('#searchField');
      if (keyboardMenu.currentIndex == 28) {
        if($('#searchField').text()=="Enter a Search"){return}
        thisKeyValue = "";
        $log('PRESSED SUBMIT!')
        Gaiam.User.searchTerm = searchField.text();
        TVEngine.StageManager.scene.changeState("searchresults");
        $('#submitButton').removeClass('focused');

        TVEngine.Navigation.menus["gaiam:keyboard"].onBlur();

        TVEngine.Navigation.menus['gaiam:verticalList'].focus()

      }
      //want to delete anything before we add anything
      if (thisKeyValue === 'DEL') {
        $log('GOT THE DELETE HIT!')
        //get the text, slice off the last character, and reinsert itr
       var oldText = searchField.text().trim();
        $log('oldtext is: ' + oldText)
       var  slicedText = oldText.slice(0, -1);
        $log('slicedtext is: ' + slicedText)
        searchField.text(slicedText);
        xWidth = TVEngine.util.getStringWidth(searchField, 20, 'HelveticaNeueLight');
        if (xWidth > 250) {
          if (xWidth - 250 > 0) {

            searchField.css({
              'margin-left': 250 - xWidth
            })
          } else {
            searchField.css({
              'margin-left': 0
            })
          }


        }

      }
      //same with spaces
      if (thisKeyValue === 'SPC') {
        oldText = searchField.text();
        newText = oldText + " "
        searchField.text(newText)
        //   searchField.append(" ");
      }

      //
      if (verticalListMenu.firstKeyEntry == false) {

        xWidth = TVEngine.util.getStringWidth(searchField, 20, 'HelveticaNeueLight');
        $log('search string width: ' + xWidth);
        //dont do anything for del or spc keys

        if (thisKeyValue != 'DEL' && thisKeyValue != 'SPC') {
          //just add normally until we get to the full width of the field
          if (xWidth < 245) {
            //append the key value
            searchField.append(thisKeyValue);

          }
          //gotta move everything to the left so we can still see the search term
          else {

            searchField.css({
              'margin-left': 240 - xWidth
            })
            searchField.append(thisKeyValue);
          }


        }

        //but if it's the first entry we don't want to append, we want to replace
      } else {
        //gotta make sure it's not del or spc
        if (thisKeyValue != 'DEL' && thisKeyValue != 'SPC') {

          searchField.html(thisKeyValue);
          verticalListMenu.firstKeyEntry = false
        }

      }

      $log('keyboard value: ' + thisKeyValue)

    });


    keyboardMenu.on('onup', function() {
      if (TVEngine.Navigation.menus['gaiam:keyboard'].currentIndex >= 0 && TVEngine.Navigation.menus['gaiam:keyboard'].currentIndex <= 5) {

        var indexForBackFromKeyboard = keyboardMenu.currentIndex;
        var xForBackFromKeyboard = keyboardMenu.currentX;
        var yForBackFromKeyboard = keyboardMenu.currentY;
        TVEngine.DataStore.set('lastIndexForBackFromKeyboard', indexForBackFromKeyboard);
        TVEngine.DataStore.set('xForBackFromKeyboard', xForBackFromKeyboard);
        TVEngine.DataStore.set('yForBackFromKeyboard', yForBackFromKeyboard);
        backMenu.focus();
      }
    }, this);

    backMenu.on('ondown', function() {


      lastIndexForBackFromKeyboard = TVEngine.DataStore.get('lastIndexForBackFromKeyboard');
      xForBackFromKeyboard = TVEngine.DataStore.get('xForBackFromKeyboard')
      yForBackFromKeyboard = TVEngine.DataStore.get('yForBackFromKeyboard')

      keyboardMenu.focus();
      keyboardMenu.onBlur();
      keyboardMenu.setFocused(lastIndexForBackFromKeyboard);

      keyboardMenu.currentIndex = lastIndexForBackFromKeyboard;
      keyboardMenu.currentX = xForBackFromKeyboard;
      keyboardMenu.currentY = yForBackFromKeyboard;
    }, this);
    backMenu.on('onselect', function() {
      $log('search backmenu stagehistory');
      TVEngine.StageHistory.back();
    }, this);


 if(TVEngine.Navigation.currentMenu.currentIndex==28){

  $('#submitButton').addClass('focused')};

    verticalListMenu.bind('onleft', function() {

      keyboardMenu.focus();
      verticalListMenu.firstKeyEntry=true;
            if(keyboardMenu.currentIndex==28){
        $('#submitButton').addClass('focused')
      }

    }, this);

    keyboardMenu.bind('rightFromRight', function() {
 if(recentSearchesObject.searches[0]!='Please login to view recent searches.'){
   verticalListMenu.focus();
 }
     
    }, this);
    searchResultsObject = "fresh";

    //bind to the menu on the right that we use for recent searches and search results

    verticalListMenu.bind("onselect", function(idx) {
      if($('#searchResultsTable li').eq(0).text()=="No Results"){return}

      if (verticalListMenu.whichList == "recentSearchesTable") {
        $log('vList SELECT RECENTSEARCHES!');
        Gaiam.User.searchTerm = $("#" + verticalListMenu.whichList + " li").eq(verticalListMenu.currentIndex).text();
        TVEngine.StageManager.scene.changeState("searchresults");

      }
      if (verticalListMenu.whichList == "searchResultsTable") {
        $log('vList SELECT SEARCHRESULTS')

        $log('vSelect this is:' + this.currentIndex);
        if (searchResultsObject != "fresh") {
          $log('title here is: ', searchResultsObject.titles[this.currentIndex]);
          $log('searchResultsVideos at this index is:', searchResultsVideos.at(this.currentIndex));
          $log('TESTCURRENTINDEX 1 IS: ', this.currentIndex);
          if (searchResultsVideos.at(this.currentIndex).attributes.type == "product_series") {

            console.log('THIS REALLY IS A SERIES!');
            params = {};
            params.nid = searchResultsVideos.at(this.currentIndex).attributes.nid;
            params.title = searchResultsVideos.at(this.currentIndex).attributes.title;
            TVEngine.StageManager.changeScene('series', params);


          } else {
            TVEngine.StageManager.changeScene("videodetails", {
              currentCategory: "",
              video: searchResultsVideos.at(this.currentIndex)
            });
            $log('TESTCURRENTINDEX  2 IS: ', this.currentIndex)
          }

        } else {
          $log("results are clean -- first time in")
        }


      }

      //end vertical list bindings
    });
    verticalListMenu.whichList = "recentSearchesTable";
   // $('#recentSearchesContainer').empty();
    Gaiam.API.fetchMySearches(function(data) {
      renderRecentSearchesView(data)
 $('#recentSearchesTable li').ThreeDots({ max_rows:1 });
 $('#recentSearchesTable li').ThreeDots({ max_rows:1 });
 //set handlers for verticallistmenu on the right

   TVEngine.Navigation.menus["gaiam:verticalList"].setHandlers();
 if(recentSearchesObject.searches[0]=='Please login to view recent searches.'){
  $log('NO RECENT SEARCHES DOING SOME SHIT')
  if(keyboardMenu.currentIndex==28){$('#submitButton').addClass('focused')}
  TVEngine.Navigation.menus["gaiam:verticalList"].unsetHandlers()
 }


    })


    //this draws the keyboard
    search.renderSearchView();


    //need to manually center the double width keyboard items
    $('#keyboardContainer table tr td:eq(26) div').css({
      'width': '85px',
      'position': 'absolute',
      'left': '173px'
    })
    $('#keyboardContainer table tr td:eq(27) div').css({
      'width': '85px',
      'position': 'absolute',
      'left': '282px'
    })

    //$('#submitButton').removeClass('focused');
    //$log('calling keyboardmenu focus');

    keyboardMenu.focus();

  }

  search.onleavescene = function() {
    $log('LEAVING SEARCH SCENE');
    verticalListMenu.unbind(null, null, this);
   // keyboardMenu.unbind(null, null, this);
    //$('#recentSearchesContainer').empty();
    //$('#searchResultsContainer').empty();
    recentSearchesObject.searches[0]="";

  }

  search.renderSearchView = function(data) {
    $log('Rendering SEARCHVIEW');
    var template = Handlebars.compile($("#searchTemplate").html());
    $("#keyboardContainer").html(template({
      keyboard: keyboardObject
    }));
  };


  searchingState.onenterstate = function() {
    $log('searchingstate onenterstate');
   



  };

  searchingState.onleavestate = function() {

  };


  var renderRecentSearchesView = function(data) {



    $log('Rendering RECENTSEARCHESVIEW');
    var template = Handlebars.compile($("#recentSearchesTemplate").html());
    $("#recentSearchesContainer").html(template({
      searches: recentSearchesObject.searches
    }));
  };

  searchResultsState.onenterstate = function() {

    $log('ENTERING SEARCH RESULTS STATE');

//some bindings here since they get fired onback from results
    $('setting menu handlers in searchresultsstate');
    verticalListMenu.setHandlers();
    keyboardMenu.setHandlers();
listUp.on('click',function(){
  $log('listup click')
 
verticalListMenu.onUp()
});

if($('#recentSearchesTable li').eq(0).text()==" Please login to view recent searches."){
  $('#recentSearchesTable').hide();
}

//end that


listDown.on('click',function(){
    $log('listdown click')
verticalListMenu.onDown()
});


    verticalListMenu.whichList = "searchResultsTable";
      verticalListMenu.focus();
      
    //need to keep a regular and escaped searchterm for logging recent searches
    $log('searchterm is: ' + Gaiam.User.searchTerm);
    preTranformSearchTerm = Gaiam.User.searchTerm;
    preTransformArray = preTranformSearchTerm.split(' ');
    postTransformSearchTerm = preTransformArray.join('&');
    escapedSearchTerm = escape(postTransformSearchTerm);
    $log('searching in resultsonenterstate');
 $('#recentSearchesTable').hide();
    showLoader();
    Gaiam.API.searchThis(escapedSearchTerm, Gaiam.User.searchTerm, 1, 25, function(data) {
      $log('data in searchResultsState onenterscene is', data)
      if (data.titles.length != 0) {
        searchResultsObject = data;

      } else {
        searchResultsObject = {
          "titles": [{
            "title": ""
          }]
        };
        searchResultsObject.titles[0].title = 'No Results'
      };


      //need to sort object for showing titles to match the object we use for nid
      searchResultsObject.titles.sort(function(obj1, obj2) {
        return obj1.nid - obj2.nid
      })

      //here we go
      searchResultsVideos = new VideoCategory(data.titles);
      searchResultsVideos.comparator = function(model1, model2) {
        return model1.get('nid') - model2.get('nid');
      };
      searchResultsVideos.sort();
      $log('search results VIDEOS are: ', searchResultsVideos);
      $log('search results object is: ', searchResultsObject);

      //now render the view
      renderSearchResultsView();

     $('#searchResultsTable li').ThreeDots({ max_rows:1 });
    $log('doing ellipsis!')
    $('#searchResultsTable li').ThreeDots({ max_rows:1 });
$log('results length:' + $('#searchResultsTable li').length);
if ($('#searchResultsTable li').length >6){
  $('.catSelectionDownArrowDiv').show()
}
      //since we're not focusing the menu, we have to do the verticallist onfocus stuff here
    



      var vMenu = TVEngine.Navigation.menus['gaiam:verticalList'];
      //if we don't set a maxindex we can't move up and down the list
      vMenu.maxIndex = data.titles.length-1;
      vMenu.currentIndex = 0;
$("#" + verticalListMenu.whichList + " li").eq(verticalListMenu.currentIndex-1).css({'margin-top':'0px'})
$("#" + verticalListMenu.whichList + " li").eq(verticalListMenu.currentIndex).css({'margin-top':'-21px'})
$("#" + verticalListMenu.whichList + " li").eq(verticalListMenu.currentIndex+1).css({'margin-top':'22px'})
$("#" + verticalListMenu.whichList + " hr").eq(verticalListMenu.currentIndex+1).hide()
      //focus it!
       TVEngine.Navigation.menus["gaiam:verticalList"].unsetHandlers()
 TVEngine.Navigation.menus["gaiam:verticalList"].setHandlers();
      vMenu.setFocused();

     hideLoader();

verticalListMenu.bind('onleft', function() {
 
      $log('changing state from verticalListMenu')
  $('#searchResultsContainer').empty();

      search.changeState('searching');

      keyboardMenu.focus();

            if(keyboardMenu.currentIndex==28){
        $('#submitButton').addClass('focused')
      }
    }, this);
    });




  };
  searchResultsState.onleavestate = function() {
    $log('LEAVING SEARCH RESULTS STATE');
        verticalListMenu.firstKeyEntry=true;
        verticalListMenu.unbind('onleft');
$('#searchResultsContainer').empty();
      if(keyboardMenu.currentIndex==28){
        $('#submitButton').addClass('focused')
      }

  };


  var renderSearchResultsView = function(data) {
    $log('Rendering SEARCHRESULTSVIEW');
    var template = Handlebars.compile($("#searchResultsTemplate").html());
    $("#searchResultsContainer").html(template({
      results: searchResultsObject.titles
    }));



  };


  var keyboardArray = new Array();
  keyboardArray[0] = ["A", "B", "C", "D", "E", "F"];
  keyboardArray[1] = ["G", "H", "I", "J", "K", "L"];
  keyboardArray[2] = ["M", "N", "O", "P", "Q", "R"];
  keyboardArray[3] = ["S", "T", "U", "V", "W", "X"];
  keyboardArray[4] = ["Y", "Z", "DEL", "SPC"];


  var keyboardObject = {};

  keyboardObject.row1 = keyboardArray[0];
  keyboardObject.row2 = keyboardArray[1];
  keyboardObject.row3 = keyboardArray[2];
  keyboardObject.row4 = keyboardArray[3];
  keyboardObject.row5 = keyboardArray[4];


  $log('KEYBOARD OBJECT IS: ', keyboardObject);

  TVEngine.StageManager.addScene(search);

})(TVEngine, window);