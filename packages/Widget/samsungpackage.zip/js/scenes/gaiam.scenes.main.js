(function(TVEngine, window, undefined) {

    var mainScene = new Scene({
        defaultScene: false,
        name: "main",
        target: "#wrapper",
        view: "views/gaiam.views.main.html"
    });

    var featuredDown = mainScene.createState("featuredDown", true);
    var mymainMenu, featuredItems, featuredItemsView, featuredMenu, dummyMenu, getFeaturedMenu, searchMenu, featuredVideosMenu;

    mainScene.onenterscene = function() {
        $log(" ENTERING MAIN SCENE ");

  
  Gaiam.Analytics.bindListeners();

        var pluginPlayer = $('#pluginPlayer');
        pluginPlayer.css({
            'visibility': 'hidden'
        })

        $('#brandedBackground').show();
        $('#categorySelectBackground').hide();

        // Debug login
        // Gaiam.API.login();
        $('#purple_vignette').show()
        $("#mainLogo").show();
        mymainMenu = TVEngine.Navigation.getMenu("gaiam:mainmenu");
        featuredMenu = TVEngine.Navigation.getMenu("gaiam:featured");
        featuredMenu.whichMenu = 'main';
        dummyMenu = TVEngine.Navigation.getMenu("ade:dummymenu");


        TVEngine.MediaPlayer.on("all", mediaEventHandler, this);

        $('#loader').show();
        $('#loadLogo').show();



        Gaiam.API.fetchFeatured(function(data) {
            if (data && (data.totalCount > 0)) {
                featuredVideos = new VideoCategory(data.titles);

                $log('featuredvideos are: ', featuredVideos);

                renderFeatured(featuredVideos);

//gaiam wants some kind of login confirmation

if(mainFirstEntry==true){

    Gaiam.errorModalHandler.trigger('show','Thanks for signing in.')
 dummyMenu = TVEngine.Navigation.menus['ade:dummymenu'];
  dummyMenu.focus();
  dummyMenu.on('onselect',function(){Gaiam.errorModalHandler.trigger('hide'); TVEngine.Navigation.getMenu("gaiam:featured").focus()})
  mainFirstEntry = false;
}

        

            } else {
                TVEngine.Navigation.menus['gaiam:mainmenu'].focus()

            }

            $('#loader').hide();
            $('#loadLogo').hide();

            $('#main-bottom-featured-nav').addClass('focusedblue');

        })


        featuredMenu.on('newfocus', function(idx) {
            var item = featuredVideos.at(idx);
            currentVideoData = {};
            $log(" GOT ITEM ", item.attributes);
            //$log('item nid:' , item.feature)

            $("#featuredDetailsWrapper span").eq(0).text(item.get('title'));
            // fields=item.get('fields');
            // teaser=fields.teaser[0].value;
            $log('currentIndex is:' + featuredMenu.currentIndex)

            //    $("#featuredDetailsWrapper span").eq(3).text(teaser);



        }, this);
        featuredMenu.on('onselect', function(idx) {
            $log('item selected at index: ' + featuredMenu.currentIndex);
            $('#featuredWrapper').empty();
            $('#featuredDetailsWrapper').empty();
            showLoader();
            var item = featuredVideos.models[featuredMenu.currentIndex];
            if (item.attributes['feature']) {
                featuredDetails = Gaiam.API.fetchMediaDetails(item.attributes.nid, "Featured Video", function(data) {
                    $log('got media deets')
                    $log('data iz : ', data)
                    currentVideoDataOut = data;
                
                // Gaiam.API.fetchRenditions(item.attributes['feature'].nid, function() {

                  //  currentVideoDataOut.bcHLSURL = currentVideoData.bcHLSURL;
                    TVEngine.StageManager.changeScene("videoplayback", {
                        currentVideoData: currentVideoDataOut,
                        playPreview: false,
                        isFeatured: true
                        // isFavorite: isFavorite
                    });
                    hideLoader();
                //})
                // currentVideoDataOut = item.attributes;

            })
            };
        }, this)


        $('#LGRightHoverZone').hover(LGHoverRightHandlerIn, LGHoverRightHandlerOut);

        $('#LGLeftHoverZone').hover(LGHoverLeftHandlerIn, LGHoverLeftHandlerOut);


    }

    mainScene.onleavescene = function() {
        $("#mainLogo").hide();
        TVEngine.MediaPlayer.off(null, mediaEventHandler, this);
    }

    var renderFeatured = function(items) {
        $log(" RENDERING ITEMS ", items)
        var featuredItemsView = new featuredVideosView({
            collection: items
        })
        featuredItemsView.render();
        featuredMenu.focus()
    }


    featuredDown.onenterstate = function() {

        $('#featuredNav').show();
        $log('mymainMenu', mymainMenu)
        // mymainMenu.focus();

        // mainMenu.on("featured:onselect", function() {
        //     mainScene.changeState("featuredUp");
        // }, this);

        mymainMenu.on("categories:onselect", function() {
            TVEngine.StageManager.changeScene("catselection");
        }, this);

        mymainMenu.on("recent:onselect", function() {
            TVEngine.StageManager.changeScene("recent");
        }, this);

        mymainMenu.on("playlist:onselect", function() {
            TVEngine.StageManager.changeScene("myplaylists");
        }, this);


        mymainMenu.on("search:onselect", function() {
            TVEngine.StageManager.changeScene("search");
        }, this);

        mymainMenu.on("logout:onselect", function() {
            Gaiam.User.username = 'default';
            Gaiam.User.password = 'default';
            Gaiam.User.loggedIn = 'false';
            TVEngine.StageManager.changeScene("preauthMain");
        }, this);
        mymainMenu.setFeaturedOnly(false);
    }

    featuredDown.onleavestate = function() {
        mymainMenu.off(null, null, this);
    }

    var mediaEventHandler = function(event, param) {

        switch (event) {
            case 'timeupdate':
                var d = TVEngine.MediaPlayer.duration();
                $(".videoPlaybackDetails").not(":visible").fadeIn();
                if (_.isNumber(d)) {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(param) + " / " + TVEngine.util.convertMstoHumanReadable(d));
                    $(".progressBar").css({
                        width: Math.ceil((param / d) * 800)
                    });
                } else {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(param));
                }
                break;
            case 'play':
                videoActive = true;
                break;
            case 'playlist:newplaylistitem':
                //$log(" GOT NEW PLAYLIST ITEM ", param)
                updateCurrentVideo(param);
                var d = TVEngine.MediaPlayer.duration();

                if (_.isNumber(d)) {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(0) + " / " + TVEngine.util.convertMstoHumanReadable(d));
                    $(".progressBar").css({
                        width: Math.ceil(0)
                    });
                } else {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(0));
                }
                break;
        }
    }


    var updateCurrentVideo = function(playlistItem) {
        $log(" UPDATE CURRENT VIDEO ", playlistItem);
        $(".vidDeetsNowPlaying").html(playlistItem.get("title").trunc(45, true).toString());

    }

    TVEngine.StageManager.addScene(mainScene);

    TVEngine.bind("tvengine:appready", function() {
        $log('tvengine:appready caled');
        Gaiam.Analytics.bindListeners();
    });

})(TVEngine, window);