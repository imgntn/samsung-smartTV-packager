(function(TVEngine, window, undefined) {

    var currentVideoDataOut;
    var videoDetails = new Scene({
        defaultScene: false,
        name: "videodetails",
        target: "#wrapper",
        view: "views/gaiam.views.videodetails.html"
    });

    videoDetails.handlesback = function() {
        if (videoDetails.currentState.name == "videoplayback") {
            videoDetails.s.videodetails();
            return false;
        } else {
            return true;
        }
    }

    var detailsState = videoDetails.createState("videodetails", true);
    var currentPage = 0,
        numPages = 0,
        backmenu, pagingMenu, tabMenu, subCategoryName, categoryName;
    var currentNid = null,
        isFavorite = null;

    var titleWidth;

    videoDetails.onenterscene = function() {
        // Julie note this.persist.params and getting the nid and category name you can set to static
        $log(">>>>>> GOT TO VIDEO DETAILS WITH PARAMS", this.persist.params.video);

        currentNid = this.persist.params.video.get("nid"), categoryName = (_.isString(this.persist.params.currentSubCategory) && this.persist.params.currentSubCategory.length) ? this.persist.params.currentSubCategory : this.persist.params.currentCategory;
        subCategoryName = this.persist.params.currentSubCategory
        $("#videodetails_nav > div").hide();

        //set up our menus
        backMenu = TVEngine.Navigation.getMenu("gaiam:backmenu");
        pagingMenu = TVEngine.Navigation.getMenu("gaiam:videodetails:paging");
        tabMenu = TVEngine.Navigation.getMenu("gaiam:videodetails:bottomtabs");

        //grab details for main video
        $('#loader').show();
        $('#loadLogo').show();
        Gaiam.API.fetchMediaDetails(currentNid, categoryName, function(data) {
            _t = this;
            $log(" FETCH MEDIA DETAILS GOT BACK ", data);

            if (data.type != 'product_series') {
                //   Gaiam.API.fetchRenditions(data.feature.nid);
                //check to see if there's a preview available
                if (data.previewAvailable) {
                    Gaiam.API.fetchPreviewRenditions(data.previewNid)
                }
                $log('fetching this rendition...');
                 $('#loader').hide();
                   $('#loadLogo').hide();
                renderMediaDetails(data);
                $('span.stars').stars();
                setBottomNav(data);
                currentVideoData = data;
                currentVideoDataOut = currentVideoData;
                $log('currentvideodata OUT is: ', currentVideoDataOut)
            } else {
                $log('This is probably a series.')

            };

            if (numPages > 1) {
                pagingMenu.focus();
            } else {
                tabMenu.focus();
            }
        });
        $("#videodetails_nav > div").eq(2).hide();
        Gaiam.API.checkPlayListFlag(currentNid, function(data) {
            $log(" PLAYLIST FLAG CHECK ", data);
            isFavorite = data;
            if (isFavorite) $("#videodetails_nav > div").eq(2).text("Remove from Playlist");
            else $("#videodetails_nav > div").eq(2).text("Add to Playlist");
            if(Gaiam.User.loggedIn==true){
                $("#videodetails_nav > div").eq(2).show();
            }
        })

    $log('categoryName is: ' + categoryName) 
        if (subCategoryName){
            $(".backText").text("Categories / " + this.persist.params.currentCategory + " / " + this.persist.params.currentSubCategory);
        } 
    
        else if (categoryName) {
            $(".backText").html("Categories / " + categoryName);
        } 
        else  $(".backText").html("Back ");
       // $("#vignette").hide();
        $("#purple_vignette").show();



        // backMenu.on('ondown onright', function() {
        //     if (numPages > 1) {
        //         pagingMenu.focus();
        //     } else {
        //         tabMenu.focus();
        //     }
        // }, this)

        backMenu.on('onselect', function() {
            TVEngine.StageHistory.back();
        },this)

         backMenu.on('ondown', function() {
            if (pagingMenu.maxPage!==-1){
                 pagingMenu.focus();
            }
            else {
                tabMenu.focus();
            }

           
        },this)

        pagingMenu.on('onup', function() {
            backMenu.focus();
        }, this)
        pagingMenu.on('ondown', function() {
            tabMenu.focus();
        }, this)

        pagingMenu.on("newpage", function(page) {

            $(".videoDetailsWrapper > div").css({
                top: -(Math.ceil($(".videoDetailsWrapper ").outerHeight()) * page)
            })

            $(".videoDetailsRightOverflow > div").css({
                top: -(Math.ceil($(".videoDetailsWrapper").outerHeight()) * (page + 1)),
            })


        }, this)

        tabMenu.on('onup', function() {
            if (numPages > 1) {
                pagingMenu.focus();
            } else {
                backMenu.focus();
            }
        });

        tabMenu.on('selecteditem', function(action) {
            var _t = this;
            $log(" Tab Menu Action: ", action);
            switch (action) {
                case 'video':
                    TVEngine.StageManager.changeScene("videoplayback", {
                        currentVideoData: currentVideoDataOut,
                        playPreview: false,
                        isFavorite: isFavorite
                    });
                    break;
                case 'preview':
                    TVEngine.StageManager.changeScene("videoplayback", {
                        currentVideoData: currentVideoDataOut,
                        playPreview: true,
                        isFavorite: isFavorite
                    });
                    break;
                case 'favorite':
                    $log(" FAVORITING VIDEO ", isFavorite);
                    $("#videodetails_nav > div").eq(2).html("<em>Saving</em>");
                    if (isFavorite) {
                        Gaiam.API.removePlayListFlag(currentNid, function() {
                            isFavorite = false;
                            $("#videodetails_nav > div").eq(2).html("Add To Playlist");
                        });
                    } else {
                        Gaiam.API.addPlaylistFlag(currentNid, function() {
                            isFavorite = true;
                            $("#videodetails_nav > div").eq(2).html("Remove From Playlist");
                        });
                    }
                    break;
                    case 'signup':
                   TVEngine.StageManager.changeScene('signup')
                    break;


            }
        });

    }
    videoDetails.onleavescene = function() {
        $log('LEAVING VIDEO DETAILS')
        $("#vignette").show();
      //  $("#purple_vignette").hide();
        backMenu.off(null, null, this);
        pagingMenu.off(null, null, this);
        tabMenu.off(null, null, this);
    }

    var renderMediaDetails = function(details) {
        var template = Handlebars.compile($("#videoDetailsTemplate").html());
        $("#viddetails").html(template({
            video: details
        }));

        //handle long titles by rearranging elements on the video details page -- must do this after the render
        titleWidth = TVEngine.util.getStringWidth('.videoDetailsHeader', 30, 'HelveticaNeueMedium');
        console.log('titleWidth: ' + titleWidth);
        if (titleWidth > 549) {

            $('.videoDetailsWrapper').css({
                'top': '240px',
                'height': '280px'
            });
            $('.videoDetailsRightOverflow').css({
                'top': '300px',
                'height': '300px'
            });
            $('.videoDetailsRightOverflow >div').css({
                'top': '-300px'
            });
        }

        currentPage = 0;
        numPages = Math.ceil($(".videoDetailsWrapper > div").outerHeight() / $(".videoDetailsWrapper").outerHeight());
        if (numPages > 1) {
            $log('no page indicators if')
            $("#viddetails_page_indicators > div").hide();
            $("#viddetails_page_indicators > div").slice(0, numPages).show();
            $("#viddetails_page_indicators > div").removeClass('active');
            $("#viddetails_page_indicators > div").eq(currentPage).addClass('active');
        } else {
            $log('no page indicators else')
            $("#viddetails_page_indicators").hide();
            $('.videoDetailsRightOverflow .synopsis').css({
                'display': 'none'
            })
        }

    }

    var setBottomNav = function(data) {
        $log(" Setting Bottom Nav ", data.previewAvailable);
        //only show full video button if user is logged in successfully
        if(Gaiam.User.loggedIn==true){     $("#videodetails_nav > div").eq(0).show();}
   
        
        if (data.type == "product_series") {
            $("#videodetails_nav > div").eq(3).hide();
        }
        if (data.previewAvailable) {
            $("#videodetails_nav > div").eq(1).show();
        }
        if(Gaiam.User.username=="default"){
            $("#videodetails_nav > div").eq(4).show();
        }
    }

    var mediaEventHandler = function(event, param) {

        switch (event) {
            case 'timeupdate':
                var d = TVEngine.MediaPlayer.duration();

                if (_.isNumber(d)) {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(param) + " / " + TVEngine.util.convertMstoHumanReadable(d));
                    $(".progressBar").css({
                        width: Math.ceil((param / d) * 800)
                    });
                } else {
                    $(".videoPosition").text(TVEngine.util.convertMstoHumanReadable(param));
                }
                break;
            case 'play':
                $(".videoPlaybackDetails").fadeIn();
                videoActive = true;
                break;
            case 'playlist:newplaylistitem':
                //$log(" GOT NEW PLAYLIST ITEM ", param)
                updateCurrentVideo(param);
                break;
        }
    }


    var updateCurrentVideo = function(playlistItem) {
        $log(" UPDATE CURRENT VIDEO ", playlistItem);
        $(".vidDeetsNowPlaying").html(playlistItem.get("title").trunc(45, true).toString());
    }

    // $.fn.stars = function() {
    //      return $(this).each(function() {
    //          // Get the value
    //          var val = parseFloat($(this).html());
    //          // Make sure that the value is in 0 - 5 range, multiply to get width
    //          var size = Math.max(0, (Math.min(5, val))) * 16;
    //          // Create stars holder
    //          var $span = $('<span  />').width(size);
    //          // Replace the numerical value with stars
    //          $(this).html($span);
    //      });
    //  }

    TVEngine.StageManager.addScene(videoDetails);


})(TVEngine, window);