(function(TVEngine, window, undefined) {

    var signupScene = new Scene({
        defaultScene: false,
        name: "signup",
        target: "#wrapper",
        view: "views/gaiam.views.signup.html"
    });
    var signupMenu;
    signupScene.onenterscene = function() {
        var _t = this;
        signupMenu = TVEngine.Navigation.getMenu("gaiam:signup");
        backMenu = TVEngine.Navigation.getMenu("gaiam:backmenu");
        
        signupMenu.on('onup', function() {
            backMenu.focus();
        }, this)
        backMenu.on('ondown', function() {
            signupMenu.focus();
        }, this);
        backMenu.on('onselect', function() {
            TVEngine.StageHistory.back();
        }, this);

        // var view = new signupView({
        //     collection: null,
        //     el: "#signupEl",
        // })
        // view.render();
        signupMenu.on('selected', function() {

        });

        signupMenu.focus();
        $("#vignette").hide();
        $('#signupModalBackground').show();
        $('#purple_vignette').show();
        // $('#signupModal').show();
        $('#signupButton').on('mouseover',function(){
            $(this).addClass('focused')
        })
        $('#signupButton').on('mouseout',function(){
               $(this).removeClass('focused')
        })
        $('#signupButton').on('click',function(){
               TVEngine.StageManager.changeScene("gaiam:loginKeyboard")
        })




    }

    signupScene.onleavescene = function() {
        $('.backMenu').off();
 $('#signupModalBackground').hide();
    }



    TVEngine.StageManager.addScene(signupScene);



})(TVEngine, window);