(function(TVEngine, window, undefined) {

    var seriesScene = new Scene({
        defaultScene: false,
        name: "series",
        target: "#wrapper",
        view: "views/gaiam.views.series.html"
    });
    var seriesVideos, seriesMenu;
    seriesScene.onenterscene = function() {
        $('#loader').show()
        $('#loadLogo').show();
        var _t = this;
        seriesMenu = TVEngine.Navigation.getMenu("gaiam:series");
        backMenu = TVEngine.Navigation.getMenu("gaiam:backmenu");
        seriesMenu.on('onup', function() {
            backMenu.focus();
        }, this)
        backMenu.on('ondown', function () {
            seriesMenu.focus();
        }, this);
        backMenu.on('onselect', function() {
            TVEngine.StageHistory.back();
        }, this);
        seriesNID=this.persist.params.nid;
        seriesTitle=this.persist.params.title;
        $log('this persist params is:', this.persist.params.nid);
         $log('this persist params is:', this.persist.params.title);
        $log('SERIES NID is: ', seriesNID)
        Gaiam.API.fetchSeries(seriesNID,function(data) {
            $log(" series" ,data)
            seriesVideos = new VideoCategory(data.titles);
            $log('SERIESVIDEOS IS: ',seriesVideos);
            var view = new seriesVideosView({
                collection: seriesVideos, el: "#series",
            })
            view.render();
            $('#seriesTitle').text(seriesTitle)
            seriesMenu.on('newfocus', function(idx) {
                var item = seriesVideos.at(idx);
                $log(" GOT ITEM ", item.attributes);
                $("#seriesDetailsWrapper span").eq(0).text(item.get('title'));
                fields=item.get('fields');
                teaser=fields.teaser[0].value;
                $("#seriesDetailsWrapper span").eq(1).text(teaser);
            });
            seriesMenu.on('selected', function(idx) {
                TVEngine.StageManager.changeScene("videodetails", {
                    currentCategory: seriesTitle, video: seriesVideos.at(idx)
                });
            });
            _t.trigger("series:loadedseries");
              $('#loadLogo').hide();
            $('#loader').hide()
            seriesMenu.focus();
        });
        $("#vignette").hide();
        $("#purple_vignette").show();
        return "series:loadedseries";
    }
    seriesScene.onleavescene = function () {
        $("#vignette").show();
        $("#purple_vignette").hide();
    }



    TVEngine.StageManager.addScene(seriesScene);



})(TVEngine, window);