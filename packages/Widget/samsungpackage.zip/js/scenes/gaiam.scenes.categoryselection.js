(function(TVEngine, window, undefined) {

    var catSelection = new Scene({
        defaultScene: false,
        name: "catselection",
        target: "#wrapper",
        view: "views/gaiam.views.catselection.html"
    });


    var catSelectionState = catSelection.createState("catselector", true);
    var subCatSelectionState = catSelection.createState('subcatselector');
    var videoSelectionState = catSelection.createState("videoSelector");

    var currentCategoryId = 1,
        selectionView, onSubCategory = false,
        currentMainCategoryName, currentMainCategoryData, currentSubCategoryData, currentSubCategoryName, currentVideoCategory = [],
        videoCategoryName = null,
        catMenu, lastVideoItemSelected, lastMainCatFocus = 0,
        lastSubCatFocus = 0,
        returnFromVideos = 'subcatselector',
        backMenu, gridMenu;


    catSelection.addTransitionMethod('catselector', 'videoSelector', function() {
        $log(" SETTING RETURN FROM VIDEOS TO CAT SELECTOR ");
        returnFromVideos = 'catselector';
    })
    catSelection.addTransitionMethod('subcatselector', 'videoSelector', function() {
        returnFromVideos = 'subcatselector';
    })


    catSelection.handlesback = function() {
        $log(" CAT SELECTION HANDLES BACK " + catSelection.currentState.name + " " + returnFromVideos);

        switch (catSelection.currentState.name) {
            case 'catselector':
                return true;
            case 'subcatselector':
                catSelection.s.catselector();
                return false;
            case 'videoSelector':
                catSelection.changeState(returnFromVideos);
                return false;

        }
    }

    catSelection.onenterscene = function() {
        $log(" CATEGORY SELECTION !!!  ON ENTER SCENE ");

$('#brandedBackground').hide();
$('#categorySelectBackground').show();

        if (!currentMainCategoryData) {
            loadCategory();
        } else {
            lastMainCatFocus = 0
            selectionView = new CategoriesSelectionView({
                el: '#catSelectionWrapper',
                collection: currentMainCategoryData
            });
            selectionView.render();
            catMenu.focus();
        }
        catMenu = TVEngine.Navigation.getMenu("gaiam:catselection");
        catMenu.reset();
        gridMenu = TVEngine.Navigation.getMenu("gaiam:videogrid");
        gridMenu.reset();
        backMenu = TVEngine.Navigation.getMenu("gaiam:backmenu");


        gridMenu.on('upfromtop', function() {
            backMenu.focus();
        })

        $("#vignette").hide();
        $("#purple_vignette").show();

        catMenu.on("onleft", function() {
            backMenu.focus();
        }, this)
        backMenu.on('onselect', function() {
            if (this.handlesback()) {
                $log('in catselection backmenu onselect1')
                TVEngine.StageHistory.back();
            }
        }, this)
        //if(!TVEngine.MediaPlayer.playing()) $("#backimage").show();
    }

    catSelection.onleavescene = function() {
        currentCategoryId = 1;
        // $("#vignette").show();
        // $("#purple_vignette").hide();
        $("#backimage").hide();
    }


    catSelectionState.onenterstate = function() {
        $('#categorySelectBackground').show();
        $log(" Entered Cat Selection State " + lastMainCatFocus);
        $(".backMenu > span").text("Categories");
        currentSubCategoryName = null;
        lastVideoItemSelected = 0;
        catMenu.on("selected", function(index) {
            $log(" CAT MENU SELECTED ", index);
            lastMainCatFocus = index;
            var tid = parseInt($(".categoriesSelectList:visible > li").eq(index).attr("data-tid"), 10);
            var leaf = ($(".categoriesSelectList:visible > li").eq(index).attr("data-isLeaf") == "true") ? true : false;
            currentMainCategoryName = $(".categoriesSelectList:visible > li").eq(index).text();
            if (leaf) {
                $log(" GOT LEAF GET THE VIDEOS ")
                TVEngine.Navigation.disable();
                TVEngine.DataStore.set('lastSubCategoryTID', tid);
                TVEngine.DataStore.set('lastSubCategoryName', currentMainCategoryName);
                Gaiam.API.fetchVideosForCategory(tid, function(data) {
                    $log(" GOT VIDEOS FOR CATEGORY ", data);
                    currentVideoCategory = data;
                    catSelection.s.videoSelector();
                    TVEngine.Navigation.enable();
                })
            } else {
                $log(" GOT NEW NODE ", tid);
                loadSubCategory(tid, $(".categoriesSelectList:visible > li").eq(index).text(), $(".categoriesSelectList > li").eq(index).attr("data-image"));
            }
        }, this);
    
        catMenu.currentIndex = lastMainCatFocus;
        catMenu.focus();

        backMenu.on('ondown onright', function() {
            catMenu.focus();
        }, this)


        catMenu.on('focused', function(index) {
            $("#backimage:visible").attr('src', $(".categoriesSelectList:visible > li").eq(index).attr("data-image"));
            $(".currentCategoryImage").attr('src', $(".categoriesSelectList:visible > li").eq(index).attr("data-image"));
            var currentCategoryImageBG = $(".categoriesSelectList:visible > li").eq(index).attr("data-image");
            $("#categorySelectBackground").css({'background-image':'url('+currentCategoryImageBG+')'})
          
        }, this);

        
    }

    catSelectionState.onleavestate = function() {
        catMenu.off(null, null, this);
        $log(" CAT MENU CURRENT FOCUS ", catMenu.currentIndex);

        backMenu.off(null, null, this);

    }

    subCatSelectionState.onenterstate = function() {
        $('#categorySelectBackground').show();
        catMenu.unsetHandlers();
        catMenu.setHandlers();

        $(".backMenu > span").text("Categories / " + currentMainCategoryName);

        lastVideoItemSelected = 0;
        selectionView = new CategoriesSelectionView({
            el: '#subcatSelectionWrapper',
            collection: currentSubCategoryData
        });
        selectionView.render();

        catMenu.on("selected", function(index) {
            $log(" SUB CAT MENU SELECTED ", index);


            var tid = parseInt($(".categoriesSelectList:visible > li").eq(index).attr("data-tid"), 10);
            var name = $(".categoriesSelectList:visible > li").eq(index).text();
            currentSubCategoryName = name;

            //save it for later
            TVEngine.DataStore.set('lastSubCategoryTID', tid);
            TVEngine.DataStore.set('lastSubCategoryName', name);

            TVEngine.Navigation.disable();
            $('#subcatSelectionWrapper').hide();
            $('#mainLogo').hide();
            showLoader();

            Gaiam.API.fetchVideosForCategory(tid, function(data) {
                $log(" GOT VIDEOS FOR CATEGORY ", data);
                currentVideoCategory = data;
                  hideLoader();
                //save
                TVEngine.DataStore.set('lastSubCategoryVideos', data);
                catSelection.s.videoSelector();
              
                TVEngine.Navigation.enable();
                $('#mainLogo').show();
            })
        }, this);
        catMenu.on('focused', function(index) {
            lastSubCatFocus = index;
        }, this);


        catMenu.setFocusByIndex(lastSubCatFocus);
        catMenu.focus();
        backMenu.on('ondown onright', function() {
            catMenu.focus();
        }, this)

    }
    subCatSelectionState.onleavestate = function() {
        catMenu.off(null, null, this);
        backMenu.off(null, null, this);
    }

    var loadCategory = function(id) {
        currentCategoryId = _.isNumber(id) ? id : currentCategoryId;
        $(".backMenu > span").text("Categories");
        lastMainCatFocus = 0;
        Gaiam.API.fetchCategory(currentCategoryId, function(data) {
            if (!data || !data.models.length) {
                $error(" No data error");
                Gaiam.utils.ErrorModal.show("Invalid Response", "We were unable to contact the Gaiam service, please try again later. If this problem persists please contact support@gaiamtv.com", function() {
                     $log('in catselection loadcategory onselect2')
                    TVEngine.StageHistory.back();
                })
                return;
            }
            currentMainCategoryData = data;
            selectionView = new CategoriesSelectionView({
                el: '#catSelectionWrapper',
                collection: currentMainCategoryData
            });
            selectionView.render();
            catMenu.focus();
        });
    }

    var loadSubCategory = function(id, name, image) {
        TVEngine.KeyHandler.incrementStupidCounter();
        $log(" LOADING SUB CATEOGRY ", currentCategoryId, id);
        if (currentCategoryId == id) {
            $log(" RETURNING ");
            catSelection.s.subcatselector();
            return;
        }
        lastSubCatFocus = 0;
        currentCategoryId = id;
        Gaiam.API.fetchSubCategory(currentCategoryId, function(data) {
            if (!data || !data.models.length) {
                $error(" No data error");
                Gaiam.utils.ErrorModal.show("Invalid Response", "We were unable to contact the Gaiam service, please try again later. If this problem persists please contact support@gaiamtv.com", function() {
                      $log('in catselection erromodal')
                    TVEngine.StageHistory.back();
                })
                return;
            }
            _(data.models).each(function(m) {
                m.attributes.term_image.roku_306x214 = image;
            });
            currentSubCategoryData = data;
            catSelection.s.subcatselector();

        })
    }


    videoSelectionState.onenterstate = function() {
        $('#categorySelectBackground').show();
        $log(" VIDEO SELECTION STATE ", currentVideoCategory);

          //show and hide category arrows for LG
  showVidGridArrows = function(){
$('#vidGridLeftArrow, #vidGridRightArrow').show()
  };

  hideVidGridArrows = function(){
$('#vidGridLeftArrow, #vidGridRightArrow').hide()

  };

        if (currentSubCategoryName) $(".backMenu > span").text("Categories / " + currentMainCategoryName + " / " + currentSubCategoryName);
        else $(".backMenu > span").text("Categories / " + currentMainCategoryName);
        currentVideoCategory.comparator = function(item) {
            return item.get("title");
        }

        currentVideoCategory.sort();

        var videoGridView = new VideoGridView({
            collection: currentVideoCategory
        });


        videoGridView.render();
        showVidGridArrows();


        gridMenu.on("onfocus", function() {
            $log(" GRID MENU ON FOCUS ")
            $("#vidDetailsWrapper").show();
        }, this);
        gridMenu.on("onblur", function() {
            $log(" GRID MENU ON BLUR ");
            $("#vidDetailsWrapper").hide();
        }, this);




        gridMenu.on("selecteditem", function(index) {
            $log(" CURRENT VIDEO ", currentVideoCategory, index, currentVideoCategory.at(index));
            thisVideo = currentVideoCategory.at(index);
            $log("THISVIDEO IS: ", thisVideo);

            if (thisVideo.attributes.type == "product_series") {
                lastVideoItemSelected = index;
                console.log('THIS REALLY IS A SERIES!');
                params = {};
                params.nid = thisVideo.attributes.nid;

                params.title = thisVideo.attributes.title;
                TVEngine.StageManager.changeScene('series', params);

            }
            
            else{  lastVideoItemSelected = index;
            TVEngine.StageManager.changeScene("videodetails", {
                currentCategory: currentMainCategoryName, currentSubCategory: currentSubCategoryName, video: currentVideoCategory.at(index)
            })
            }

        }, this)
        gridMenu.on("newfocus", function(index) {
            $log(" CURRENT ITEM ", currentVideoCategory.at(index))
            thisVideo = currentVideoCategory.at(index);


            if (thisVideo.attributes.type == "product_series") {
                console.log('This is a series not a video!!');
            } else {
                $("#vidDetailsWrapper > div > span").eq(0).html(currentVideoCategory.at(index).get('title').trunc(45, true).toString());
                $("#videoCounter").text((index + 1) + " of " + currentVideoCategory.length);
                $("#vidDetailsWrapper > div > span").eq(1).text('Page: '+(gridMenu.currentPage+1)+'/'+(gridMenu.maxPages+1));
            }
 }, this)
        $log(" CAlling focus from videoselectionstate:onup")
        if (lastVideoItemSelected > 0) {
            gridMenu.setCurrentFocusByIndex(lastVideoItemSelected);
        }
        gridMenu.focus();
        backMenu.on('ondown', function() {
            gridMenu.focus();
        }, this)
    }


    videoSelectionState.onleavestate = function() {
             hideVidGridArrows();
        gridMenu.off(null, null, this);
        backMenu.off(null, null, this);
    }

    TVEngine.StageManager.addScene(catSelection);


})(TVEngine, window);