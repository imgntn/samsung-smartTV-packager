var isMediaPlayerPaused = true;
var isMediaPlayerStopped = true;

Gaiam.Analytics = {
	positionInterval: null,
	playPauseInterval: null,
	beaconUpdateInterval: null,
	histogramBinInterval: null,
	nid: null,
	analyticsToken: null,
	initData: {

		beaconInterval: 18,
		eventInterval: 180,
		histogramInterval: 6,
		histogramResolution: 30
	},

	analyticsData: {

		lastPlayState: "",
		position: 1281,
		seekCount: 0,
		sleepCount: 0,
		histogram: {
			timecodeHistory: [],
			histogramInterval: 6,
			histogramResolution: 30,
		},
		lastEventUpd: 0,
		events: []


	},

	bindListeners: function() {
	

if(Gaiam.User.loggedIn==true){
		$log('binding analytics listeners');

		//bind to some tv engine events to send analytics
		TVEngine.MediaPlayer.bind("bufferingstart", function() {
			$log(' analytics BUFFERINGSTART Called!!!!!!!!!!!!!!!!!!!!!');
			this.analyticsData.events.push({
				timestamp: Date.now(),
				name: "Buffering"
			})
			this.lastEventUpdate();
			this.analyticsData.lastPlayState = "Buffering";
		}, this);

		TVEngine.MediaPlayer.bind("play", function() {
			$log(' analytics PLAY Called!!!!!!!!!!!!!!!!!!!!!');
			this.analyticsData.events.push({
				timestamp: Date.now(),
				name: "Playing"
			})
			this.lastEventUpdate();
			this.analyticsData.lastPlayState = "Playing";
		}, this);


		TVEngine.MediaPlayer.bind("pause", function() {
			$log(' analytics PAUSE Called!!!!!!!!!!!!!!!!!!!!!');
			this.analyticsData.events.push({
				timestamp: Date.now(),
				name: "Paused"
			});
			this.lastEventUpdate();
			this.analyticsData.lastPlayState = "Paused";
		}, this);


		TVEngine.MediaPlayer.bind("onstop", function() {
			$log(' analytics STOP Called!!!!!!!!!!!!!!!!!!!!!');
			this.analyticsData.events.push({
				timestamp: Date.now(),
				name: "Stopped"
			});
			this.lastEventUpdate();
			this.analyticsData.lastPlayState = "Stopped";
			//want to write on every stop
			this.writeToAnalytics();
		}, this);


		TVEngine.MediaPlayer.bind("play", function() {
			$log('starting analytics clock and histogram');
			this.startPositionClock();
			this.startHistogramBin();
		}, this);

		TVEngine.MediaPlayer.bind("onstop", function() {
			$log('stopping analytics clock and histogram');
			this.stopPositionClock();
			this.stopHistogramBin();
		}, this);


		//setup some flags so we can tell when things are playing/paused/stopped
		TVEngine.MediaPlayer.bind("play", function() {
			isMediaPlayerPaused = false;
			isMediaPlayerStopped = false;
		}, this);

		TVEngine.MediaPlayer.bind("pause", function() {
			isMediaPlayerPaused = true;
		}, this);

		TVEngine.MediaPlayer.bind("onstop", function() {
			isMediaPlayerStopped = true;
			isMediaPlayerPaused = false;

		}, this);


}

	},

	startPositionClock: function() {

		if (isMediaPlayerPaused == false && isMediaPlayerStopped == true) {
			this.analyticsData.position = 0;
		}


		Gaiam.Analytics.positionInterval = setInterval(function() {
			//$log('video position is:' + Gaiam.Analytics.videoPosition);
			Gaiam.Analytics.analyticsData.position++;

		}, 1000);
	},


	stopPositionClock: function() {
		clearInterval(Gaiam.Analytics.positionInterval);
	},

	startHistogramBin: function() {
		$log('starting histogrambin');
		if (isMediaPlayerPaused == false && isMediaPlayerStopped == true) {
			Gaiam.Analytics.analyticsData.histogram.timecodeHistory = [];
		}


		Gaiam.Analytics.histogramBinInterval = setInterval(function() {


			if (TVEngine.MediaPlayer.playing() == true) {

				bin = Math.floor(Gaiam.Analytics.analyticsData.position / Gaiam.Analytics.initData.histogramResolution);
				if (Gaiam.Analytics.analyticsData.histogram.timecodeHistory[bin] == undefined) {
					Gaiam.Analytics.analyticsData.histogram.timecodeHistory[bin] = 1
				} else {
					Gaiam.Analytics.analyticsData.histogram.timecodeHistory[bin]++
				}

			}
			//{$log('bin value is: ' + bin)}
		}, Gaiam.Analytics.initData.histogramInterval * 1000)


	},

	stopHistogramBin: function() {
		$log('stopping histogrambin');
		clearInterval(Gaiam.Analytics.histogramBinInterval);
	},


	clearAnalyticsIntervals: function() {
		if(Gaiam.User.loggedIn==true){
			$log('Clearing Analytics Intervals...');

		clearInterval(Gaiam.Analytics.playPauseInterval);
		clearInterval(Gaiam.Analytics.beaconUpdateInterval);

		return 'Cleared Intervals'
		}
		
	},


	setAnalyticsIntervals: function() {
		$log('Setting Analytics Intervals...');

		Gaiam.Analytics.fullUpdateInterval = setInterval(function() {
			$log('writing full analytics update')
			Gaiam.Analytics.writeToAnalytics();
		}, Gaiam.Analytics.initData.eventInterval * 1000);

		Gaiam.Analytics.playPauseInterval = setInterval(function() {
			if (TVEngine.MediaPlayer.playing() == true) {

				$log(' analytics timeout PLAY Called!!!!!!!!!!!!!!!!!!!!!');
				//if(Gaiam.Analytics.analyticsData.events.length>=11){Gaiam.Analytics.analyticsData.events.shift()}
				Gaiam.Analytics.analyticsData.events.push({
					timestamp: Date.now(),
					name: "Playing"
				});
				Gaiam.Analytics.lastEventUpdate();
				Gaiam.Analytics.analyticsData.lastPlayState = "Playing";


			} else {
				$log(' analytics timeout NOTPLAYING Called!!!!!!!!!!!!!!!!!!!!!');
				Gaiam.Analytics.analyticsData.events.push({
					timestamp: Date.now(),
					name: "Paused"
				});
				Gaiam.Analytics.lastEventUpdate();
				Gaiam.Analytics.analyticsData.lastPlayState = "Paused";


			}

		}, 6000);

		//do a beacon update every 18 seconds
		Gaiam.Analytics.beaconUpdateInterval = setInterval(function() {
			$log('Gaiam Analytics beaconUpdate');
			Gaiam.Analytics.beaconUpdate();
		}, Gaiam.Analytics.initData.beaconInterval * 1000)

		return 'Set Intervals'

	},
	writeToAnalytics: function() {
		Gaiam.API.updateAnalytics(this.nid, this.analyticsToken, this.analyticsData);
	},

	beaconUpdate: function() {
		//need to update the position in our analytics object here

		//write it
		Gaiam.API.updateAnalytics(this.nid, this.analyticsToken, {
			'position': this.analyticsData.position,
			'lastPlayState': this.analyticsData.lastPlayState
		});
	},

	lastEventUpdate: function() {

		this.analyticsData.lastEventUpd = Date.now();
		return this.analyticsData.lastEventUpd
	}
};