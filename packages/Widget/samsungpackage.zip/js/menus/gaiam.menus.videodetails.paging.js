(function(TVEngine) {
    var menu = new TVEngine.Navigation.Menu("gaiam:videodetails:paging");
    menu.menuHandlesEvents();

    menu.currentPage = 0;

menu.unsetHandlers=function(){
  
}
menu.setHandlers=function() {

  $('#viddetails_page_indicators').on('mouseover','div',function() {
    _t = this;
    $log('_t is:', _t);
    // if(menu._focused && menu.currentIndex == $(this).index()) return;
    if (!menu._focused) {
      menu.focus();
    }
    thisIndex=$(this).index();
    $log('$this index is: '+ thisIndex);
    $("#viddetails_page_indicators > div").eq(thisIndex).addClass('focused');
     menu.currentPage = thisIndex;
    $log('currentindex is: '+ menu.currentPage);
     menu.setFocused();
     menu.trigger("newpage", menu.currentPage);
  });

  $('#viddetails_page_indicators').on('mouseout','div',function() {
    _t = this;
    $log('_t is:', _t);

    $log('$this index is: '+ $(this).index());
    $("#viddetails_page_indicators > div").eq(thisIndex).removeClass('focused');
 
    $log('currentindex is: '+menu.currentIndex)
    // menu.setFocus();
  });

    $('#viddetails_page_indicators').on('click','div',function() {

    $log('GOT A CLICK!')
  });

  };

    menu.onFocus = function() {
      this.currentPage = $("#viddetails_page_indicators > div.active").index();
      this.maxPage = $("#viddetails_page_indicators > div:visible").last().index();
      $log("PAGING MENU ON FOCUS ", this.currentPage, this.maxPage);
      this.setFocus();
    }

    menu.setFocus = function() {

      $("#viddetails_page_indicators > div").removeClass("focused active");
      $("#viddetails_page_indicators > div").eq(this.currentPage).addClass("focused");

    }

    menu.onBlur = function() {
      $log(" PAGING ON BLUR ");
       $("#viddetails_page_indicators > div").eq(this.currentPage).removeClass("focused").addClass("active");
    }

    menu.onRight = function() {
      if(this.currentPage < this.maxPage) {
        this.currentPage++; this.setFocus(); this.trigger("newpage", this.currentPage);
    
      }
    }

    menu.onLeft = function() {
      if(this.currentPage > 0) {
        this.currentPage--; this.setFocus(); this.trigger("newpage", this.currentPage);
      }
    }

    TVEngine.Navigation.addMenu(menu);
})(TVEngine);