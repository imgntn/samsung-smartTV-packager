(function(TVEngine) {
  var menu = new TVEngine.Navigation.Menu("gaiam:videogrid");
  menu.menuHandlesEvents();


  menu.currentPage = 0;
  menu.currentFocus = 0;

  menu.reset = function() {
    this.currentPage = 0;
    this.currentFocus = 0;
    this.setHandlers();
  }



  menu.setCurrentFocusByIndex = function(index) {
    var li = $(".videoGrid > ul li").eq(index);
    if (!li.length) return;
    this.currentPage = li.parent().index();
    this.currentFocus = index - (this.currentPage * 14);
    this.displayPages();
    this.setFocus();
  }



  menu.setHandlers = function() {
    this.unsetHandlers();
    var _t = this;

    //grid mouseovers
    $(".videoGrid").on('mouseover', 'li', function() {
      $log(" Got mouseover for li " + $(this).index() + ' at currentpage' + _t.currentPage);
      var index = $(this).index();
      $log('currentFocus is:' + menu.currentFocus)
      menu.setCurrentFocusByIndex(index + (menu.currentPage * 14));
      $log("Moused over an item");

    });
    //grid clicks
    $(".videoGrid").on('click', 'li', function() {

      $log('clicked an item');
      menu.onSelect();
    });

    //left arrow unbind
    $("#vidGridLeftArrow").off();

    //left arrow mouseovers
    $("#vidGridLeftArrow").on('mouseover', function() {
      $log('left arrow mouseover');
      $("#vidGridLeftArrow").addClass('focused')

    });

    $("#vidGridLeftArrow").on('mouseout', function() {
      $log('left arrow mouseout');
      $("#vidGridLeftArrow").removeClass('focused');

    });
    //left arrow clicks

    $("#vidGridLeftArrow").on('click', function() {
      $log('left arrow click');

      $log(" PAGING LEFT ")
      if (menu.currentPage > 0) {
        menu.currentPage--;
        menu.page();
      } else {
        $log('LAST PAGE CANT DO')
      }
    });


    //right arrow unbind
    $("#vidGridRightArrow").off();

    //right arrow mouseovers
    $("#vidGridRightArrow").on('mouseover', function() {
      $log('left arrow mouseover');
      $("#vidGridRightArrow").addClass('focused')

    });

    $("#vidGridRightArrow").on('mouseout', function() {
      $log('right arrow mouseout');
      $("#vidGridRightArrow").removeClass('focused');

    });
    //right arrow clicks
    $("#vidGridRightArrow").on('click', function() {
      $log('right arrow click');

      $log(" PAGING RIGHT ")
      if (menu.currentPage < menu.maxPages) {

        menu.currentPage++;
        menu.page(true);
      } else {
        $log('LAST PAGE CANT DO')
      }


    });



  }

  menu.unsetHandlers = function() {
    $(".videoGrid").off('mouseover', 'li');
    $(".videoGrid").off('click', 'li');
    $(".videoGridRightArrow").off('click');
    $(".videoGridLeftArrow").off('click');
  }



  menu.onFocus = function() {
    this.setFocus();
    this.maxPages = $(".videoGrid > ul").length - 1;
    $log('maxPages ' + this.maxPages);
    this.maxFocus = $(".videoGrid > ul").eq(this.currentPage).find("li").length - 1;

  }

  menu.onBlur = function() {
    $(".videoGrid li").removeClass("focused");
  }

  menu.setFocus = function() {
    $log(" SETTING FOCUS TO ", menu.currentFocus);
    $(".videoGrid li").removeClass("focused");
    $(".videoGrid > ul").eq(this.currentPage).find("li").eq(menu.currentFocus).addClass('focused');
    this.trigger("newfocus", this.currentPage * 14 + $(".videoGrid > ul").eq(this.currentPage).find("li").eq(menu.currentFocus).index());
  }

  menu.page = function(goingRight) {
    this.displayPages();
    if (goingRight) {

      this.currentFocus = this.currentFocus;
    } else {
      this.currentFocus = (this.maxFocus > 7) ? 6 : this.maxFocus;
    }
    this.trigger('newpage', {
      current: this.currentPage + 1,
      total: this.maxPages + 1
    })
    this.setFocus();
  }

  menu.displayPages = function() {

    left = this.currentPage - 1;
    right = this.currentPage + 1;

    $log(" page left: " + left + " current: " + this.currentPage + " right: " + right);

    if (left == 0) $(".videoGrid > ul").eq(0).removeClass("on blurred").addClass('off');
    else $(".videoGrid > ul").slice(0, left - 1).removeClass("on blurred").addClass('off');

    $(".videoGrid > ul").eq(left).addClass('left blurred').removeClass('off on');
    $(".videoGrid > ul").eq(this.currentPage).addClass('on').removeClass('left right blurred off');
    $(".videoGrid > ul").eq(right).addClass('right blurred').removeClass('left off on');
    $(".videoGrid > ul").slice(right + 1).removeClass("on blurred").addClass('off');
    $(".videoGrid > ul:lt(" + left + ")").find('li > img.boxart').attr('src', 'images/boxart_default.png');
    $(".videoGrid > ul:gt(" + right + ")").find('li > img.boxart').attr('src', 'images/boxart_default.png');

    $(".videoGrid > ul").each(function() {

      if ($(this).index() >= left && $(this).index() <= right) {
        $(this).find('img.boxart').each(function() {
    
          if ($(this).attr('src') != $(this).attr('data-imagesrc')) $(this).attr('src', $(this).attr('data-imagesrc'));
        })
      }
    })

    this.maxFocus = $(".videoGrid > ul").eq(this.currentPage).find("li").length - 1;
  }
  menu.onRight = function() {
    $log('this currentfocus: '+this.currentFocus)
     $log('this maxfocus: '+this.maxFocus)
      $log('this currentpage: '+this.currentPage)
      $log('this maxpage:' +this.maxPages)
  
    if (menu.currentFocus != 6 && menu.currentFocus != 13) {
      $log('in loop1')
      if(menu.currentFocus==menu.maxFocus){return}
      menu.currentFocus++;
      menu.setFocus();
    } 
  
    else if(
      this.currentPage == this.maxPages-1){
      $log('inloop4')
       this.currentPage++;
      this.page(true);
    menu.currentFocus=0;
    menu.setFocus();
    }
      else if (this.currentPage < this.maxPages) {
         $log('in loop3')
      $log(" PAGING RIGHT ")
      this.currentPage++;
      this.page(true);
    }
  }
  menu.onLeft = function() {
     $log('this currentfocus: '+this.currentFocus)
     $log('this maxfocus: '+this.maxFocus)
      $log('this currentpage: '+this.currentPage)
      $log('this maxpage:' +this.maxPages)
    if (menu.currentFocus != 0 && menu.currentFocus != 7) {
      menu.currentFocus--;
      this.setFocus();
    } else if (this.currentPage > 0) {
      $log(" PAGING LEFT ")
      this.currentPage--;
      this.page();
    }
  }
  menu.onUp = function() {
    if (menu.currentFocus < 6) {
      this.trigger("upfromtop", this.currentFocus);
    } else {
      this.currentFocus = this.currentFocus - 7;
      this.setFocus();
    }
  }

  menu.onDown = function() {
    if (menu.currentFocus >= 7 || this.maxFocus < 7) {
      //$log(" TRIGGERING DOWN FROM BOTTOM ");
      //   this.trigger("downfrombottom", this.currentFocus);
    } else if (this.currentFocus + 7 <= this.maxFocus) {
      this.currentFocus = this.currentFocus + 7;
      this.setFocus();
    }
  }

  menu.onSelect = function() {

    var idx = this.currentPage * 14 + $(".videoGrid > ul").eq(this.currentPage).find("li").eq(menu.currentFocus).index()
    this.trigger("selecteditem", idx);

    // TVEngine.StageManager.changeScene("videodetails")
  }

  TVEngine.Navigation.addMenu(menu);
})(TVEngine);