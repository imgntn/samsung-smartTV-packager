(function(TVEngine) {
  var menu = new TVEngine.Navigation.Menu("gaiam:verticalList");
  menu.menuHandlesEvents();
  menu.whichList = "recentSearchesTable";
  menu.step = null;
  menu.searchIndex = "";
  menu.currentSearchX = "";
  menu.currentSearchY = "";
  //get featured items to pull, so we can set the title etc. we're also getting this in the scene, but the variable is private and we're not storing it.  so, here.
  menu.featuredItemsDataStore = null;

  menu.firstKeyEntry = true;

  menu.reset = function() {

    menu.setHandlers();
  };

  menu.unsetHandlers = function() {
    $('#' + this.whichList + '').off()
  };

  menu.setHandlers = function() {
    Vmenu = TVEngine.Navigation.menus["gaiam:verticalList"];
    $('#' + this.whichList + '').on('mouseover', 'li', function() {
      if (Vmenu._focused && Vmenu.currentIndex == $(this).index()) return;
      // if (!menu._focused) {
      // menu.focus();
      // }

      // menu.currentIndex = $(this).index();
      // menu.setFocused();
      //$('#recentSearchesTable li').removeClass('focused')
      $log('#this is: ', $(this))
      $log('#this nextSibling x2 : ', $(this)[0].nextSibling.nextSibling)
      focusedDiv = $(this)[0];
      $(focusedDiv).css({
        'margin-top': '-20px',
        'margin-bottom': '4px'
      })
      // $(this).css('margin-top':'-13px')
      //hide the hr
      var hr = $(this)[0].nextSibling.nextSibling;
      $(hr).hide();
      //set margin on next item

      var nextLi = $(this)[0].nextSibling.nextSibling.nextSibling;
      $(nextLi).css({
        'margin-top': '22px'
      })
      $('#' + menu.whichList + ' li').removeClass('focused');
      $(this).addClass('focused');
      Vmenu.currentIndex= ($(this).index() - 1) / 2;
    });

    $('#' + this.whichList + '').on('mouseout', 'li', function() {
      hr = $(this)[0].nextSibling.nextSibling;
      $(hr).show();

      focusedDiv = $(this)[0];
      $(focusedDiv).css({
        'margin-top': '0px'
      })

      $(this).removeClass('focused');



    });

    $('#' + this.whichList + '').on('click', 'li', function() {

      $log('GOT A CLICK!', ($(this).index() - 1) / 2)

      $log('currentindex at click',Vmenu.currentIndex)
      Vmenu.trigger('onselect')
    });

  };


  menu.onFocus = function() {

    this.searchIndex = TVEngine.DataStore.get('searchIndex');
    this.currentSearchX = TVEngine.DataStore.get('currentSearchX');
    this.currentSearchY = TVEngine.DataStore.get('currentSearchY');
    $log('SEARCHINDEX IS: ', this.searchIndex);

    this.currentIndex = _.isNumber(this.currentIndex) ? this.currentIndex : 0;

    this.maxIndex = $("#" + this.whichList + " li").length - 1;
    this.setFocused();

    $("#" + this.whichList + " li").eq(this.currentIndex - 1).css({
      'margin-top': '0px'
    })
    $("#" + this.whichList + " li").eq(this.currentIndex).css({
      'margin-top': '-21px'
    })
    $("#" + this.whichList + " li").eq(this.currentIndex + 1).css({
      'margin-top': '22px'
    })
    $("#" + this.whichList + " hr").eq(this.currentIndex + 1).hide()


  }
  menu.onBlur = function() {
    $("#" + this.whichList + " li").removeClass('focused');
    $("#" + this.whichList + " li").eq(this.currentIndex).css({
      'margin-top': '0px'
    });
    $("#" + this.whichList + " li").eq(this.currentIndex + 1).css({
      'margin-top': '0px'
    });
    $("#" + this.whichList + " hr").eq(this.currentIndex + 1).show();

  }
  menu.setFocused = function() {
    $log('CURRENT FEATURED INDEX', this.currentIndex);
    $("#" + this.whichList + " li").removeClass('focused');
    $("#" + this.whichList + " li").eq(this.currentIndex).addClass('focused');
  }

  menu.onLeft = function() {

$('#recentSearchesTable').show();

  }
  menu.onUp = function() {
if (this.currentIndex<=7){
      $('#searchResultsTable').css({'margin-top':'0px'})
}
    if (this.currentIndex<=1){
  
       $("#" + this.whichList + " li").eq(this.currentIndex).css({
        'margin-top': '-21px'
      })
      $('.catSelectionUpArrowDiv').hide()
    }
    if (this.currentIndex > 0) {

if (this.currentIndex<=6){

      this.currentIndex--;
      this.setFocused();



      $("#" + this.whichList + " li").eq(this.currentIndex).css({
        'margin-top': '-20px'
      })
      $("#" + this.whichList + " li").eq(this.currentIndex + 1).css({
        'margin-top': '21px'
      })
      $("#" + this.whichList + " li").eq(this.currentIndex + 2).css({
        'margin-top': '0px'
      })
      $("#" + this.whichList + " hr").eq(this.currentIndex + 1).hide()
      $("#" + this.whichList + " hr").eq(this.currentIndex + 2).show()
    }
      
      else if (this.currentIndex>6){
  var currentTopMargin= $('#'+ this.whichList).css('margin-top');
  $log('currentMargin is: ', currentTopMargin);
  var nextMargin = parseInt(currentTopMargin) +62;
  $log('nextMargin is: ', nextMargin);
$('#'+ this.whichList).css({'margin-top':nextMargin+'px'});
 $('.catSelectionDownArrowDiv').show()


      $("#" + this.whichList + " li").eq(this.currentIndex-1).css({
        'margin-top': '-20px'
      })
      $("#" + this.whichList + " li").eq(this.currentIndex).css({
        'margin-top': '21px'
      })
      $("#" + this.whichList + " li").eq(this.currentIndex + 1).css({
        'margin-top': '0px'
      })
      $("#" + this.whichList + " hr").eq(this.currentIndex).hide()
      $("#" + this.whichList + " hr").eq(this.currentIndex + 1).show()


      this.currentIndex--;
      this.setFocused();
      }

    }
  }

  menu.onDown = function() {

    if (this.currentIndex < this.maxIndex) {
if (menu.currentIndex===0){
  $log('zeroindex')
  $('.catSelectionUpArrowDiv').show()
  
  if(this.whichList!=='recentSearchesTable'){
    $log('EMPTYING CONTAINER ON MENU FOCUS')
       $('#recentSearchesContainer').hide();
  }

    if(this.whichList=='recentSearchesTable'){
    $log('SHOWING CONTAINER ON MENU FOCUS')
       $('#recentSearchesContainer').show();
  }
}
      if (this.currentIndex < 6 ) {

        this.currentIndex++;
        this.setFocused();
        $("#" + this.whichList + " hr").eq(this.currentIndex).show()
        $("#" + this.whichList + " li").eq(this.currentIndex).css({
          'margin-top': '-20px'
        })
        $("#" + this.whichList + " li").eq(this.currentIndex - 1).css({
          'margin-top': '0px'
        })
        $("#" + this.whichList + " li").eq(this.currentIndex + 1).css({
          'margin-top': '21px'
        })
        $("#" + this.whichList + " hr").eq(this.currentIndex + 1).hide()
       
      }

else {
  var currentTopMargin= $('#'+ this.whichList).css('margin-top');
  $log('currentMargin is: ', currentTopMargin);
  var nextMargin = parseInt(currentTopMargin) -62;
  $log('nextMargin is: ', nextMargin);
$('#'+ this.whichList).css({'margin-top':nextMargin+'px'});
    this.currentIndex++;
    this.setFocused();
    $('.catSelectionUpArrowDiv').show()
           $("#" + this.whichList + " hr").eq(this.currentIndex).show()
        $("#" + this.whichList + " li").eq(this.currentIndex).css({
          'margin-top': '-20px'
        })
        $("#" + this.whichList + " li").eq(this.currentIndex - 1).css({
          'margin-top': '0px'
        })
        $("#" + this.whichList + " li").eq(this.currentIndex + 1).css({
          'margin-top': '21px'
        })
        $("#" + this.whichList + " hr").eq(this.currentIndex + 1).hide()
if (this.maxIndex==this.currentIndex){
  $('.catSelectionDownArrowDiv').hide()
}
    }


  }
}

  menu.onSelect = function() {
    this.trigger("selected", this.currentIndex);

  }

  menu.onReturn = function() {
    $log('EXIT Vertical List MENU!!!');
  }

  TVEngine.Navigation.addMenu(menu);
})(TVEngine);