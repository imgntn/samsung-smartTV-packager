(function(TVEngine) {
  var menu = new TVEngine.Navigation.Menu("gaiam:backmenu");
  menu.menuHandlesEvents();
  TVEngine.Navigation.addMenu(menu);
  var defaultImage, overImage;
  menu.init = function() {
    defaultImage = new Image();
    defaultImage.src = "images/back_button.png";

    overImage = new Image();
    overImage.src = "images/back_button_focus.png";
  }

  menu.setHandlers=function() {

  $('.backMenu').on('mouseover','img',function() {
        $(".backMenu > img").attr('src', overImage.src);
  });

  $('.backMenu').on('mouseout','img',function() {
   $(".backMenu > img").attr('src', defaultImage.src);
  });

  $('.backMenu').on('click','img',function() {
$log('backmenu button click back')
  TVEngine.StageHistory.back()
  });

  };


  menu.onFocus = function() {
    $(".backMenu > img").attr('src', overImage.src);
  }

  menu.onBlur = function() {
    $(".backMenu > img").attr('src', defaultImage.src);
  }

})(TVEngine);

