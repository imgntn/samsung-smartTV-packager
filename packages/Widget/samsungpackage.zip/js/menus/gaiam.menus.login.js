(function(TVEngine, window, undefined) {
  var menu = new TVEngine.Navigation.Menu("gaiam:login");

  menu.setTargets({
    username: "#usernameField",
    password: "#passwordField",
    signin: "#signinButton",


  });


  menu.items["username"] = {
    onUp: function() {
      backMenu.focus();
    },
    onRight:function(){
      menu.focus('password')
    },
    onDown: function() {
    TVEngine.Navigation.menus['gaiam:loginKeyboardMenu'].focus();
    },
    onFocus: function() {
      $log(" username ON FOCUS ")
      //remove active highlight
      $("#usernameField").removeClass("loginActive");
      $("#passwordField").removeClass("loginActive");

      //add focused highlight
      $("#usernameField").addClass("focused");
 
      inputfieldObject.whichInput = "username";

      if (inputfieldObject.lastUsername == "") {
        TVEngine.Navigation.menus['gaiam:loginKeyboardMenu'].setCurrentValue('');
      } else {
        TVEngine.Navigation.menus['gaiam:loginKeyboardMenu'].setCurrentValue(inputfieldObject.lastUsername)
      }



    },
    onBlur: function() {
      $("#usernameField").removeClass("focused");
      $("#usernameField").addClass("loginActive");
    },
    onMouseover: function() {
      menu.focus('username');
    },
    onSelect:function(){
      TVEngine.Navigation.menus['gaiam:loginKeyboardMenu'].focus();
    }

  }
  menu.items["password"] = {
    onUp: function() {
      menu.focus('username');
    },
    onDown: function() {
   TVEngine.Navigation.menus['gaiam:loginKeyboardMenu'].focus();
    },
      onLeft:function(){
      menu.focus('username')
    },
    onFocus: function() {
      $log(" password ON FOCUS ")
      //remove active highlight
       $("#usernameField").removeClass("loginActive");
        $("#passwordField").removeClass("loginActive");
        //add focus
      $("#passwordField").addClass("focused");

           inputfieldObject.whichInput = "password";


      if (typeof inputfieldObject.lastPassword === "undefined") {
        TVEngine.Navigation.menus['gaiam:loginKeyboardMenu'].setCurrentValue('');
      } else {
        TVEngine.Navigation.menus['gaiam:loginKeyboardMenu'].setCurrentValue(inputfieldObject.lastPassword)
      }



    },
    onBlur: function() {
      $("#passwordField").removeClass("focused");
       $("#passwordField").addClass("loginActive");

    },
    onMouseover: function() {
      menu.focus('password');
    },
    onSelect:function(){
      TVEngine.Navigation.menus['gaiam:loginKeyboardMenu'].focus();
    }
  }

  menu.items["signin"] = {
    onUp: function() {
  TVEngine.Navigation.menus['gaiam:loginKeyboardMenu'].focus();
    },
    onFocus: function() {
      $log(" signin ON FOCUS ")
      $("#signinButton").addClass("focused");
    },
    onBlur: function() {
      $("#signinButton").removeClass("focused");

    },
    onSelect: function() {
      submitButtonObject.trigger('select');
    },
    onMouseover: function() {
      menu.focus('signin');
    }
  }

  TVEngine.Navigation.addMenu(menu);
})(TVEngine, window);