(function(TVEngine, window, undefined) {
  var menu = new TVEngine.Navigation.Menu("gaiam:signup");

  menu.setTargets({
    signup: "#signupButton",



  });


  menu.items["signup"] = {
    onUp: function() {
      backMenu.focus();
    },
    onDown: function() {
     
    },
    onFocus: function() {
      $log(" signupButton ON FOCUS ")
      $("#signupButton").addClass("focused");
     


    },
    onBlur: function() {
      $("#signupButton").removeClass("focused");
    },
    onMouseover: function() {
      menu.focus('signup');
    },
    onSelect:function(){
    TVEngine.StageManager.changeScene('loginKeyboard')
    }

  }

  TVEngine.Navigation.addMenu(menu);
})(TVEngine, window);