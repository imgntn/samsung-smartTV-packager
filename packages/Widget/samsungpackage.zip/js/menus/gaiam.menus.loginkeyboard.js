(function(TVEngine) {
  var menu = new TVEngine.Navigation.Menu("gaiam:loginKeyboardMenu");
  menu.menuHandlesEvents();
  menu.currentValue = [];
  menu.shifted = false;
  menu.blink = true;
  menu.blinkInterval = null;
  menu.passwordMode = false;
  menu.showPassword = false;
  menu.focused = false;
  menu.ontextinput = true;
  menu.topRow = false;
  menu.bottomRow = false;

  menu.firstUsernameFocus = false;
  menu.whichSet = 0;

  menu.setPasswordMode = function(mode) {
    // $log(" SETTING PASSWORD MODE TO " + mode + " current: " + this.passwordMode);
    this.passwordMode = mode;
    this.renderKeyboardPage();
    if (this.passwordMode && !this.showPassword && $(".keyboard-current-value").attr("type") != "password") {
      var pwd = $(".keyboard-current-value").clone();
      pwd.attr("type", "password");
      $(".keyboard-current-value").replaceWith(pwd);
    } else {
      var pwd = $(".keyboard-current-value").clone();
      pwd.attr("type", "text");
      $(".keyboard-current-value").replaceWith(pwd);
    }
  }

  menu.setup = function(valTitle, valDesc, val) {
    valTitle = valTitle || "";
    valDesc = valDesc || "";
    $(".keyboard-value-title").html(valTitle);
    $(".keyboard-details").html(valDesc);
    this.originalValue = val;
    this.setCurrentValue(val);
  }
  menu.setCurrentValue = function(val) {
    val = val || "";
    this.currentValue = (val instanceof Array) ? val : val.split("");
    $("#inputTextInput").val(this.currentValue.join(""));

  }

  menu.setHandlers = function() {
    _t = this;
    $log('keyboardmenu sethandlers called')
    $("#keyboard td").off();
    $("#keyboard").on('mouseover', 'td', function() {
      if (!_t._focused) {
        _t.focus();
      }
      _t.setFocusOn(_t.getCellValue($(this)));
    });
    $("#keyboard").on('click', 'td', function(e) {

      var value = _t.getCellValue($(this));

      _t.lastfocus = this;
      //     _t.setFocusOn(_t.getCellValue($(this)));
      //   _t.onSelect();
      return true;
    })

  };


  menu.pages = {
    abc123: {
      primary: [
        ["A", "B", "C", "D", "E", "F", "G"],
        ["H", "I", "J", "K", "L", "M", "N"],
        ["O", "P", "Q", "R", "S", "T", "U"],
        ["V", "W", "X", "Y", "Z", "-", "_"], ],
      secondary: [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
        ["@", ".", 0]
      ]
    },
    "&%#?": {
      primary: [
        ["!", "?", "*", "#", "$", "%", "^"],
        ["&", ",", ":", ";", "'", "\"", "~"],
        ["-", "_", "{", "}", "[", "]", "|"],
        ["\\", "/", "+", "=", "<", ">", "`"], ],
      secondary: [
        [1,2,3],
        [4,5,6],
        [7,8,9],
        ["@", ".", "0"]
      ]
    },
    "åßñü": {
      primary: [
        ["à", "á", "â", "ã", "ä", "å", "æ"],
        ["è", "é", "ê", "ë", "ì", "í", "î"],
        ["ï", "ò", "ó", "ô", "õ", "ö", "ø"],
        ["œ", "ü", "ú", "û", "!!!", "ç", "ñ"], ],
      secondary: [
        ["ý", "ÿ","š"],
        ["ž","þ","ß"],
        ["+", "-","±"],
        ["@", ".", 0]
      ]
    }
  }


menu.resetValue = function() {
  this.currentValue = [];
}

menu.onFocus = function() {
  // $log(" Focus on keyboard ");
  var _t = this;
  this.focused = true;
  this.renderKeyboardPage();
  $('.loginFocus').css({'background-color':'transparent'})
  $('.loginFocus').eq(0).css({'background-color':'rgb(27,121,200)'})
  var letter = this.shifted ? "A" : "a";
  this.setFocusOn(letter)
  $("#inputTextDisplay").off();
  // $("#inputTextDisplay").on("click", function() {
  //   // $log("Clicked on Text Display, switching to input");
  //   _t.onTextInput();
  // });
  $("#inputTextInput").on('focus', function() {
    $("#keyboard td").removeClass('focused')
  })
  $("#inputTextInput").parent().off();
  // $("#inputTextInput").parent().on('submit', function() {
  //   $log(" GOT SUBMIT WITH CURRENT VaL", $("#inputTextInput").val())
  //   _t.trigger("onsave", $("#inputTextInput").val());
  //   return false;
  // })

  // this.onKeyboard();
  var _t = this;

  clearInterval(this.blinkInterval); // Make sure we only have one.
  this.blinkInterval = setInterval(function() {
    _t.blink = !! !_t.blink;
    // Set visibility instead of hide, so it keeps it block intact (letters would shift around otherwise)
    if (_t.blink) $(".blinky").css({
      visibility: "hidden"
    });
    else $(".blinky").css({
      visibility: "visible"
    });
  }, 300);
  this.renderCurrentValue();
  // Make sure this is done after redner
}
menu.onBlur = function() {
  if(this.whichSet!==0){$('.loginFocus').css({'background-color':'transparent'})}
   
  this.focused = false;
  this.setPasswordMode(false); // Do this after setting focused, so we don't render again.
  $(".keyboard-current-value").off();
  this.orignalValue = "";
}
menu.getCurrentFocus = function() {

}

menu.onRight = function() {
  // $log("Keyboard Menu on Right");
  this.switchTable(true)
}
menu.onLeft = function() {
  this.switchTable();
}
menu.switchTable = function(right) {
  if (right) next = $("#keyboard td.focused").next("td");
  else next = $("#keyboard td.focused").prev("td");
  if (next.length) this.setFocusOn(this.getCellValue($(next)));
  else {
    // get the current row
    var row = $("#keyboard td.focused").parent();

    // Find the next table
    if (right) var nextTable = row.parents("table").eq(0).next("table");
    else var nextTable = row.parents("table").eq(0).prev("table");

    // $log("NEXT TABLE: ", nextTable)
    // Is there a next table?
    if (nextTable.length) {
      // find the current row index.
      var index = row.index();
      // Get the rows in the table (we're kind of memoizing the result here)
      var rows = nextTable.find("tr");
      // If the next table has fewer rows then the current index, we need to find the last row
      if (index > rows.length - 1) index = rows.last().index();

      // Get the element (first td going right, last td going left)
      if (right) elm = rows.eq(index).find("td").first();
      else elm = rows.eq(index).find("td").last();
      this.setFocusOn(this.getCellValue(elm));
    }
  }
}
menu.switchRow = function(up) {
  var index = $("#keyboard td.focused").index(),
    next = null;
  if (up) next = $("#keyboard td.focused").parent().prev("tr"); // Going up get the previous row
  else next = $("#keyboard td.focused").parent().next("tr"); // Going down get the next row
  if (!next.length) return;
  var cells = next.find("td");
  if (index > cells.length - 1) index = cells.last().index();
  this.setFocusOn(this.getCellValue(cells.eq(index)));
}

menu.getCellValue = function(item) {
  var img = $(item).find("img");
  if (img.length) return img.attr("data-value");
  // return $(item).attributes.value;
  // $log('item is ', item.attributes)
  //return item[0].attributes[0].value
  //$log('item.attr.val is: '+ item[0].attributes[0].value)
  //$log('item.text is: '+ item.text)
  return item[0].textContent
}
menu.onUp = function() {
  if (this.topRow == true) {
    TVEngine.Navigation.menus['gaiam:login'].focus('username');
  } else {
    this.switchRow(true);
  }

}

menu.onDown = function() {
  if (this.bottomRow == true) {
    TVEngine.Navigation.menus['gaiam:login'].focus('signin');
  } else {
    this.switchRow();
  }

}

menu.onSelect = function() {

  var text = this.getCellValue($("td.focused"));
  // $log(" Keyboard selected, text: " + text.toLowerCase());
  switch (text.toLowerCase()) {

    case "shift":
      // $log(" Shifting ");

      this.shifted = !this.shifted;
         if (this.shifted==true){
      $('.loginFocus').eq(3).children().children().eq(2).css({'background-color':'rgb(27,121,200)'});
   }
   else{
    $('.loginFocus').eq(3).children().children().eq(2).css({'background-color':'transparent'});
   }
      if(this.whichSet==0){

            this.renderKeyboardPage();
      }
        else if(this.whichSet==1){
         this.renderKeyboardPage("&%#?");}
          else if(this.whichSet==2){
            this.renderKeyboardPage("åßñü");
          }
  
      break;
    case "abc123":
     $('.loginFocus').css({'background-color':'transparent'})
    $('.loginFocus').eq(0).css({'background-color':'rgb(27,121,200)'})
      this.renderKeyboardPage("abc123");
      this.whichSet = 0;
      $log("this.whichSet",this.whichSet)
      break;
    case "&%#?":
    $('.loginFocus').css({'background-color':'transparent'})
     $('.loginFocus').eq(1).css({'background-color':'rgb(27,121,200)'})
      this.renderKeyboardPage("&%#?");
      this.whichSet = 1;
        $log("this.whichSet",this.whichSet)
      break;
    case "åßñü":
    $('.loginFocus').css({'background-color':'transparent'})
    $('.loginFocus').eq(2).css({'background-color':'rgb(27,121,200)'})
      this.renderKeyboardPage("åßñü");
      this.whichSet = 2;
        $log("this.whichSet",this.whichSet)
      break;
    case "> spc":
      this.addChar(" ");
      break;
    case "< del":
      this.deleteChar();
      break;
      // case "left":
      //   if (this.currentIndex > 0) {
      //     this.currentIndex--;
      //     $log(" SETTING CURRENT INDEX TO " + this.currentIndex );
      //     $("#inputTextInput").caret(this.currentIndex, this.currentIndex);
      //     this.renderCurrentValue();
      //   }
      //   break;
      // case "right":
      //   if (this.currentIndex < this.currentValue.length) {
      //     this.currentIndex++;
      //     $("#inputTextInput").caret(this.currentIndex, this.currentIndex);
      //     this.renderCurrentValue();
      //   }
      //   break;
    case 'show pass':
      this.showPassword = true;
      $("td.showPass").text("hide pass");
      this.renderCurrentValue();
      break;
    case 'hide pass':
      this.showPassword = false;
      $("td.showPass").text("show pass");
      this.renderCurrentValue();
      break;
    case "cancel":
      this.currentValue = [];
      this.trigger('onsave', this.originalValue);
      break;
    case "save":
      this.trigger("onsave", this.currentValue.join(""));
      break;
    default:
      this.addChar(text);
      break;
  }
}
menu.addChar = function(s) {
  // $log(" Adding char at index: " + this.currentIndex, this.currentValue );
  this.currentValue = this.currentValue instanceof Array ? this.currentValue : []; // Validate these are correct
  this.currentValue.push(s);
  this.renderCurrentValue();

}
menu.renderCurrentValue = function() {

  if (this.passwordMode && !this.showPassword && $(".keyboard-current-value").attr("type") != "password") {
    var pwd = $(".keyboard-current-value").clone();
    pwd.attr("type", "password");
    $(".keyboard-current-value").replaceWith(pwd);
  } else if (this.passwordMode && this.showPassword && $(".keyboard-current-value").attr("type") == "password") {
    var pwd = $(".keyboard-current-value").clone();
    pwd.attr("type", "text");
    $(".keyboard-current-value").replaceWith(pwd);
  }
  $("#inputTextInput").val(this.currentValue.join(""));
  pushValue = $("#inputTextInput").val();
  $log('pushvalue is: ' + pushValue);
  $log('inputvalue is: ' + $("#inputTextInput").val());

  inputfieldObject.trigger('change', pushValue);


  // $("#inputTextDisplay").html(items.join(""));
}
menu.deleteChar = function() {
  var string = this.currentValue.join("");
  this.currentValue = string.slice(0, -1).split("");
  this.renderCurrentValue();
}

menu.setFocusOn = function(text) {

  // $log(" Selector: " + "#keyboard td:contains("+text+"), #keyboard td > img[data-value='"+text+"']")
  var item = $("#keyboard td:contains(" + text + ")").filter(function() {
    return ($(this).text() == text || $(this).attr("data-value") == text);
  });
  if (!item.length) {
    item = $("#keyboard td > img").filter(function() {
      return $(this).attr('data-value') == text;
    })
    if (!item.length) return;
    else item = item.parent();
  }

  $log('item here is: ', item)
  $log('item attr is: ', item[0].attributes[0].value)


  $("#keyboard td div").removeClass("focused");
  $("#keyboard td").removeClass("focused");
  $(item).addClass("focused");
  $(item[0].children[0]).addClass('focused');
  if ($(item[0].children).length == 0) {
    $(item).addClass("loginFocus");
  }

  item.focus();
  if ($("#keyboard td.focused").parent().children().eq(0).text() == "a" 
    || $("#keyboard td.focused").parent().children().eq(0).text() == "A" 
    || $("#keyboard td.focused").parent().children().eq(0).text() == "!"
    || $("#keyboard td.focused").parent().children().eq(0).text() == "à"
     || $("#keyboard td.focused").parent().children().eq(0).text() == "À") {
    $log('TOP ROW')
    menu.topRow = true;
    $log('Menu TopRow:', menu.topRow)
  } else {
    menu.topRow = false;
  }

  if ($("#keyboard td.focused").parent().children().eq(0).text() == "v" || $("#keyboard td.focused").parent().children().eq(0).text() == "\\"
    || $("#keyboard td.focused").parent().children().eq(0).text() == "V" || $("#keyboard td.focused").parent().children().eq(0).text() == "Œ" || $("#keyboard td.focused").parent().children().eq(0).text() == "œ") {
    $log('Bottom ROW')
    menu.bottomRow = true;
    $log('Menu Bottom Row:', menu.bottomRow)
  } else {
    menu.bottomRow = false;
  }




}


menu.renderKeyboardPage = function(pageName, destination) {
  // $log(" Rendering Keyboard Page ");
  destination = destination || "#keyboard";
  pageName = pageName || "abc123";
  var page = this.pages[pageName];
  if (!page) {
    $error("Tried to switch keyboard to invalid page, " + pageName);
    return;
  }
  var primary = $(destination).find(".keyboard-primary");
  primary.empty().append("<tr></tr><tr></tr><tr></tr><tr></tr>");

  var secondary = $(destination).find(".keyboard-secondary");
  secondary.empty().append("<tr></tr><tr></tr><tr></tr><tr></tr>");

  $(".keyboard-switches td.showPass").parent().remove();
  if (this.passwordMode) {
    // $log(" <<< IN PASSWORD MODE >>>");
    var text = (this.showPassword) ? "hide pass" : "show pass";
    $(".keyboard-switches tr").eq(1).after($('<tr><td class="showPass">' + text + '</td></tr>'));
  } else {
    // $log("<<< NOT IN PASSWORD MODE >>>");
  }
  var _t = this;
  for (var i = 0; i < 4; i++) {
    _.each(page.primary[i], function(letter) {
      if (_t.shifted) letter = letter.toUpperCase();
      else letter = letter.toLowerCase();
      primary.find("tr").eq(i).append($("<td data-value='" + letter + "'><div class='full-circle-login'>" + letter + "</div></td>"));
    });
    _.each(page.secondary[i], function(letter) {
      secondary.find("tr").eq(i).append($("<td data-value='" + letter + "'><div class='full-circle-login'>" + letter + "</div></td>"));
    });
  }
  var _t = this;
  // $log(" Which page? " + pageName)

  $("#keyboard td").off("click");
  $("#keyboard td").on("click", function(e) {
    // $log(" Got TD Event: " + e);
    _t.setFocusOn(_t.getCellValue($(e.target)));
    _t.onSelect();
  });
}, TVEngine.Navigation.addMenu(menu);
})(TVEngine);