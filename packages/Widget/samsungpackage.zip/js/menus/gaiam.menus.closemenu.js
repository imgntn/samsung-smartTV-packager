(function(TVEngine) {
    var menu = new TVEngine.Navigation.Menu("gaiam:closemenu");
    menu.menuHandlesEvents();
    TVEngine.Navigation.addMenu(menu);
    var defaultImage, overImage;
    menu.init = function() {
      defaultImage = new Image();
      defaultImage.src = "images/close_button.png";
      overImage = new Image();
      overImage.src = "images/close_button_focus.png";
    }

    menu.setHandlers=function() {

  $('.closeMenu').on('mouseover','img',function() {
        $(".closeMenu > img").attr('src', overImage.src);
        $log('closemenu over')
  });

  $('.closeMenu').on('mouseout','img',function() {
 $(".closeMenu > img").attr('src', defaultImage.src);
  });

    $('.closeMenu').on('click','img',function() {

  showAndHidePanes();
  });

  };

    menu.onBlur = function() {
       $(".closeMenu > img").attr('src', defaultImage.src);
    }

})(TVEngine);
