(function(TVEngine) {
    var menu = new TVEngine.Navigation.Menu("gaiam:videoplayback:bottomtabs");
    menu.menuHandlesEvents();

    menu.currentIndex = 0;

  menu.setHandlers=function() {
  $('.bottomtabnav').on('mouseover','div:visible',function() {
        $log('CURRENTINDEX IS: '+ menu.currentIndex)
      $log('$THIS INDEX IS: '+ $(this).index())
      menu.currentIndex = $(this).index();
      $log(' NEW CURRENTINDEX IS: '+ menu.currentIndex)
    $log('BOTTOMPLAYBACK MOUSEOVER')
    $(".bottomtabnav  > div").eq(menu.currentIndex).addClass("focused");
  
  });


    $('.bottomtabnav').on('mouseout','div',function() {

    $log('BOTTOMPLAYBACK  MOUSEOUT!')
       $(".bottomtabnav  > div").removeClass("focused");

  });

    $('.bottomtabnav').on('click','div',function() {

    $log('BOTTOMPLAYBACK  CLICK!')
  menu.trigger("selecteditem", $(".bottomtabnav > div").eq(menu.currentIndex).attr('data-action'));
  });

  };


    menu.setFocus = function() {
      $(".bottomtabnav  > div").removeClass("focused");
      $(".bottomtabnav  > div:visible").eq(this.currentIndex).addClass("focused");
    }

    menu.onBlur = function() {
       $(".bottomtabnav  > div").removeClass("focused");
       
    }

    // menu.onRight = function() {
    //     $log('maxpage:' +this.maxPage);
    //       if(this.currentIndex < this.maxPage) {
    //         this.currentIndex++; this.setFocus();
    //       }
    //     }
    //     menu.onLeft = function() {
    // 	  $log("on left")
    //       if(this.currentIndex > 0) {
    //         this.currentIndex--; this.setFocus();
    //       }
    
    //     }

    menu.onSelect = function() {
      this.trigger("selecteditem", $(".bottomtabnav > div:visible").eq(this.currentIndex).attr('data-action'));
    }

    TVEngine.Navigation.addMenu(menu);
})(TVEngine);