(function(TVEngine) {
	var menu = new TVEngine.Navigation.Menu();
	menu.menuHandlesEvents();
	
	menu.name = "simpleapp:mainmenu";
	menu.step = null;
	
	menu.onFocus = function() {
	  this.currentIndex = _.isNumber(this.currentIndex) ? this.currentIndex : 0;
	  this.maxIndex = $("#videos > div").length - 1;
	  this.step = this.step || $("#videos > div").eq(0).outerWidth(true);
    this.setFocused();
	}
	menu.setFocused = function() {
	  $("#videos > div").removeClass('focused');
	  $("#videos > div").eq(this.currentIndex).addClass('focused');	  
	}
	menu.onLeft = function() {
		if(this.currentIndex > 0 )  {
		  this.currentIndex--;
		  $("#videos").animate({ left: '+='+this.step });
		  this.setFocused();
		}
	}
	
	
	menu.onRight = function() {
	  if(this.currentIndex < this.maxIndex )  {
		  this.currentIndex++;
		  $("#videos").animate({ left: '-='+ this.step });
		  this.setFocused();
		}
	}
	
	menu.onSelect = function() {
	  this.trigger("selected", this.currentIndex);
	}
	
	menu.defaultMenu = true;
	TVEngine.Navigation.addMenu(menu);
})(TVEngine);