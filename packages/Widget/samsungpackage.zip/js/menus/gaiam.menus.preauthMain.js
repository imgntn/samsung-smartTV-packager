(function(TVEngine, window, undefined) {
    var menu = new TVEngine.Navigation.Menu("gaiam:preauthMainMenu");

    menu.setTargets({
        featured: "#preauth-bottom-featured-nav",
        categories: "#preauth-bottom-categories-nav",
        search: "#preauth-bottom-search-nav",
        login: "#preauth-bottom-login-nav",

    });

    menu.setFeaturedOnly = function(featuredOnly) {
        this.featuredOnly = featuredOnly;
    }
    menu.items["featured"] = {
        onRight: function() {
            //  $log(" FEATURED ON RIGHT ")
            if (!this.featuredOnly) menu.focus('categories');
        },
        onFocus: function() {
            $("#preauth-bottom-featured-nav").addClass("focused");
        },
        onBlur: function() {
            $("#preauth-bottom-featured-nav").removeClass("focused");
        },
        onUp: function() {
            TVEngine.Navigation.menus['gaiam:featured'].focus();
        },
        onMouseover: function() {

            menu.focus('featured');
        }
    }
    menu.items["categories"] = {
        onRight: function() {
            menu.focus('search');
        },
        onLeft: function() {
            menu.focus("featured")
        },
        onFocus: function() {
            $log(" CATEGORIES ON FOCUS ")
            $("#preauth-bottom-categories-nav").addClass("focused");
            $('#preauth-bottom-featured-nav').removeClass('focused').removeClass('focusedblue');
        },
        onBlur: function() {
            $("#preauth-bottom-categories-nav").removeClass("focused");
        },
        onUp: function() {
            TVEngine.Navigation.menus['gaiam:featured'].focus();
        },
        onMouseover: function() {

            menu.focus('categories');
        }
    }

    menu.items["search"] = {
        onRight: function() {
            menu.focus('login');
        },
        onLeft: function() {
            menu.focus("categories")
        },
        onFocus: function() {
            $("#preauth-bottom-search-nav").addClass("focused");
            $('#preauth-bottom-featured-nav').removeClass('focused').removeClass('focusedblue');
        },
        onBlur: function() {
            $("#preauth-bottom-search-nav").removeClass("focused");
        },
        onUp: function() {
            TVEngine.Navigation.menus['gaiam:featured'].focus();
        },
        onMouseover: function() {

            menu.focus('search');
        }
    }
    menu.items["login"] = {
        onLeft: function() {
            menu.focus("search")
        },
        onFocus: function() {
            $("#preauth-bottom-login-nav").addClass("focused");
            $('#preauth-bottom-featured-nav').removeClass('focused').removeClass('focusedblue');
        },
        onBlur: function() {
            $("#preauth-bottom-login-nav").removeClass("focused");
        },
        onUp: function() {
            TVEngine.Navigation.menus['gaiam:featured'].focus();
        },
        onMouseover: function() {

            menu.focus('login');
        }
    }



    TVEngine.Navigation.addMenu(menu);
})(TVEngine, window);