(function(TVEngine) {
    var menu = new TVEngine.Navigation.Menu("gaiam:morevideos");
    menu.menuHandlesEvents();
    menu.step = null;
    menu.config = {
      maxSlot: 4
    }
    menu.lastSelectedIndex=0;

menu.setHandlers=function() {
  $('#moreVideosHolder').off();
  $('#moreVideosHolder').on('mouseover','div',function() {
   // if(menu._focused && menu.currentIndex == $(this).index()) return;
 
    //menu.currentIndex = _.isNumber(menu.currentIndex) ? menu.currentIndex : 0;
       if (!menu._focused) {
      menu.focus();
  }
$log('menucurrentindex: ' + menu.currentIndex)
     $log('menucurrentindex: ' + menu.currentIndex)
       
    menu.currentIndex = $(this).index();
  //    $(".morevideos-list > div").eq(menu.currentIndex).addClass('focused');
       menu.trigger("newfocus", menu.currentIndex);
    menu.setFocused();
  });

   $('#moreVideosHolder').on('mouseout','div',function() {
    //     $(".morevideos-list > div").removeClass('focused');
   });

    $('#moreVideosHolder').on('click','div',function() {

    $log('GOT A CLICK!')
 menu.onSelect();
  });

  };


    menu.onFocus = function() {
      this.currentIndex = _.isNumber(this.currentIndex) ? this.currentIndex : 0;
      this.maxIndex = $(".morevideos-list > div").length - 1;
      this.setFocused();
     
    }

    menu.reset = function ()  {
      this.currentIndex = null;
      this.slotIndex = 0;
    }

    menu.onBlur = function() {
      $(".morevideos-list > div").removeClass('focused');
    }

    menu.setFocused = function() {
      $(".morevideos-list > div").removeClass('focused');
      $(".morevideos-list > div").eq(this.currentIndex).addClass('focused');
      this.trigger("newfocus", this.currentIndex);
    }


    menu.onLeft = function() {
        if(this.currentIndex!==-1){
                if(this.currentIndex > 0) {
        if(this.slotIndex ==  0 && this.currentIndex > 0) {
            $("#moreVideosHolder").css({
              left: '+=' + $("#moreVideosHolder > div").eq(0).outerWidth(true)
            })
          } else {
            this.slotIndex--;
        }
        this.currentIndex--;
        this.setFocused();
      }
        }

    }

    menu.onRight = function() {
      if(this.currentIndex!==-1){
        if(this.currentIndex < this.maxIndex )  {
          if(this.slotIndex == this.config.maxSlot) {
            $("#moreVideosHolder").css({
              left: '-='+ $("#moreVideosHolder > div").eq(0).outerWidth(true)
            })
          } else {
            this.slotIndex++;
          }
          this.currentIndex++;
          this.setFocused();
        }
      }
      
    }

    menu.onUp=function(){
      this.lastSelectedIndex=this.currentIndex;
      this.currentIndex=-1;
      $log('MOREVIDEOSBUTTON FOCUSED');
       $(".morevideos-list > div").removeClass('focused');
       $('#bottomMoreVideosTab').css({'background-color':'#61b14c'})
      $('#moreVideosDiv').css({'border-top':'5px solid #61b14c'}) 
    }

    menu.onDown=function(){
      $log('AWAY FROM MOREVIDEOSBUTTON')
    $('#bottomMoreVideosTab').css({'background-color':'#1d8ed3'})
    $('#moreVideosDiv').css({'border-top':'5px solid #1d8ed3'}) 
    this.currentIndex=this.lastSelectedIndex;
      menu.focus()
    }

    menu.onSelect = function() {
      this.trigger("selected", this.currentIndex);
    }

    TVEngine.Navigation.addMenu(menu);
})(TVEngine);