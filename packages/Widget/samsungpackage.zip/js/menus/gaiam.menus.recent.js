(function(TVEngine) {
    var menu = new TVEngine.Navigation.Menu("gaiam:recent");
    menu.menuHandlesEvents();
    menu.step = null;
    menu.config = {
      maxSlot: 4
    }

menu.setHandlers=function() {
  $('#recent').off();
  $('#recent').on('mouseover','div',function() {
    if(menu._focused && menu.currentIndex == $(this).index()) return;
    if (!menu._focused) {
      menu.focus();
    }
    menu.currentIndex = $(this).index();
    menu.setFocused();
  });

    $('#recent').on('click','div',function() {

    $log('GOT A CLICK!')
 menu.onSelect();
  });

  };


    menu.onFocus = function() {
      this.currentIndex = _.isNumber(this.currentIndex) ? this.currentIndex : 0;
      this.maxIndex = $(".recent-list > div").length - 1;
      this.setFocused();
    }

    menu.reset = function ()  {
      this.currentIndex = null;
      this.slotIndex = 0;
    }

    menu.onBlur = function() {
      $(".recent-list > div").removeClass('focused');
    }

    menu.setFocused = function() {
      $(".recent-list > div").removeClass('focused');
      $(".recent-list > div").eq(this.currentIndex).addClass('focused');
      this.trigger("newfocus", this.currentIndex);
    }


    menu.onLeft = function() {
      if(this.currentIndex > 0) {
        if(this.slotIndex ==  0 && this.currentIndex > 0) {
            $("#recent").css({
              left: '+=' + $("#recent > div").eq(0).outerWidth(true)
            })
          } else {
            this.slotIndex--;
        }
        this.currentIndex--;
        this.setFocused();
      }
    }

    menu.onRight = function() {
      if(this.currentIndex < this.maxIndex )  {
          if(this.slotIndex == this.config.maxSlot) {
            $("#recent").css({
              left: '-='+ $("#recent > div").eq(0).outerWidth(true)
            })
          } else {
            this.slotIndex++;
          }
          this.currentIndex++;
          this.setFocused();
        }
    }

    menu.onSelect = function() {
      this.trigger("selected", this.currentIndex);
    }

    TVEngine.Navigation.addMenu(menu);
})(TVEngine);