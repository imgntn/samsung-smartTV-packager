(function(TVEngine) {
    var menu = new TVEngine.Navigation.Menu("gaiam:videodetails:bottomtabs");
    menu.menuHandlesEvents();

    menu.currentIndex = 0;

menu.setHandlers=function() {

  $('#videodetails_nav').on('mouseover','div',function() {
    _t = this;
    $log('_t is:', _t);
    // if(menu._focused && menu.currentIndex == $(this).index()) return;
    if (!menu._focused) {
      menu.focus();
    }
    thisIndex=$(this).index();
    $log('$this index is: '+ $(this).index());
     $(".bottomtabnav > div").removeClass('focused active')
    $(".bottomtabnav > div").eq($(this).index()).addClass('focused')
   menu.currentIndex = thisIndex;
    $log('currentindex is: '+ menu.currentIndex);
    // menu.setFocus();
  });

  $('#videodetails_nav').on('mouseout','div',function() {
    _t = this;
    $log('_t is:', _t);
    // if(menu._focused && menu.currentIndex == $(this).index()) return;
    if (!menu._focused) {
      menu.focus();
    }
    $log('$this index is: '+ $(this).index());
    $(".bottomtabnav > div").eq($(this).index()).removeClass('focused active')
 
    $log('currentindex is: '+menu.currentIndex)
    // menu.setFocus();
  });

    $('#videodetails_nav').on('click','div',function() {

    $log('GOT A CLICK!')
 menu.trigger("selecteditem", $(".bottomtabnav > div").eq(menu.currentIndex).attr('data-action'));
  });

  };
    menu.onFocus = function() {
      $log(this.name + " on Focus");
      
      this.setFocus();
      this.maxPage = $(".bottomtabnav > div:visible").last().index();
    }

    menu.setFocus = function() {
      $(".bottomtabnav  > div").removeClass("focused");
      $(".bottomtabnav  > div:visible").eq(this.currentIndex).addClass("focused");
    }

    menu.onBlur = function() {
       $(".bottomtabnav  > div").removeClass("focused");
    }

    menu.onRight = function() {
    
      if(this.currentIndex < this.maxPage) {
        this.currentIndex++; this.setFocus();
      }
    }
    menu.onLeft = function() {
      if(this.currentIndex > 0) {
        this.currentIndex--; this.setFocus();
      }
    }

    menu.onSelect = function() {
      this.trigger("selecteditem", $(".bottomtabnav > div:visible").eq(this.currentIndex).attr('data-action'));
    }
    TVEngine.Navigation.addMenu(menu);
})(TVEngine);