(function(TVEngine, window, undefined) {
  var menu = new TVEngine.Navigation.Menu("gaiam:trickplay");

  menu.setTargets({
    rewind: "#trickPlayRW",
    //crap name but its the truth :)
    play: "#trickPlayPlay",
    pause: "#trickPlayPause",
    fastforward: "#trickPlayFF",


  });
// a flag so we can toggle which button is in the middle
  menu.playorpause = "pause";

  //get the menus that we use to change
  var closemenu = TVEngine.Navigation.getMenu("gaiam:closemenu");
  var tabMenu = TVEngine.Navigation.getMenu("gaiam:videoplayback:bottomtabs"); 
  var backMenu = TVEngine.Navigation.getMenu("gaiam:backmenu"); //close menu

  menu.items["rewind"] = {
    onLeft: function() {
      backMenu.focus();
    },

    onRight: function() {
      if (menu.playorpause == "play") {
        menu.focus('play');
      } else if (menu.playorpause == "pause") {
        menu.focus('pause');
      }

    },
    onDown: function() {

tabMenu.focus()
    },
    onFocus: function() {
      $log(" rewind ON FOCUS ")

      $("#trickPlayRW").addClass("focused");
    },
    onBlur: function() {
      $("#trickPlayRW").removeClass("focused");
    },
    onMouseover: function() {
      menu.focus('rewind');
    },
    onSelect: function(){
      TVEngine.KeyHandler.trigger('keyhandler:onRW');
    } ,

  }
  menu.items["play"] = {
    onLeft: function() {
      menu.focus('rewind');
    },
    onRight: function() {
      menu.focus('fastforward');
    },

    onDown: function() {
tabMenu.focus()
    },
    onFocus: function() {
      $log(" play ON FOCUS ")
      $("#trickPlayPlay").addClass("focused");

    },
    onBlur: function() {
      $("#trickPlayPlay").removeClass("focused");

    },
    onMouseover: function() {
      menu.focus('play');
    },
    onSelect: function() {
      TVEngine.KeyHandler.trigger('keyhandler:onPlay');
      menu.playorpause = "pause"
      $('#trickPlayPlay').hide();
       $('#trickPlayPause').show();
        menu.focus('pause');
    }
  }

  menu.items["pause"] = {
    onLeft: function() {
      menu.focus('rewind');
    },
    onDown: function() {
tabMenu.focus()
    },
    onFocus: function() {
      $log(" pause ON FOCUS ")
      $("#trickPlayPause").addClass("focused");



    },
    onRight: function() {
      menu.focus('fastforward');
    },
    onBlur: function() {
      $("#trickPlayPause").removeClass("focused");

    },
    onMouseover: function() {
      menu.focus('pause');
    },
    onSelect: function() {
       TVEngine.KeyHandler.trigger('keyhandler:onPause');
      menu.playorpause = "play"
       $('#trickPlayPause').hide();
        $('#trickPlayPlay').show();
          menu.focus('play');
    }
  }

  menu.items["fastforward"] = {
    onLeft: function() {
      if (menu.playorpause == "play") {
        menu.focus('play');
      } else if (menu.playorpause == "pause") {
        menu.focus('pause');
      }
    },
    onDown:function(){
 tabMenu.focus()
    },
    onFocus: function() {
      $log(" fastforward ON FOCUS ")
      $("#trickPlayFF").addClass("focused");
    },
    onBlur: function() {
      $("#trickPlayFF").removeClass("focused");
    },
    onSelect: function() {
      TVEngine.KeyHandler.trigger('keyhandler:onFF');

    },
    onMouseover: function() {
      menu.focus('fastforward');
    },
  onRight:function(){
if(TVEngine.Platforms.platformName()=="lg"){
  launchQuickMenu();
}
    },
  }

  TVEngine.Navigation.addMenu(menu);
})(TVEngine, window);