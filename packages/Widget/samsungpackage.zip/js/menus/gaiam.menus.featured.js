(function(TVEngine) {
    var menu = new TVEngine.Navigation.Menu("gaiam:featured");
    menu.menuHandlesEvents();
    menu.step = null;
    menu.config = {
      maxSlot: 4
    }
menu.whichMenu='main';
menu.setHandlers=function() {
  $('#featured').off();
  $('#featured').on('mouseover','div',function() {
    if(menu._focused && menu.currentIndex == $(this).index()) return;
    if (!menu._focused) {
      menu.focus();
    }
    menu.currentIndex = $(this).index();
    menu.setFocused();
  });

    $('#featured').on('click','div',function() {
     menu.trigger("onselect", menu.currentIndex);
   
    $log('GOT A CLICK!',  menu.currentIndex)

  });

  };


    menu.onFocus = function() {
      this.currentIndex = _.isNumber(this.currentIndex) ? this.currentIndex : 0;
      this.maxIndex = $(".featured-list > div").length - 1;
      this.setFocused();
    }

    menu.reset = function ()  {
      this.currentIndex = null;
      this.slotIndex = 0;
    }

    menu.onBlur = function() {
      $(".featured-list > div").removeClass('focused');
    }

    menu.setFocused = function() {
      $(".featured-list > div").removeClass('focused');
      $(".featured-list > div").eq(this.currentIndex).addClass('focused');
      this.trigger("newfocus", this.currentIndex);
    }


    menu.onLeft = function() {
      if(this.currentIndex > 0) {
        if(this.slotIndex ==  0 && this.currentIndex > 0) {
            $("#featured").css({
              left: '+=' + $("#featured > div").eq(0).outerWidth(true)
            })
          } else {
            this.slotIndex--;
        }
        this.currentIndex--;
        this.setFocused();
      }
    }

    menu.onRight = function() {
      if(this.currentIndex < this.maxIndex )  {
          if(this.slotIndex == this.config.maxSlot) {
            $("#featured").css({
              left: '-='+ $("#featured > div").eq(0).outerWidth(true)
            })
          } else {
            this.slotIndex++;
          }
          this.currentIndex++;
          this.setFocused();
        }
    }

    menu.onSelect = function() {
      this.trigger("selected", this.currentIndex);
    }

    menu.onDown=function(){
      if(menu.whichMenu=='main'){
         TVEngine.Navigation.menus['gaiam:mainmenu'].focus();
      }
      else{
            TVEngine.Navigation.menus['gaiam:preauthMainMenu'].focus();
      }
       
 
    }

    TVEngine.Navigation.addMenu(menu);
})(TVEngine);