(function(TVEngine, window, undefined) {
    var menu = new TVEngine.Navigation.Menu("gaiam:mainmenu");

    menu.setTargets({
        featured: "#main-bottom-featured-nav",
        categories: "#main-bottom-categories-nav",
        recent: "#main-bottom-recent-nav",
        playlist: "#main-bottom-myplaylist-nav",
        search: "#main-bottom-search-nav",
        logout: "#main-bottom-logout-nav",
    });

    menu.setFeaturedOnly = function(featuredOnly) {
        this.featuredOnly = featuredOnly;
    }
    menu.items["featured"] = {
        onRight: function() {
            //  $log(" FEATURED ON RIGHT ")
            if (!this.featuredOnly) menu.focus('categories');
        },
        onFocus: function() {
            $("#main-bottom-featured-nav").addClass("focused");
        },
        onBlur: function() {
            $("#main-bottom-featured-nav").removeClass("focused");
        },
        onMouseover: function() {

            menu.focus('featured');
        },
        onUp: function() {
            TVEngine.Navigation.menus['gaiam:featured'].focus();
        },
    }
    menu.items["categories"] = {
        onRight: function() {
            menu.focus('recent');
        },
        onLeft: function() {
            menu.focus("featured")
        },
        onFocus: function() {
            $log(" CATEGORIES ON FOCUS ")
            $("#main-bottom-categories-nav").addClass("focused");
             $('#main-bottom-featured-nav').removeClass('focused').removeClass('focusedblue');
        },
        onBlur: function() {
            $("#main-bottom-categories-nav").removeClass("focused");
        },
        onMouseover: function() {
            menu.focus('categories');
        },
        onUp: function() {
            TVEngine.Navigation.menus['gaiam:featured'].focus();
        },
    }
    menu.items["recent"] = {
        onRight: function() {
            menu.focus('playlist');
        },
        onLeft: function() {
            menu.focus("categories")
        },
        onFocus: function() {
            $("#main-bottom-recent-nav").addClass("focused");
               $('#main-bottom-featured-nav').removeClass('focused').removeClass('focusedblue');
        },
        onBlur: function() {
            $("#main-bottom-recent-nav").removeClass("focused");
        },
        onMouseover: function() {
            menu.focus('recent');
        },
        onUp: function() {
            TVEngine.Navigation.menus['gaiam:featured'].focus();
        },
    }

    menu.items["playlist"] = {
        onRight: function() {
            menu.focus('search');
        },
        onLeft: function() {
            menu.focus("recent")
        },
        onFocus: function() {
            $("#main-bottom-myplaylist-nav").addClass("focused");
               $('#main-bottom-featured-nav').removeClass('focused').removeClass('focusedblue');
        },
        onBlur: function() {
            $("#main-bottom-myplaylist-nav").removeClass("focused");
        },
        onMouseover: function() {
            menu.focus('playlist');
        },
        onUp: function() {
            TVEngine.Navigation.menus['gaiam:featured'].focus();
        },
    }
    menu.items["search"] = {
        onRight: function() {
            menu.focus('logout');
        },
        onLeft: function() {
            menu.focus("playlist")
        },
        onFocus: function() {
            $("#main-bottom-search-nav").addClass("focused");
               $('#main-bottom-featured-nav').removeClass('focused').removeClass('focusedblue');
        },
        onBlur: function() {
            $("#main-bottom-search-nav").removeClass("focused");
        },
        onMouseover: function() {
            menu.focus('search');
        },
        onUp: function() {
            TVEngine.Navigation.menus['gaiam:featured'].focus();
        },
    }
    menu.items["logout"] = {
        onLeft: function() {
            menu.focus("search")
        },
        onFocus: function() {
            $("#main-bottom-logout-nav").addClass("focused");
               $('#main-bottom-featured-nav').removeClass('focused').removeClass('focusedblue');
        },
        onBlur: function() {
            $("#main-bottom-logout-nav").removeClass("focused");
        },
        onMouseover: function() {
            menu.focus('logout');
        },
        onUp: function() {
            TVEngine.Navigation.menus['gaiam:featured'].focus();
        },
    }
    TVEngine.Navigation.addMenu(menu);
})(TVEngine, window);