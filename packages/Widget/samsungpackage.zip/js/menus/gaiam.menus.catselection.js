(function(TVEngine) {
  var menu = new TVEngine.Navigation.Menu("gaiam:catselection");
  menu.menuHandlesEvents();


  menu.step = null;

  menu.setTargets = function() {
    var _t = this;
    $("ul.boxart_page > li").off();
    $("ul.boxart_page > li").on('mouseover', function() {
      _t.currentIndex = $(this).index() + $(this).parent().siblings().length * 14;
      _t.focus();
      _t.setFocused();
    });
    $("ul.boxart_page > li").on('mouseout', function() {

    });
    $("ul.boxart_page > li").on('click', function() {});
  }
  menu.unsetHandlers = function() {
    $('.categoriesSelectList').off();
    $('.catSelectionUpArrowDiv').off();
    $('.catSelectionDownArrowDiv').off();
  }

  menu.setHandlers = function() {
    menu.unsetHandlers();
    $log('setting categories handlers')

    $('.categoriesSelectList').on('mouseover', 'li', function() {
      $log('moused over cateselection menu');

      var index = $(this).index();
      menu.setFocusByIndex(index);
      menu.setFocused();
    });


    $('.categoriesSelectList').on('mouseout', 'li', function() {
      $log('moused out cateselection menu');
    });

    $('.categoriesSelectList').on('click', 'li', function() {
      $log('GOT A CLICK!')
      menu.onSelect();
    });



  }
  //hover handlers
  LGHoverUpHandlerIn = function() {

    LGHoverUpInterval = setInterval(function() {


      $log('hover!')

      $('.catSelectionUpArrowDiv').addClass('focused');
      thisCurrentUpMarginTop = $('.categoriesSelectList').css('margin-top').replace(/[^-\d\.]/g, '');
      $log('thisCurrentMarginTop' + thisCurrentUpMarginTop);
      thisCurrentUpMarginTop = parseInt(thisCurrentUpMarginTop);
      var thisNewUpMarginTop = thisCurrentUpMarginTop + 1;
      $log('thisNewMarginTop' + thisNewUpMarginTop);

      var listHeight = $('.categoriesSelectList').height();
      var itemHeight = listHeight / $('.categoriesSelectList li').length;
      var topOfList = listHeight - (itemHeight * 4);
      if (thisNewUpMarginTop > topOfList) {
        thisNewUpMarginTop = topOfList;
        $('.catSelectionUpArrowDiv').hide();
        $('.catSelectionDownArrowDiv').show();
      }

      thisNewUpMarginTopString = thisNewUpMarginTop + 'px';

      $('.categoriesSelectList').css({
        'margin-top': thisNewUpMarginTopString
      })


    }, 10)
    return false;
  };

  LGHoverUpHandlerOut = function() {
    $log('OUTHANDLER')
    clearInterval(LGHoverUpInterval);
    $('.catSelectionUpArrowDiv').removeClass('focused');

  };



  $('.catSelectionUpArrowDiv').on('mousedown', function() {

    timeout = setInterval(function() {
      $log('mousedown!')

    }, 10)
    return false;
  });

  $('.catSelectionUpArrowDiv').on('mouseup', function() {

    clearInterval(timeout);
    return false;
  });



  //down arrow

  $('.catSelectionDownArrowDiv').on('mouseover', function() {
    $log('over down arrow')
    $(this).addClass('focused');
  });

  $('.catSelectionDownArrowDiv').on('mouseout', function() {
    $log('out down arrow')
    $(this).removeClass('focused');
  });

  $('.catSelectionDownArrowDiv').on('click', function() {
    $log('GOT A CLICK!')

  });


  //hover handlers
  LGHoverDownHandlerIn = function() {

    LGHoverDownInterval = setInterval(function() {
      $log('hover!')


      $('.catSelectionDownArrowDiv').addClass('focused');
      thisCurrentDownMarginTop = $('.categoriesSelectList').css('margin-top').replace(/[^-\d\.]/g, '');
      thisNewDownMarginTop = thisCurrentDownMarginTop - 1;
      var listHeight = $('.categoriesSelectList').height();
      var itemHeight = listHeight / $('.categoriesSelectList li').length;
      var bottomOfList = listHeight - (itemHeight * 2);
      if (thisNewDownMarginTop < -bottomOfList) {
        thisNewDownMarginTop = -bottomOfList;
        $('.catSelectionDownArrowDiv').hide();
        $('.catSelectionUpArrowDiv').show()
      }
      thisNewMarginDownTopString = thisNewDownMarginTop + 'px';
      $('.categoriesSelectList').css({
        'margin-top': thisNewMarginDownTopString
      })
    }, 10)
    return false;
  };

  LGHoverDownHandlerOut = function() {
    clearInterval(LGHoverDownInterval);
    $('.catSelectionDownArrowDiv').removeClass('focused');
    $log('this is: ', $(this))
    return false;
  };



  menu.reset = function(parent) {
    $log(" RESET PARENT ", parent);
    this.currentIndex = 0;
    parent = parent || ".catselector:eq(0)";
    this.parent = $(parent);
  }

  menu.setFocusByIndex = function(index) {
    this.currentIndex = index;
    var offset = 224 - (index * 57);
    // $(".categoriesSelectList:visible").css({ top: offset});
  }
  menu.onFocus = function() {
    this.currentIndex = _.isNumber(this.currentIndex) ? this.currentIndex : 0;
    this.maxIndex = $(".categoriesSelectList:visible > li").length - 1;
    this.setFocused();

    this.setHandlers();
    $log('this in onfocus is:',this)
    $('.catSelectionUpArrowDiv').hover(LGHoverUpHandlerIn, LGHoverUpHandlerOut);
    $('.catSelectionDownArrowDiv').hover(LGHoverDownHandlerIn, LGHoverDownHandlerOut);

  }

  menu.onBlur = function() {
    $(".categoriesSelectList:visible > li").removeClass('focused pre-focused');
  }

  menu.setFocused = function() {
    $log(" SET FOCUSED", $(this.parent), $(".categoriesSelectList:visible > li"))
    $(".categoriesSelectList:visible > li").removeClass('focused pre-focused');
    $(".categoriesSelectList:visible > li").eq(this.currentIndex).addClass('focused');
    $(".categoriesSelectList:visible > li").eq(this.currentIndex).prev().addClass('pre-focused');

   if (this.currentIndex == 0) $(".catselector:visible").find(".catSelectionUpArrow").hide();
    else $(".catselector:visible").find(".catSelectionUpArrow").show();
    if (this.currentIndex == this.maxIndex) $(".catselector:visible").find(".catSelectionDownArrow").hide();
    else $(".catselector:visible").find(".catSelectionDownArrow").show();
    

          if($(".categoriesSelectList").eq(1).children().length!==0 && $(".categoriesSelectList").eq(1).children().length<7){
      $log('less than 7 loop')
       $(".catSelectionUpArrow").hide();
      $(".catSelectionDownArrow").hide();
  }

    
    this.trigger('focused', this.currentIndex);
    
  }

  menu.onUp = function() {
    if(this.currentIndex==0){TVEngine.Navigation.menus['gaiam:backmenu'].focus()};
    if (this.currentIndex > 0) {
      // $(".categoriesSelectList:visible").css({
      //   top: "+=24"
      // });
if(this.currentIndex>6){
        $(".categoriesSelectList:visible").css({
        top: "+=48"
      });
}
      this.currentIndex--;
      this.setFocused();
    }
  }

  menu.onDown = function() {
    $log(" MENU ON DOWN ", this.currentIndex, this.maxIndex);
    if (this.currentIndex < this.maxIndex) {
      // $(".categoriesSelectList:visible").css({
      //   top: "-=24"
      // });
  if(this.currentIndex>5){
      $(".categoriesSelectList:visible").css({
         top: "-=48"
       });
  }
      this.currentIndex++;
      this.setFocused();
    }
  }

  menu.onSelect = function() {
    this.trigger("selected", this.currentIndex);
  }

  TVEngine.Navigation.addMenu(menu);
})(TVEngine);