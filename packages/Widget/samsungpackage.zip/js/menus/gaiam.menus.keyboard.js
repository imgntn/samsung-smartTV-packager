(function(TVEngine) {
	var menu = new TVEngine.Navigation.Menu();
	menu.menuHandlesEvents();

	menu.name = "gaiam:keyboard";
	menu.step = null;
	menu.maxX = 5;
	menu.maxY = 4;
	menu.reset = function() {

		menu.currentX = 0;
		menu.currentY = 0;
		menu.currentIndex = 0;
		$log('keyboard onFocus event at: ' + this.currentIndex);

	};

menu.unsetHandlers=function(){
	 $('#keyboardTable').off();
}
menu.setHandlers=function() {

 
  $('#keyboardTable').on('mouseover','td',function() {
  	$('#keyboardTable tbody tr td div').removeClass('keyboardFocused');
  	menu.focus();
//  	$log('this index is: ',$(this).index())
  	var thisX = $(this).index();
  	menu.currentX=thisX;
  	var thisY = $(this)[0].parentNode.rowIndex-1;
  	menu.currentY=thisY;
  		// $log('this rowindex is: ',$(this)[0].parentNode.rowIndex)

      if(thisX==3&&thisY==4){menu.currentIndex=27}
      	
      	else{
      		 menu.currentIndex = menu.xyToIndex(thisX,thisY);
      	}
  

   // $log('thisX: '+thisX );
   // $log('thisX: '+thisY );
   // $log('currentindex hover is:' +menu.currentIndex)
   menu.setFocused(menu.currentIndex);
  
  });
$('#keyboardTable').on('click','td',function() {

// $log('GOT A KEYBOARD CLICK')
// $log('menu currentx: '+menu.currentX )
// $log('menu currenty: '+menu.currentY )
// $log('menu currentindex: '+menu.currentIndex )
// $log('menu is: ', menu)
menu.trigger('onselect');
// $log('this is: ', this)
// $log('$this is: ',$(this))
});


   
  };

  // menu.reset=function(){
  // 	this.unsetHandlers();
  // }

	menu.onFocus = function() {
			this.setHandlers();
		this.setFocused(this.currentIndex);
	
	}


	menu.setFocused = function(currentIndex) {


		$('#keyboardContainer table tr td:eq(' + currentIndex + ') div').addClass('keyboardFocused');
		$log('keyboard focus x:' + this.currentX);
		$log('keyboard focus y:' + this.currentY);

		$log('currentIndex is: ' + this.currentIndex);


		TVEngine.DataStore.set('searchIndex', this.currentIndex);
		TVEngine.DataStore.set('currentSearchX', this.currentX);
		TVEngine.DataStore.set('currentSearchY', this.currentY);


	}


	menu.onLeft = function() {
		//this is a little ugly but since i dont know what the submit button is going to look like we're just going to use two table spaces
		if (this.currentIndex == 28) {
			// $('#submitButton').removeClass('focused');
			// this.currentIndex
		} else if (this.currentIndex == 26) {
			$('#keyboardContainer table tr td:eq(' + this.currentIndex + ') div').removeClass('keyboardFocused');
			this.currentX = 1;
			this.currentIndex = 25;
			this.setFocused(this.currentIndex);

			$log('keyboard left');
		} else if (this.currentX > 0) {
			$('#keyboardContainer table tr td:eq(' + this.currentIndex + ') div').removeClass('keyboardFocused');
			this.currentX--;
			this.currentIndex--;
			this.setFocused(this.currentIndex);

			$log('keyboard left');
		}
	}


	menu.onRight = function() {
		if (this.currentIndex == 28 || this.currentIndex == 27 || this.currentX !== 0 && this.currentX % 5 == 0) {
			if(recentSearchesObject.searches[0]!='Please login to view recent searches.'){
					$('#keyboardContainer table tr td:eq(' + this.currentIndex + ') div').removeClass('keyboardFocused');
			this.currentX = this.maxX;
			this.trigger('rightFromRight');
			}
		
		} else {
			if (this.currentX < this.maxX) {
				$('#keyboardContainer table tr td:eq(' + this.currentIndex + ') div').removeClass('keyboardFocused');
				this.currentX++;
				this.currentIndex++;
				this.setFocused(this.currentIndex);
			}


			$log('keyboard right');
		}


	}

	menu.onUp = function() {


		if (this.currentIndex == 28) {

			lastSearchIndex = TVEngine.DataStore.get('lastSearchIndex');
			$('#submitButton').removeClass('focused');
			this.currentIndex = lastSearchIndex;
			this.setFocused(lastSearchIndex);
		} else if (this.currentIndex == 27) {

			$('#keyboardContainer table tr td:eq(' + this.currentIndex + ') div').removeClass('keyboardFocused');

			lastSearchIndex = TVEngine.DataStore.get('lastSearchIndex');
			if (lastSearchIndex != 22 && lastSearchIndex != 23) {
				lastSearchIndex = 22
			}
			if (lastSearchIndex == 22) {
				this.currentX = 4
			}
			if (lastSearchIndex == 23) {
				this.currentX = 5
			}
			this.currentY--;
			this.currentIndex = lastSearchIndex;
			this.setFocused(lastSearchIndex);
		} else if (this.currentY > 0 && this.currentIndex != 28) {
			$('#keyboardContainer table tr td:eq(' + this.currentIndex + ') div').removeClass('keyboardFocused');
			this.currentY--;
			this.currentIndex = this.xyToIndex(this.currentX, this.currentY);
			this.setFocused(this.currentIndex);
		}

		$log('keyboard up');
	}

	menu.onDown = function() {


		if (this.currentIndex == 24 || this.currentIndex == 25 || this.currentIndex == 26 || this.currentIndex == 27) {

			$('#keyboardContainer table tr td:eq(' + this.currentIndex + ') div').removeClass('keyboardFocused');
			$('#submitButton').addClass('focused');
			TVEngine.DataStore.set('lastSearchIndex', this.currentIndex);
			this.currentIndex = 28;
			this.setFocused(this.currentIndex);
			$log('CURRENTINDEX IS: ' + this.currentIndex)
		} else if (this.currentY < this.maxY) {
			$('#keyboardContainer table tr td:eq(' + this.currentIndex + ') div').removeClass('keyboardFocused');
			this.currentY++;
			if (this.currentIndex == 20 || this.currentIndex == 21) {
				TVEngine.DataStore.set('lastSearchIndex', this.currentIndex);
				this.currentIndex = 26;
				this.currentX = 2;
				this.currentY = 4;
				$log('U V DOWN')
			} else if (this.currentIndex == 22 || this.currentIndex == 23) {
				TVEngine.DataStore.set('lastSearchIndex', this.currentIndex);
				this.currentIndex = 27;
				this.currentX = 3;
				this.currentY = 4;
				$log('W XDOWN')
			} else {
				TVEngine.DataStore.set('lastSearchIndex', this.currentIndex);
				this.currentIndex = this.xyToIndex(this.currentX, this.currentY);


			}


			this.setFocused(this.currentIndex);

		}


		$log('keyboard down');
	}

	menu.onSelect = function() {
// 		$log('this is: ', this)
// $log('$this is: ',$(this))
// 		this.trigger("selected", this.currentX, this.currentY);
// 		$log('keyboard selected');
	},

	menu.onBlur = function() {
		this.unsetHandlers();
	
		$log('keyboard blur');
		$('#keyboardContainer table tr td:eq(' + this.currentIndex + ') div').removeClass('keyboardFocused');
	},

	menu.xyToIndex = function(x, y) {
		if (y == 0) {
			currentIndex = x
		} else if (y == 1) {
			currentIndex = x + 6
		} else if (y == 2) {
			currentIndex = x + 12
		} else if (y == 3) {
			currentIndex = x + 18
		} else if (y == 4 && (x == 3)) {
			currentIndex = 26;
		} else if (y == 4 && (x >= 4 && x <= 5)) {
			currentIndex = 27
		} else if (y == 4) {
			currentIndex = x + 24
		} else if (y == 5 && (x >= 0 && x <= 3)) {
			currentIndex = 28
		}


		return currentIndex;

	}

	menu.defaultMenu = true;
	TVEngine.Navigation.addMenu(menu);
})(TVEngine);