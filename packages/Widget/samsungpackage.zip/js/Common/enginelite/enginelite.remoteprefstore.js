(function(TVEngine, Parse, undefined) {

    TVEngine.RemotePrefStore  = {
        name: "RemotePrefStore",
        _preferences: null,
        _preferencesObject: Parse.Object.extend("RemotePrefStore"),
    },
    TVEngine.RemotePrefStore.init = function() {
        if(!TVAppConfig || !TVAppConfig.parseAppId || !TVAppConfig.parseJSId || TVEngine.getPlatform().name=='panasonic') {
            $error("CANT DO REMOTE RemotePrefStore WITHOUT PARSE CREDENTIAL SET IN TVAppConfig");
            this.trigger("loadeduser");
            return;
        }
        Parse.initialize(TVAppConfig.parseAppId, TVAppConfig.parseJSId);
        var platform = TVEngine.getPlatform();
        var query = new Parse.Query(this._preferencesObject);
        $log(" TRYING TO FIND USER WITH DEVICE ID :", platform.deviceId())
        query.equalTo("deviceid", platform.deviceId());
        var _t = this;
        query.find({
            success: function(users) {
                $log(" LOADED USER ")//,users);
                if(users.length) {
                    $log(" FOUND USER ")//, users[0]);
                    _t._preferences = users[0];
                    _(users.slice(1)).each(function(u) { u.destroy() });
                } else {
                    $log(" DIDNT FIND USER, CREATING ENW ")
                    _t._preferences = new _t._preferencesObject();
                    _t.set('deviceid',TVEngine.getPlatform().deviceId(),true);
                }
                _t.trigger("loadeduser");
            },
            error: function() {
                $log(" FAILED TO LOAD USER ");
                _t._preferences = new _t._preferencesObject();
                _t.set('deviceid',TVEngine.getPlatform().deviceId(),true);
                _t.trigger("loadeduser");
            }
        })
    },

    TVEngine.RemotePrefStore.get = function(key) {
        return (this._preferences) ? this._preferences.get(key): null
    }

    TVEngine.RemotePrefStore.set = function(key, value, savenow) {
        this._preferences.set(key, value);
        var out = {}; out[key] = value;
        this.trigger("newpreference", out);
        if(savenow) this.save();
    }

    TVEngine.RemotePrefStore.save = function() {
        _t = this;
        //$log("this._preferences = ", this._preferences);
        try{
             //undefinedfunction()
             $log('testing');
            }
        catch(e){
         //catch and just suppress error
        }

        this._preferences.save({
            success: function() {
                $log('saved worked');
                _t.trigger("saved")
            },
            error: function () {
                $log('save did not work');
                _t.trigger("savefailed")
            }
        })

    }

    _.extend(TVEngine.RemotePrefStore, Backbone.Events);

    TVEngine.addModule("RemotePrefStore", TVEngine.RemotePrefStore, {
        callbacks: ["loadeduser"],
    });
    $(window).on('unload', function() {
        $log(" UNLOAD TRUING TO SAVE !!! ")
        TVEngine.RemotePrefStore.save();
    });
})(TVEngine, Parse);