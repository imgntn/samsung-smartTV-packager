/**
 *
 *  Simple TV App Engine Platform Handling
 *
 *  author: A Different Engine LLC.
 *  http://adifferentengine.com
 *  contact@adifferentengine.com
 *
 */
TVEngine.Platforms = {

  // 4 Primary Platforms (for now) samsung, lg, googletv, browser
  platform: null,
  proxy: "",
  // Default
  supportedPlatforms: {},
  addSupportedPlatform: function(platform) {
    this.supportedPlatforms[platform.name] = platform;
    if (platform.defaultPlatform == true) {
      this.defaultPlatform = platform;
    }
  },

  platformName: function() {
    if (this.platform) return this.platform.name;
  },
  init: function() {
    $.each(['appCodeName','appName','appVersion','userAgent','platform'], function(index, item) {
      $log(" ___ NAVIGATOR."+item + ": " + navigator[item] + " ___");
    });
    _.each(this.supportedPlatforms, function(platform) {
      if (!platform.defaultPlatform && platform.detectPlatform()) {
        this.platform = platform;
        $log(" Found platform: " + platform.name);
        return;
      }
    }, this);
    if (!this.platform && !this.defaultPlatform) {
      $error("!!!! NO PLATFORM DETECTED, AND NO DEFAULT PLATFORM !!!!");
      return;
    } else if (!this.platform) {
      $log(" COULD NOT DETECT PLATFORM, USING DEFAULT (" + this.defaultPlatform.name + ")");
      this.platform = this.defaultPlatform;
    }
    var p = this.platform.name;
    $(function() {
      $("#debug").html("Platform: " + p);
    })

    $log("<< PLATFORM IS: (" + this.platform.name + ") >>")
    var _t = this;
    $(function() {
      // $log(" ON READY PLEASE! ")
      $("#help").text("PLATFORM IS: (" + _t.platform.name + ")");
    })
    this.platform.init();
    if($query("tvengine:screensize")) {
      this.platform.setResolution
    }
    this.platform.addPlatformCSS();
    this.platform.fetchMediaPlayer();

    // Going to add our proxy adding an ajax prefilter to switch to route the url
    // through a proxy for cross domain requests.
    var platform = this.platform;
    if (_.isFunction($.ajaxPrefilter)) {
      $log("Adding ajax Prefilter, proxy: ")
      $.ajaxPrefilter(function(options, originalOptions) {
        var proxy = platform.proxy();
        var data = originalOptions.data || {};
        // $log(" ORIGINAL OPTIONS ", originalOptions, options)
        if (!options.skipProxy && proxy !== "" && data.dataType !== "jsonp" && options.url.indexOf("http") == 0) {
          // Create the url
          options.data = $.param(data);
          options.url = proxy + "?url="+options.url+"&send_cookies=1";
          $log(" options: url " + options.url);
        }
      });
    }
    // Get rid of platform specific elements which we dont' need
    var _t = this;
    $(document).ready(function(){
      $log(" Removing Elements we dont' need for htis platform: " + _t.platform.name)
      $("*[data-platform]").not("[data-platform*='"+_t.platform.name+"']").remove();
      $log("5");
    });

  }
}

// Master "Class" for Platforms.
TVEngine.Platform = function(name) {
  this.name = name;
  this.defaultPlatform = false;
  this._mediaPlayer = "videotag";
  this.start = $noop;
  this.exit = $noop;
  this.logger = null, this._keys = {
    KEY_RETURN: 36,
    KEY_UP: 38,
    KEY_DOWN: 40,
    KEY_LEFT: 37,
    KEY_RIGHT: 39,
    KEY_ENTER: 13,
    KEY_RED: 65,
    KEY_GREEN: 66,
    KEY_YELLOW: 67,
    KEY_BLUE: 68,
    KEY_BACK: 8,
    KEY_PLAY: 80,
  };
  // this.resolution = {
  //   height: 540,
  //   width: 960
  // }
  	this.resolution = {
  		height: 720, width: 1280
  	};
  // You can override this if you'd like
  this.init = $noop;

  // Might want to set this to something different
  this.needsProxy = true;
  _.extend(this, Backbone.Events);

}
TVEngine.Platform.prototype.deviceId = function() {
  return "No Device ID Method set for "+ this.name;
}
TVEngine.Platform.prototype.deviceType = function() {
  return "No Device Type method set for " + this.name;
}

TVEngine.Platform.prototype.uid = function () {
  return (this.deviceType() + this.deviceId()).replace(" ","");
}

// override this if necessary
TVEngine.Platform.prototype.keys = function() {
  return this._keys;
}
TVEngine.Platform.prototype.setMediaPlayer = function(mediaplayer) {
  this._mediaPlayer = mediaplayer;
}
TVEngine.Platform.prototype.fetchMediaPlayer = function() {
  if (this._mediaPlayer) {
    //	$log("Adding media player path");
    var root = "js/Common/enginelite/mediaplayers/enginelite.mediaplayer." + this._mediaPlayer.toLowerCase() + ".js";
    if ($(document).find('script[src="' + root + '"]').length < 1) {
      var path = root + "?" + new Date().getTime();
      $log("Adding media player path: " + path);
      $("<script />", {
        src: path,
        type: 'text/javascript'
      }).appendTo("head");
    } else {
      $log(" Media Player Script is already loaded.")
    }
  }
}

TVEngine.Platform.prototype.cleanAppVersion = function() {
  var version = navigator.appVersion.match(/^[^\s]*/)[0] || null;
  if (version == null) return null;
  split = version.split(".")
  return {
    major: split[0],
    minor: split[1],
    mod: split[2]
  }
};

TVEngine.Platform.prototype.setResolution = function(width, height) {
  if(width.toString().indexOf("x") > 1) {
      splits = width.split("x");
      width = splits[0];
      height = splits[1];
  }
  this.resolution.height = height;
  this.resolution.width = width;
}
TVEngine.Platform.prototype.matrix = function() {
  return this.resolution.width + "x" + this.resolution.height;
}

TVEngine.Platform.prototype.addPlatformCSS = function() {
  // $log(" ADDING PLATFORM CSS FOR PLATFORM: " + this.name  + " path: css/platforms/"+this.name.toLowerCase()+".css and resolution: css/resolutions/"+this.matrix()+".css" );
  $("<link/>", {
    rel: "stylesheet",
    type: "text/css",
    href: "css/resolutions/" + this.matrix() + ".css"
  }).appendTo("head");
  $("<link/>", {
    rel: "stylesheet",
    type: "text/css",
    href: "css/platforms/" + this.name.toLowerCase() + ".css"
  }).appendTo("head");
}

// Override this
TVEngine.Platform.prototype.detectPlatform = function() {
  if (!this.defaultPlatform) $error(" <<< PLATFORM MUST OVERRIDE THE DETECT PLATFORM METHOD >>>");
}


TVEngine.Platform.prototype.proxy = function(url) {
  if(!url) return this.needsProxy ? "proxy.php" : "";
  if(this.needsProxy) {
    url = url || "";
    return "proxy.php?url="+url.trim()+"&send_cookies=1&send_session=1";
  } else {
    return url;
  }
}

TVEngine.Platform.prototype.setLogger = function(l) {
  this.logger = l
}

/* The first default platform "browser" */
;
(function() {
  var browser = new TVEngine.Platform('browser');
  browser.needsProxy = true;
  // We want this to fail, and get added as default
  browser.setResolution(1280, 720);
  // browser.setResolution(960,540);
  browser.defaultPlatform = true;
  TVEngine.Platforms.addSupportedPlatform(browser);

  browser.deviceId = function() {
    var saved_did = localStorage.getItem("ade.deviceid");
    if(!saved_did) {
      saved_did = this.__generateDeviceId();
      localStorage.setItem("ade.deviceid", saved_did);
    }
    return saved_did;
  }

  browser.deviceType = function() {
    return navigator.appCodeName + " - " + navigator.appName;
  }

  browser.__generateDeviceId  = function() {
    // Note no guarantee this is actually unique.
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
      return v.toString(16);
    });
  }
  browser.__clearDeviceId = function() {
    localStorage.removeItem("ade.deviceid");
  }

}());
