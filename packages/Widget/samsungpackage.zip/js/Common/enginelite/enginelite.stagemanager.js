;
(function(TVEngine, undefined) {
  TVEngine.StageManager = {
    _scenes: [],
    name: "Stage Manager",
    _setDefaultScene: null,
    _stateChangeParams: {
      newstate: null,
      params: {}
    },
    _changingScene: false,

    setDefaultScene: function(scene) {
      this._setDefaultScene = scene;
    },

    // Optional
    stateIs: function(name, scene) {
      if (scene == null) return (this.currentStateName() == name); // Optionally can validate against a scene.
      else return (this.sceneIs(scene) && this.currentStateName() == name)
    },
    sceneIs: function(name) {
      // $log(" SCENE IS CHECK, NAME: " + name, this.scene)
      return (this.scene && this.scene.name == name);
    },
    addScene: function(scene) {
      if (!scene.name ) {
        $error("Can't add a scene without a name ")
        return;
      }
      if (_.find(this._scenes, function(s) { s.name == scene.name })) {
        $error("Trying to add a scene with a name that has already been added, perhaps the name is not unique? ");
        return;
      }
      this._scenes.push(scene);
    },
    currentStateName: function() {
      return (this.scene && this.scene.currentState && this.scene.currentState.name) ? this.scene.currentState.name : null;
    },

    _defaultScene: function() {
      // $log(" Looing for default Scene: ", this._setDefaultScene, this._scenes)
      if (this._setDefaultScene) {
        var _t = this;
        var scene = _.find(this._scenes, function(s) {
          // $log("testing "+s.name+" to " + _t._setDefaultScene  )
          return (s.name == _t._setDefaultScene);
        });
        // $("SCENE: ", scene)
        if (scene) return scene;
      }

      var d = _.find(this._scenes, function(s) {
        return s.defaultScene
      });
      // $log(" Did we find a set default scene? ", d);
      if (d) return d;
      else if (this._scenes.length) {
        // $(" I Guess not lets find the first one, ", _.first(this._scenes))
        return _.first(this._scenes);
      }
    },

    start: function() {
      var _t = this, d;
      // $log("Stage Manager Init.")
      if (d = this._defaultScene()) {
        // $("Stage Manager loading default scene");
        this.changeScene(d.name);
      } else {
        // $("Stage Manager does not have a default scene. Done now.")
        this._initialized = true;
        this.trigger("scenemanager:loaded");
      }
    },

    setStateChangeParams: function(newstate, params) {
      params = params || {}
      this._stateChangeParams = {
        newstate: newstate,
        params: params
      }
      // $log(" SET STATE CHANGE PARAMS ", this._stateChangeParams)
    },

    changeScene: function(newscene, params) {
     $log(" NEW SCENE: ", newscene)
     var splits = newscene.match(/^(.[^:]*):?(.*)$/)
     newscene = splits[1];
     newstate = splits[2];
      // VALIDATE THE SCENE CHANGE
      if (this._changingScene) {
        $error(" Can't change scene in the middle of a scene change ");
        return;
      }

      // Just storing the name
      var sname = newscene;
      if (typeof newscene == "string") newscene = _.find(this._scenes, function(s) {
        return s.name == newscene
      });
      if (!newscene) return $error("Tried to load an invalid scene '" + sname + "'.");
      if(this.scene) this._last = { scene: this.scene.name, state: this.currentStateName}


      this.setStateChangeParams(newstate, params);

      this._changingScene = true; // Lock scene changes

      if (this.scene && this.scene.name == newscene) {
       // $log(" CHANGE SCENE WAS CALLED WITH THE SAME SCENE, SEEING IF THERE'S A NEW STATE ")
        if ( newstate &&  newstate != this.scene.currentState ) {
          this.scene.changeState(newstate);
          this._changingScene = false;
        }
        return;
      }




      // Clean up the old scene.
      if (this.scene && this.scene.currentState && _.isFunction(this.scene.currentState.onleavestate)) this.scene.currentState.onleavestate();
      this.scene && _.isFunction(this.scene.onleavescene) && this.scene.onleavescene();
      // $log(" TRIGGERING BEFORE SCENE CHANGE, NEWSCENE: ", newscene)
      this.scene = newscene;
      this.trigger("beforescenechange");

      if (newscene.dataItems || newscene.waterfalls) {
        // $("Found data for scene, loading that first.")
        TVEngine.DataLoader.reset();
        if (newscene.dataItems) {
          if (!(newscene.dataItems instanceof Array)) newscene.dataItems = [newscene.dataItems];
          // $(" DATA ITEMS, ", newscene.dataItems)
          _.each(newscene.dataItems, function(i) {
            // $(i)
            if (!(i instanceof TVEngine.DataLoader.Data)) {
              // $("Creating new data item", i);
              i = new TVEngine.DataLoader.Data({
                key: i.key, url: i.url, parser: i.parser
              })
            }
            TVEngine.DataLoader.addDataSets(i);
          })
        }
        if (newscene.waterfalls) {
          var _t = this;
          var waterfalls = newscene.waterfalls instanceof Array ? newscene.waterfalls : [newscene.waterfalls];
          _.each(newscene.waterfalls, function(key, sets) {
            TVEngine.DataLoader.addWaterfall(key, sets);
          })
        }

        TVEngine.DataLoader.on("dataloader:loaded", this.loadedDataForScene, this);
        TVEngine.DataLoader.load();
      } else {
        this.loadedDataForScene();
      }
    },
    failedToLoadSceneData: function() {

    },
    loadedDataForScene: function() {
      // Make sure to unbind here;
      //  $log(" Bootstrapped the data for the scene. ");
      TVEngine.DataLoader.off(null, null, this);
      if (this.scene.view) {
        this.loadViewForScene();
      } else {
        this._sceneChanged();
      }
    },
    loadViewForScene: function() {
      var _t = this;
      // $log(" LOAD VIEW FOR SCENE ")
      if (this.scene.view && $(this.scene.target).attr('data-currentscene') != this.scene.name ) {
        $(this.scene.target).load(this.scene.view, function() {
          $(this).attr('data-currentscene', _t.scene.name );
          $(this).find(".resizer").each(function(idx, img) {
            var src = $(this).attr('src');
            var newsrc = src.replace(/\/[0-9]+x[0-9]+\//, "/" + TVEngine.getPlatform().matrix() + "/")
            $(this).attr('src', newsrc);
          })
          _t._sceneChanged();
        })
      } else {
        // Should switch this to a defferred.
        this._sceneChanged();
      }
    },

    // Really kind of confusing but this is the end of the chain for a scene change.
    changeSceneToDefaultState: function() {
      this.scene.persist.params = this._stateChangeParams.params;
      _.isFunction(this.scene.onenterscene) && this.scene.onenterscene();
      this.scene.changeToDefaultState(this._stateChangeParams.newstate);
    },

    getScene: function(name) {
      return _.find(this._scenes, function(s) { return s.name == name });
    },

    _sceneChanged: function() {
     // $log(" END SCENE CHANGED ")

      if (!this._initialized) {
        // $logthis)
        this.trigger("loaded");
        this._initialzied = true;
      }
      this._changingScene = false; // Unlock for changes;
      TVEngine.Navigation.resetMenus();
      this.changeSceneToDefaultState();
      this.trigger("afterscenechange", this.scene);
    },
  }

  _.extend(TVEngine.StageManager, Backbone.Events);


  TVEngine.on("tvengine:appready", function() {
    TVEngine.StageManager.start();
  })

  TVEngine.addModule("StageManager", TVEngine.StageManager);

  TVEngine.StageHistory = {
    _stack: [], _trackingScene: null, _enabled: true, _currentSceneAndState: {},
    init: function() {
      // $log("<<< INIT STAGE HISTORY >>>");
      TVEngine.StageManager.off(null, null, this); // Ensure we never track twice
      TVEngine.StageManager.on("afterscenechange", this._changeCurrentScene, this);
      TVEngine.KeyHandler.off(null, null, this.back);
      TVEngine.KeyHandler.on("keyhandler:onReturn", this._checkOrBack, this);
      // $(window).on('popstate', function(p) {
      //   $log(" GOT POPSTATE: ", p);
      //   if(p.originalEvent && p.originalEvent.state) TVEngine.StageManager.changeScene(p.originalEvent.state.scene)
      // })
    },

    // _pushToHistory: function(scene) {
    //   window.history.pushState({scene: scene.name }, scene.name, "?scene="+scene.name);
    // },
    //
    add: function(current) {
     // $log(" HISTORY ADDING SCENE: " + current.scene + " STATE: " + current.state + " params: ", current.params);
      if(!current || _.isEmpty(current)) return;
      this._stack.unshift({ scene: current.scene, state: current.state, params: current.params || {} });
      TVEngine.KeyHandler.incrementStupidCounter();
    },


    back: function(params) {
      params = params || {};
     // $log(" CREATING PARAMS ")
      sceneParams =   TVEngine.StageManager.scene.backParams || {};
      _.extend(sceneParams, params);
      if(!this._enabled) return;
      // window.history.back();
      var changeTo = this._stack.shift();

      if(!changeTo && TVEngine.StageManager.scene.parentScene) {
        changeTo = {
          scene: TVEngine.StageManager.scene.parentScene,
        }
      }
      this._currentSceneAndState = {}// Don't store the current Stuff in history.
      if(!changeTo || _.isEmpty(changeTo)) {
        $log('calling exittomenu in stagemanager')
        $log('parent scene is:' + TVEngine.StageManager.scene.parentScene)
        TVEngine.exitToMenu();
        return;
      }
      _.extend(changeTo.params , sceneParams)
      TVEngine.StageManager.changeScene(changeTo.scene+":"+changeTo.state, changeTo.params);
    },
    _checkOrBack: function() {
      var currentScene = TVEngine.StageManager.scene;
     $log(" CHECK OR BACK !!! ", currentScene.backhandler);
      if(_.isFunction(currentScene.handlesback) ) {
        // Scene is handling back button, see if it still wants to change the scene.
        if( !currentScene.handlesback() ) {
          TVEngine.KeyHandler.incrementStupidCounter();
          return true;
        }
      }
      if(!TVEngine.StageManager._changingScene) {
        $log('calling back in checkorback')
        this.back();
      } else {
        TVEngine.KeyHandler.incrementStupidCounter();
      }
    },

    _changeCurrentScene: function() {
      var currentScene = TVEngine.StageManager.scene;
      // $log(" SCENE CHANGED: " + currentScene.name + " am I saving this? " + currentScene.saveState);
      if(this._trackingScene) this._trackingScene.off(null, null, this);
      if( !currentScene.saveState ) return;

      this._trackingScene = currentScene;
      if(!_.isEmpty(this._currentSceneAndState)) {
        this.add(this._currentSceneAndState);
      }
      this._trackingScene.on('statechange', this._stateChanged, this);
     // $log(" CURRENT SCENE ", _.extend({}, currentScene.persist), _.keys(currentScene.persist));
      this._currentSceneAndState = {
        scene:  currentScene.name,
        params: currentScene.persist.params || {},
        state: (currentScene.currentState) ? currentScene.currentState.name : null,
      }
      //$log(" TRACKING CURRENT SCENE AND STATE ", this._currentSceneAndState)
    },
    _stateChanged: function(newstate) {
      this._currentSceneAndState.state = (this._trackingScene.currentState) ? this._trackingScene.currentState.name : null;
    },
    enable: function() { this._enabled = true },
    disable: function() { this._enabled = false }
  }


  TVEngine.addModule("StageHistory", TVEngine.StageHistory);

  window.Scene = function(config) {
    this.currentState = null;
    this.saveState = true;
    this._states = {};
    this.onenterscene = $noop;
    this.onleavescene = $noop;
    this.transitions = {};
    _.extend(this, config || {});
    this.persist = {};
    _.extend(this, Backbone.Events);
    this._lastState = null;
    return this;
  }

  Scene.prototype.addState = function(state, def) {
    if (!state.name) {
      $error("Tried to add a state without a name. ");
      return;
    }
    var _t = this;
    this.s = this.s || {};
    this.s[state.name] = function() {
      _t.changeState(state.name);
    }
    state.scene = this;
    this._states[state.name] = state;
    if (def) this._defaultState = state.name;
  }

  Scene.prototype.getDefaultState = function() {
    $log(" GETTING DEFAULT STATE " + this._defaultState);
    if (this._defaultState) return this._defaultState;
    else if (!_.isEmpty(this._states)) return (_.first(_.keys(this._states)));
  }
  Scene.prototype.changeToDefaultState = function(newstate) {
    // $log(" Changing to default state newstate? " + newstate);
    if (newstate) this.changeState(newstate, true);
    else  {
      newstate = this.getDefaultState()
      if(newstate) this.changeState(newstate, true);
      else {
        $log(" Current scene seems to have no states, defined, so we're not switching to one.");
      }
    }
  }

  Scene.prototype.createState = function(name, def) {
    var s = new SceneState(name);
    this.addState(s, def);
    return s;
  }

  Scene.prototype.changeState = function(newstate, force) {
    // $log(" Changing State from: " + this.currentState + " to: " +newstate)
    TVEngine.Navigation.disable();
    if (!force && (!_.isNull(this.currentState) && this.currentState.name === newstate)) {
      TVEngine.Navigation.enable();
      return;
    }
    // We're allowing for variable types of arguments, menu is optional
    this.trigger('newstate', newstate);

    var state = this._states[newstate];
    if (this.currentState && _.isFunction(this.currentState.onleavestate)) this.currentState.onleavestate();
    if (state && _.isFunction(state.onbeforestate)) state.onbeforestate();

    // $("[data-scene~='" + this.name.toLowerCase() + "']").hide();
    var check = this.name.toLowerCase()+":"+newstate.toLowerCase();
    $("*[data-state]").not("[data-state~='"+check+"']").hide();
   // $log(" CHECKING FOR STATES NAMED: " + check);
    $("[data-state~='" + check + "']").show();



    if (this.currentState) {
      _.isFunction(this.currentState.onleavestate) && this.currentState.onleavestate();
      var oldstate = this.currentState.name, newstate = state.name;
    }
    this.currentState = state;
    TVEngine.Navigation.enable();
   //  $log(" ON ENTER STATE? ", this.currentState)
    if(oldstate) {

      var transitionMethod = "onleave." + oldstate.toLowerCase() + ".onenter." + newstate.toLowerCase();
//      $log(" LOOKING FOR TRANSITION METHOD " + transitionMethod, this.transitions);
      if(_.isFunction(this.transitions[transitionMethod]) ) {
        $log(" FOUND TRANSITION METHOD " + transitionMethod);
        this.transitions[transitionMethod]();
      }
    }
    if (this.currentState && _.isFunction(this.currentState.onenterstate)) this.currentState.onenterstate();
    this._lastState = newstate;
    this.trigger("statechange", newstate);

  }

  Scene.prototype.addTransitionMethod = function(oldstate, newstate, method) {
    var _t = this;
    this.transitions["onleave." + oldstate.toLowerCase() + ".onenter." + newstate.toLowerCase()] = function() {
      method.call(_t);
    }
  }

  window.SceneState = function(name) {
    this.name = name;
    this.onenterstate = $noop;
    this.onafterstate = $noop;
    this.scene = null;
  }

  SceneState.prototype.current = function () {
    if(this.scene) this.scene.changeState(this.name);
  }

})(TVEngine);
