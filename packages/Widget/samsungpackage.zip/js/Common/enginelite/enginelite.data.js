/**
 *
 *  Simple TV App Engine Data Loading
 *
 *  author: A Different Engine LLC.
 *  http://adifferentengine.com
 *  contact@adifferentengine.com
 *
 */

// Loads everything asynchronously, pretty simple ability to track
// incoming data.

window.DataLoader = function(config) {
  _.extend(this, _.defaults(config || {}, {
    _dataSets: {},
    _loaded: 0,
    _waterfalls: {},
  }))
}
DataLoader.prototype.addDataSets = function(sets) {
  sets = sets instanceof Array ? sets : [sets];
  var _t = this;
  _.each(sets, function(set) {
    if (!set.key) {
      $error("Tried to add data set without a key");
      return;
    }
    _t._dataSets[set.key] = set;
  })
}

DataLoader.prototype.addWaterfall = function(key, sets) {
  if (!key) throw ("Trying to add Waterfall with no key");
  this._waterfalls[key] = new TVEngine.DataLoader.Waterfall(key, sets);
}
DataLoader.prototype.load = function(sets) {
  // $log(" ___ DATA LOAD ___", this._dataSets, this._waterfalls);
  this._setsLoaded = [], this._wfLoaded = [];

  var _this = this;
  this.trigger("dataloader:loading");

  if (_.isEmpty(this._dataSets) && _.isEmpty(this._waterfalls)) {
    this.trigger("dataloader:loaded");
    return;
  }

  _.each(this._waterfalls, function(item, key) {
    // $log("Loading waterfall")
    item.bind("all", function() {
      this._loadedWf(key);
    }, _this);
    item.load();
  })
  _.each(this._dataSets, function(data, key) {
    // $log(" Fetching data from url: " + data.getUrl() + " data type: " + data.dataType)
    //$log(" FETCHING DATA SET, USE CACHED? " + data.useCached + "is empty? " + _.isEmpty(TVEngine.DataStore.get(data.key))); 
    if( !data.useCached || _.isEmpty(TVEngine.DataStore.get(data.key))) {
      $.ajax({
        url: data.getUrl(),
        dataType: data.dataType,
        data: data.getParams(),
        success: function(input) {
          // $log("<<< DATA LOADING SUCCESS >>>")
          if (typeof input == "string") input = $.parseJSON(input);
          TVEngine.DataStore.set(data.key, data.parser(input));
          _this.loadedItem();
        },
        error: function() {
          $error("!!! ERROR LOADING DATA ITEM " + data.key + "!!!");
          _this.loadedItem(key);
        }
      });

    } else {
      this.loadedItem();
    }
  });
}

DataLoader.prototype.loadedWf = function(item) {
  // $log(" Loaded Waterfall: " + item)
  this._wfLoaded.push(item);
  if (this._wfLoaded.length == _.keys(this._waterfalls).length && this._setsLoaded.length == _.keys(this._dataSets).length) {
    this._done();
  }
},
DataLoader.prototype.loadedItem = function(key) {
  // $log(" Loaded Item: " + key);
  this._setsLoaded.push(key);
  if (this._wfLoaded.length == _.keys(this._waterfalls).length && this._setsLoaded.length == _.keys(this._dataSets).length) {
    this._done();
  }
},
DataLoader.prototype._done =function() {
  this.trigger("dataloader:loaded");
}


TVEngine.DataLoader = {
  _dataSets: [],
  _loaded: 0,
  _waterfalls: [],
  name: "Data Loader",

  reset: function() {
    this._dataSets = [], this._loaded = 0, this._waterfalls = [];
    this.off(); // Unbind events.
  },
  init: function() {
    // $log("<<< DATA INIT >>>");
    if (this._dataSets.length || this._waterfalls.length) this.load();
    else this.trigger("dataloader:loaded");
  },
  addDataSets: function(sets) {
    sets = sets instanceof Array ? sets : [sets];
    var _t = this;
    _.each(sets, function(set) {
      if (!set.key) {
        $error("Tried to add data set without a key");
        return;
      }
      _t._dataSets.push(set);
    })
  },
  // Takes multiple data items and loads them one at at time passing the data,
  // from each call back into the next call.
  addWaterfall: function(key, sets) {
    if (!key) throw ("Trying to add Waterfall with no key");
    this._waterfalls.push(new TVEngine.DataLoader.Waterfall(key, sets));
  },

  load: function() {
    // $log(" ___ DATA LOAD ___", this._dataSets, this._waterfalls);
    this._loaded = this._dataSets.length + this._waterfalls.length;
    this._errors = [];
    var _this = this;
    this.trigger("dataloader:loading");

    if (this._dataSets.length == 0 && this._waterfalls.length == 0) {
      this.trigger("dataloader:loaded");
      return;
    }

    _.each(this._waterfalls, function(item) {
      // $log("Loading waterfall")
      item.bind("all", function() {
        this.loadedItem();
      }, _this);
      item.load();
    })
    _.each(this._dataSets, function(data) {
      // $log(" Fetching data from url: " + data.getUrl() + " data type: " + data.dataType)
      // $log(" FETCHING DATA SET, USE CACHED? " + data.useCached + "is empty? " + _.isEmpty(TVEngine.DataStore.get(data.key))); 
      if( !data.useCached || _.isEmpty(TVEngine.DataStore.get(data.key))) {
        $.ajax({
          url: data.getUrl(),
          dataType: data.dataType,
          data: data.getParams(),
          success: function(input) {
            // $log("<<< DATA LOADING SUCCESS >>>")
            try {
              if (typeof input == "string") input = $.parseJSON(input)
            } catch(e) {
              $error(" ERROR PARSING JSON " + e, input);
              _this.errors.push(e);
            }
            TVEngine.DataStore.set(data.key, data.parser(input));
            _this.loadedItem();
          },
          error: function() {
            $error("!!! ERROR LOADING DATA ITEM " + data.key + "!!!");
            _this.loadedItem();
          }
        });
      } else {
        _this.loadedItem();
      }
    });
  },

  loadedItem: function() {
    this._loaded--;
    // $log(" DATA LOADED ITEM: " + this._loaded)
    if (this._loaded == 0) {
      this.trigger("dataloader:loaded");
      this.reset();
    }
  },
  
}
TVEngine.DataStore = {
  _data: {},
  set: function(key, data) {
    this._data[key] = data;
    this.trigger("newdata:"+key, data);
    return this._data[key];
  },
  get: function(key) {
    return this._data[key]
  },

}
_.extend(TVEngine.DataStore, Backbone.Events);



_.extend(TVEngine.DataLoader, Backbone.Events);

TVEngine.addModule('DataLoader', TVEngine.DataLoader, {
  callbacks: ['dataloader:loaded']
});

TVEngine.DataLoader.Waterfall = function(key, items) {
  this.datastoreKey = key;
  this.dataItems = items;
  this.currentData = null;
  _.extend(this, Backbone.Events);
}

TVEngine.DataLoader.Waterfall.prototype.load = function() {
  this.currentIndex = 0;
  this.currentData = 0;
  this.loadNextItem();
}

TVEngine.DataLoader.Waterfall.prototype.loadNextItem = function() {
  var dataItem = this.dataItems[this.currentIndex];
  // if(!dataItem) return;
  var _this = this;
  dataItem.startdata = this.currentData;
  // $log("Trying to fetch url: " + dataItem.getUrl(), dataItem.getParams())
  $.ajax({
    url: dataItem.getUrl(),
    dataType: dataItem.dataType,
    data: dataItem.getParams(),
    cache: false,
    success: function(input) {
      if (typeof input == "string" && data.dataType.toUpperCase() == "JSON") input = $.parseJSON(input);
      _this.currentData = dataItem.parser(input);
      _this.next();
    },
    error: function() {
      // $log("Error fetching Waterfall data")
      _this.error();
    }
  });
}
TVEngine.DataLoader.Waterfall.prototype.next = function() {
  this.currentIndex++;
  if (this.currentIndex == this.dataItems.length) this.done();
  else this.loadNextItem();
}

TVEngine.DataLoader.Waterfall.prototype.done = function() {
  TVEngine.DataStore.set(this.datastoreKey, this.currentData);
  this.trigger("waterfall:done");
}
TVEngine.DataLoader.Waterfall.prototype.error = function() {
  $error("Failed to load with depdencies");
  this.trigger("waterfall:error");
}



TVEngine.DataLoader.Data = function(options) {
  options = _.defaults(options, {
    method: "GET",
    dataType: "JSON",
    key: null,
    parser: $noop,
    useCached: false,
  })
  _.extend(this, options);
}

// you can override this if you want to.
TVEngine.DataLoader.Data.prototype.getUrl = function() {
  return _.isFunction(this.url) ? this.url() : this.url;
}

// Can Override.
TVEngine.DataLoader.Data.prototype.getParams = function() {
  return _.isFunction(this.params) ? this.params() : this.params;
}
