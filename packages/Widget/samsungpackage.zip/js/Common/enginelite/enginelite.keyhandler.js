/**
 *
 *  Simple TV App Engine KeyHandler
 *
 *  author: A Different Engine LLC.
 *  http://adifferentengine.com
 *  contact@adifferentengine.com
 *
 */
// This is pretty straightforward.
TVEngine.KeyHandler = {

	keyActions:  {
		KEY_UP: 			'onUp',
		KEY_DOWN: 			'onDown',
		KEY_LEFT: 			'onLeft',
		KEY_RIGHT: 			'onRight',
		KEY_ENTER:			'onSelect',
		KEY_RETURN:			'onReturn',
		KEY_STOP:			'onStop',
		KEY_FF: 			'onFF',
		KEY_RW:				'onRW',//onRew
		KEY_PLAY:			'onPlay',
		KEY_PAUSE:			'onPause',
		KEY_YELLOW:			'onYellow',
		KEY_RED:			'onRed',
		KEY_BLUE:			'onBlue',
		KEY_GREEN:			'onGreen',
		KEY_EXIT:			'onExit',
		KEY_MENU: 			'onMenu',
		KEY_BACK: 			'onReturn',
		KEY_SKIPFFORWARD: 	'onSkipForward',
		KEY_SKIPBACK: 		'onSkipBack',
	},
	enabled: true,
	keyMap: {},

	init: function() {
		// Maps system key list to ours
		$KEYS = TVEngine.getPlatform().keys();
		// Transforming Samsung keymap into something we like slightly better.
		for(key in $KEYS) {
			this.keyMap[$KEYS[key]] = key;
		}
		this._initializeKeyHandler();
		this.trackHashChange();
		// $log(" INIT KEYHANDLER !")
		document.location.hash = "1";
	},
	_cleared: true,
	_initializeKeyHandler: function() {
		var _this = this; var clear;
		$(document).bind("keydown", function(event) {
			//$log("<<< GOT KEY event.keyCode: " + event.keyCode );
			if(event.keyCode == 457){	//lg reload hack
				document.location.reload(true)
			}
			var action = _this.keyActions[_this.keyMap[event.keyCode]];

			//  $('#keyLogger').text("<<< GOT KEY ACTION: "+action+" >>>");
			 // $('#keyLogger').text("<<< GOT KEY ACTION: "+event.keyCode+" >>>");

			//$log("<<< GOT KEY ACTION: "+action+">>>");

			if ( typeof action  != 'undefined' && _this.enabled ) {
			   if( action == 'onReturn') event.preventDefault();	//samsung tv's need for _checkOrBack
			   _this.trigger("keyhandler:"+action);
			   return true;
		   } else {
		     return true;
		   }
		});

		$(document).bind("keyup", function(event) {
			var action = _this.keyActions[_this.keyMap[event.keyCode]];
		//	 $('#keyLogger').text("<<< GOT KEY ACTION: "+action+" >>>");
		 // $('#keyLogger').text("<<< GOT KEY ACTION: "+event.keyCode+" >>>");
			if ( typeof action != "undefined" ) {
			   _this.trigger("keyhandler:"+action+"Up");
			   return false;
		   } else {
		     return true;
		   }
		})
	},

	incrementStupidCounter: function() {
	  return;
	  // $log(" INCREMENT STUPID COUNTER ")
	  var c =  parseInt(window.location.hash.substring(1));
	  // $log "HASH ! ", c)
	  var newNum = (_.isNaN(c) || !_.isNumber(c)) ? 1 : ++c;
	  // $log(" NEW HASH NUMBER! ", newNum);
	  this.stupidCounter = document.location.hash = newNum;
	},

	trackHashChange: function() {
	  var _this = this;
	  $(window).bind('hashchange', function(e) {
	    var newHash =  parseInt(window.location.hash.substring(1));
	    // $log(" NEW HASH ", newHash);
  	  if( ( !_.isNaN(newHash) && _.isNumber(newHash))  &&  newHash < _this.stupidCounter ) {
  	    // $log(" Hash Change Triggering on Return")
  	    _this.trigger("keyhandler:onReturn");
  	    return false;
  	  }
	  })
	},

	enable: function(){
		this.enabled = true;
	},
	disable: function() {
		this.enabled = false;
	}
};
TVEngine.bind("tvengine:starting", function() {
  TVEngine.KeyHandler.init();
})
// Now we can subscribe to the keyhandler from anywhere.

_.extend(TVEngine.KeyHandler, Backbone.Events);