window.VAST = {
  fetchVASTUrl: function( url ) {
    //url = "stubs/vastredirect.xml";
    var d = new $.Deferred();
    $log('about to call fetchRemoteVastUrl');
    this.fetchRemoteVastUrl(url, d);
    return d;
  },


  fetchRemoteVastUrl: function(url, deferred) {
    var _t = this;
    $.ajax({
      type: "GET", url: url, dataType: 'xml', data: { mode:"native" },
      success: function(data) { 
        //$log('fetchRemoteVastUrl success fired', data);
        //$log('data below');
        //$log(data);
        data = _t.parseResponse(data);
        if(data && data.vastUrl) {
          _t.fetchRemoteVastUrl(data.vastUrl, deferred);
        } else if( !data || !data.renditions.length) {
          deferred.reject();
        } else {
          deferred.resolve(data);
        }
      },
      error: function(a,b,c) {
        $log(" ERROR FETCHING VAST URL ", arguments);
        deferred.reject();
      },
      /*complete: function(data){
        $log("complete fired with data = ", data);
      }*/
    })
  },

  parseResponse: function(data) {
    if(_.isEmpty(data)) return null;
    var out = new VASTResponse();
    
    /*try {
      $log("trying to parse xml: ", data);
      $log('data.lenght = ', data.length);
      data = $.parseXML(data.trim());
    } catch(e) {
      $log(" DATA FAILED TO PARSE XML" + e);
      return out;
    }*/

    var vasttag = $(data).find("VASTAdTagURI");
    if(vasttag.length) {
      // $log(" FOUND VAST TAG ", $(vasttag));
      return {vastUrl: $(vasttag).first().text().trim()};
    }
    $(data).find("MediaFile").each( function(idx, file) {
			if ($(file).attr("type") == "video/mp4") {
				out.renditions.push({
					bitrate: $(file).attr("bitrate"), url: $(file).text().trim(),
				});
			}
		});
		$(data).find("Tracking").each(function(idx, tracker) {
		  out.setTrackingEvent($(tracker).attr('event'), $(tracker).text());
		});
    return out;
  }
}
window.VASTResponse = function() {
  this.duration = null;
  this.trackingEvents = {};
  this.renditions = [];
  this.eventsSent = [];
  this.timeEvents = {'start':0, 'firstQuartile': 0.25, 'midpoint': 0.5, 'thirdQuartile': .75};
}


VASTResponse.prototype.trackTimeEvent = function( current, duration ) {
  var percent = current/duration;
  var _t = this;
  if(!_(this.eventsSent).include('start')) this.trackEvent('start');
  _.each(this.timeEvents, function(val, key) {
    if(percent > val && !_.include(_t.eventsSent, key )) {
      _t.trackEvent(key);
    }
  })
}

VASTResponse.prototype.trackEvent = function(key) {
  //$log("\n\n TRYING TO TRACK EVENT " + key + " \n\n");
  this.eventsSent.push(key);
  if(this.trackingEvents[key]) {
    _(this.trackingEvents[key]).each(function(tag) {
       //$log('we are trying to append an image tag to the document');
       $('body').append($("<img />").attr('src', tag).css('display','none'));
    });
  } else {
    //$log(" We Are Not Tracking Event: " + key);
  }
},
VASTResponse.prototype.resetEvents = function() {
    this.eventsSent = [];
}
VASTResponse.prototype.getRenditions = function() {
  return this.renditions;
}
VASTResponse.prototype.setTrackingEvent = function(event, url) {
  $log('setTrackingEvent called with event = ', event, url);
  this.trackingEvents[event] = _.isArray(this.trackingEvents[event]) ? this.trackingEvents[event] : [];
  this.trackingEvents[event].push(url);
}
VASTResponse.prototype.addMediaFile = function(bitrate, url) {
  $log('addMediaFile called');
  this.renditions.push({bitrate: bitrate, url: url});
}

VASTResponse.prototype.getRenditionForBitrate = function(bitrate) {
  bitrate = bitrate || 10000;
	if(this.renditions.length < 1) {
	  // $log(" NO RENDITIONS FOR URL ");
	  return null;
  }
	var file = null;
	_.each(this.renditions, function(rendition) {
		if( file === null || (rendition.bitrate > file.bitrate && rendition.bitrate < bitrate) ) {
			file = rendition;
		}
	});
  // $log(" FOUND RENDITION FOR BITRATE " + file);
	// return {url:"https://s3.amazonaws.com/public.domain.video/vids/OldSpice.DidYouKnow.h264.1100.mp4"};
	return file;
}