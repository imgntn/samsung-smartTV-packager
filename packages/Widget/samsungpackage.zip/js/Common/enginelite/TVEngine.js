/*global $error, $log, TVEngine, console, $, _, Handlebars, Backbone, TVAppConfig, location, io*/

/**
 *
 *  Simple TV App Engine.
 *
 *  author: A Different Engine LLC.
 *  http://adifferentengine.com
 *  contact@adifferentengine.com
 *
 */


window.onerror = function(message, url, linenumber) {
    $error("JavaScript error: " + message + " on line " + linenumber + " for " + url);
};

TVEngine = {
	modules: {},
	_doneEvents: [],
	_modulesToLoad: 0,
	_defConfig: {},

    defineModule: function(name, fn){
        var module, conf, results, _log, _error, _include, _include_was_called, prefix;

        prefix = "["+name+"]";
        module = {};

        _log = logging_interceptor($log);
        _error = logging_interceptor($error);
        _include = function(other){
            _include_was_called = true;
            _.extend(module, other);
        };
        
        
        conf = fn(_log, _error, _include);

        if(!_include_was_called){
            $error("error defining module: " + name + ", nothing was included.");
            return;
        }

        TVEngine.addModule(name, module, conf);

        return module;

        function logging_interceptor(logger){
            return function(){
                var args, style;
                style = module._logStyle;
                if(style === 'disabled'){
                    return;
                } else {
                    args = _.toArray(arguments);
                    if(style === 'prefix'){
                        args.unshift(prefix);
                    };

                    logger.apply(null, args);
                    
                }
            }
        }
        
    },
    enableLoggingForModule: function(name, /*optional:*/ style){

        var module = this.modules[name];
        style = style || true;
        
        if(module){
            module._logStyle = style;
        }
    },
    disableLoggingForModule: function(name){

        var module = this.modules[name];
        if(module){
            module._logStyle = "disabled";
        }
    },
	addModule: function(name, module, conf) {
            if(!module.name) module.name = name;
            
		this.modules[name] = module;
		conf = _.defaults(conf || {}, {
			callbacks: []
		});
		conf.callbacks = _.isArray(conf.callbacks) ? conf.callbacks : [conf.callbacks];

		this._doneEvents = _.union(this._doneEvents, conf.callbacks);
		_.each(conf.callbacks, function(callback) {
			module.bind(callback, function() {
				this.itemLoaded(callback);
			}, this);
		}, this);
	},

	moduleExists: function(name) {
		return(!_.isNull(this.modules[name]))
	},

	itemLoaded: function(callback) {
		// $log("<<< ITEM LOHCD ("+callback+")>>>");
		this._modulesToLoad = _.without(this._modulesToLoad, callback);
		if(this._modulesToLoad.length == 0) {
			// $log(" NOT WAITING FOR MORE MODULES, TRIGGERING READY ")
			if(this._modulesToInit == 0 && this._modulesToLoad.length == 0) {
				this.trigger("tvengine:appready");
			}
		}
	},

	start: function(config) {
		$log("<<< TV ENGINE START >>>");
		this.config = _.defaults(config || {}, this._defConfig);

		this.getPlatform().start();
                //$log(">> getPlatform().start()");
		this.trigger("tvengine:starting");
		this._modulesToLoad = this._doneEvents;
		this._modulesToInit = _.keys(this.modules).length;
		this._modulesIntialized = 0;
		_.each(this.modules, function(m) {
			//$log(" <<< INIT MODULE "+m.name+ ">>> ", m);
			if(_.isFunction(m.init)) m.init();
			this._modulesToInit--;
			//$log(" MODULES TO INIT: " + this._modulesToInit)
			if(this._modulesToInit == 0 && this._modulesToLoad.length == 0) {
                                //$log(" TRIGGERING APP READY");
				this.trigger("tvengine:appready");
			}
			//$log("<<< END INIT MODULE >>>");
		}, this);
		$log("<<< END TVEngine Start >>>");
		var _this = this;
		TVEngine.KeyHandler.on('keyhandler:onExit', function() {
			//$log(" KEY HANDLER ON EXIT ");
			this.exit();
		}, this);
	},

	exit: function() {
		$log("********************************\n       EXIT     \n ********************************");
		this.trigger('exit');
	},
	exitToMenu: function() {
		$log("********************************\n       EXIT TO MENU     \n ********************************");
		this.trigger('exittomenu');
	},

	getPlatform: function() {
		return TVEngine.Platforms.platform;
	},

	util: {
                _shouldUseRemoteLogging:false,
                setShouldUseRemoteLogging: function(yn){
                    var self = TVEngine.util;
                    if(yn !== self._shouldUseRemoteLogging){
                        if(yn){
                            self._shouldUseRemoteLogging = true;
                            self._replayLogs();
                        } else {
                            self._shouldUseRemoteLogging = false;
                        }
                    }
                },
                _replayLogs: function(){
                    var self, saved;
                    self = TVEngine.util;
                    saved = self._shouldRecordHistory;
                    
                    try {
                        self._shouldRecordHistory = false;
                        $log("Replaying Logs:");
                        if(self.log.history){
                            self.log.history.map(function(args){
                                $log.apply(window, args);
                            });
                        }

                    } finally {
                        self._shouldRecordHistory = saved;
                    }
                    
                },
                _shouldRecordHistory: true,
		error: function() {
                    var log_remote, args, self;

                    self = TVEngine.util;
                    log_remote = TVEngine.util._shouldUseRemoteLogging;
                    args = Array.prototype.slice.call(arguments);

                    if(self._shouldRecordHistory){
                        // store logs to an array for reference
                        TVEngine.util.log.history = TVEngine.util.log.history || [];
		        TVEngine.util.log.history.push(args);
                    }

                    if(log_remote){
                        
                        self._php_log({ message: (args.toString()), type:'error'});
                        
                    } else {
			if(typeof console != 'undefined' && _.isFunction(console.error)) {
			    if(arguments.length > 1) console.error(Array.prototype.slice.call(arguments));
			    else console.error(arguments[0])
			} else {
			    if(arguments.length > 1) alert(Array.prototype.slice.call(arguments));
			    else alert(arguments[0])
			}
			// TVEngine.trigger("tvengine:log",Array.prototype.slice.call(arguments));
		        
                    }
                },
		getStringWidth: function(elm,sizeinpx,font) {
			elm = $(elm);
			sizeinpx=sizeinpx;
			font="normal normal normal "+sizeinpx+"px/normal "+ font ||elm.css('font');
			var text = elm.text(),

				fontSize = Math.ceil(parseFloat(elm.css('font-size')));
			$log(" TESTING TEXT WITH FONT: " + font + " text: " + text);
			var testDiv = $("<div></div>", {
				style:  'font: ' + font + ';position: absolute, top: -1000; display:inline-block '
			}).text(text);
			$("body").append(testDiv);
			var out = Math.ceil(testDiv.outerWidth());
			testDiv.remove();
			return out;
		},
		debug: function (msg) {
			this.log(msg, 'debug')
		},

		log: function () {

                    var log_remote, args, self, platform;

                    platform = TVEngine.getPlatform();
                    
                    self = TVEngine.util;
                    log_remote = TVEngine.util._shouldUseRemoteLogging;
                    args = Array.prototype.slice.call(arguments);

                    if(self._shouldRecordHistory){
                        // store logs to an array for reference
	                TVEngine.util.log.history = TVEngine.util.log.history || [];
		        TVEngine.util.log.history.push(args);
                    }

                    if(log_remote){

                        self._php_log({message: args.toString(), type:'info'});
                        
                    } else {

                        //(TVEngine.getPlatform() && TVEngine.getPlatform().name != "Samsung2012" ) && 
			
            
			if(platform && !platform._disableAlerts && platform.name == "Samsung2012" ){
		    	if(arguments.length > 1) alert(Array.prototype.slice.call(arguments));
		    	else alert(arguments[0])
			}
			else if(typeof console != 'undefined' && _.isFunction(console.log)) {
			    if(arguments.length > 1) console.log(Array.prototype.slice.call(arguments));
			    else console.log(arguments[0])
			} else {
			    if(arguments.length > 1) alert(Array.prototype.slice.call(arguments));
			    else alert(arguments[0])
			}


                    }
		},
            _php_log:function(data){
                //forward logging statements to a php script in the
                //app root. messages are json objects in the format
                //{message:string type:string}
                // when type === 'error' message is logged as an error,
                // logged as info otherwise. ask jason for console_logger.php
                // if you don't know where to find it.
                
                data.message = Date.now() + ": " + data.message; 
                $.ajax({
                    url:'console_logger.php',
                    data: data,
                    type: 'GET',
                    dataType: 'json'
                });

            },

		getRGBFromHex: function (hex, alpha) {
    		var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);

    		if(!result) return null;

    		var out = {
        		r: parseInt(result[1], 16),
        		g: parseInt(result[2], 16),
        		b: parseInt(result[3], 16),
        		a: alpha,
        		toString: function() {
        			if(isNaN(alpha)) return "rgb("+this.r+", "+this.g+", "+this.b+")";
        			else return "rgba("+this.r+", "+this.g+", "+this.b+", "+this.a+")";
        		}
    		}
    		return out;
		},
		getImageForResolution: function(imgPath, conf) {
			conf = _.defaults(conf, {
				src: "images/" + TVEngine.Platforms.platform.matrix() + "/" + imgPath
			});
			// Kind of strange but its a consistent way to get the html of the element
			// that we want.
			document.write($('<div>').append($("<img />", conf).clone()).remove().html());
		},
		convertMstoHumanReadable: function(ms, leadingZeros) {
                        var days, hours, seconds, minutes;
			leadingZeros = typeof(leadingZeros) == 'undefined' ? true : !! leadingZeros // Make sure its boolean
			var x = ms / 1000
			var numSecs = seconds = Math.floor(x % 60)
			x /= 60
			var numMins = minutes = Math.floor(x % 60)
			x /= 60
			hours = Math.floor(x % 24)
			x /= 24
			days = Math.floor(x);

			var numMs = ms - (seconds * 1000);

			if(leadingZeros) {
				if(numSecs < 10) {
					numSecs = "0" + numSecs.toString();
				}
				if(numMins < 10) {
					numMins = "0" + numMins.toString();
				}
			}

			return {
				millis: numMs,
				seconds: numSecs,
				minutes: Math.floor(numMins),
				hours: Math.floor(hours),
				totalMS: ms,
				totalSeconds: ms / 1000,
				toString: function() {
					var str = numSecs;
					if(numSecs.toString().indexOf('-')>0)numSecs=0;		//bug
					if(Math.floor(numMins)) str = numMins + ":" + str;
					else str = "00:" + str;
					if(Math.floor(hours)) str = hours + ":" + str;
					return str;
				}
			}
		}
	}
}
_.extend(TVEngine, Backbone.Events);
window.$i = TVEngine.util.getImageForResolution;
window.$noop = function(input) {
	// if more then one return an array.
	if(arguments.length > 1) return Array.prototype.slice.call(arguments, 0);
	else return arguments[0]; // Don't return an array if only one thing came in.
}

if(typeof io != 'undefined') {
	var socket = io.connect("http://192.168.199.10:8010");
	window.$remote = function() {
		var args = Array.prototype.slice.call(arguments, 0);
		if(_.isFunction(TVEngine.util.log)) TVEngine.util.log.apply(TVEngine.util, args);
		socket.emit('log', args);
	}
}
window.$query = function(key) {
	key = key.replace(/[*+?^$.\[\]{}()|\\\/]/g, "\\$&"); // escape RegEx meta chars
	var match = location.search.match(new RegExp("[?&]" + key + "=([^&]+)(&|$)"));
	return match && decodeURIComponent(match[1].replace(/\+/g, " "));
}
window.$util = TVEngine.util;
window.$log = TVEngine.util.log;
window.$error = TVEngine.util.error;

if(typeof io != 'undefined') {
	var oldlog = $log,
		olderror = $error;
	var socket = io.connect('http://192.168.199.10:8010');
	window.$log = function(item) {
		try {
			socket.emit('log', Array.prototype.slice.call(arguments));
		} catch(e) {
			console.log(" GOT ERROR " + e)
		}
		oldlog.apply(TVEngine.util, Array.prototype.slice.call(arguments));
	}
	window.$error = function(item) {
		try {
			// socket.emit('error', arguments);
		} catch(e) {
			console.log(" GOT ERROR " + e)
		}
		olderror.apply(TVEngine.util, Array.prototype.slice.call(arguments));
	}
}


// Start her up, note that $(window).load
// will wait for all images to load before starting.
$(window).load(function() {
	// Turns on support for cross domain AJAX requests.
	$.support.cors = true;
	TVEngine.start(TVAppConfig);
	// $log("JQUERY VERSION: " + $().jquery);
});

// JQuery ajax likes to run in a try/catch style sceneario, lets capture these
$("<div />").ajaxError(function(e, aj, settings, exception) {
	$log(" ___ AJAX ERROR ___ ");
	//throw exception
	$error(exception);
	$error(settings)
	$log(" ___ END AJAX ERROR ___ ");
})
TVEngine.Tracker = {
	trackEvent: function(category, action, label, value) {
		if(TVEngine.Tracker.Google && _.isFunction(TVEngine.Tracker.Google.trackEvent)) {
			TVEngine.Tracker.Google.trackEvent(category, action, label, value);
		}
		if(TVEngine.Tracker.Omniture && _.isFunction(TVEngine.Tracker.Omniture.trackEvent)) {
			TVEngine.Tracker.Google.trackEvent(category, action, label, value);
		}
	}
}

// window.onerror = function(message, url, linenumber) {
//   $error(message + " at: " + url + ": "+ linenumber);
// }
/* Extensions to existing Javascript objects */
String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g, "");
}
String.prototype.normalize = function() {
	return this.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
}

String.prototype.ltrim = function() {
        var charlist = !arguments[0] ? ' \\s\u00A0' : (arguments[0] + '').replace(/([\[\]\(\)\.\?\/\*\{\}\+\$\^\:])/g, '$1');
	var re = new RegExp('^[' + charlist + ']+', 'g');
	return this.replace(re, '');
}
String.prototype.rtrim = function() {
	var charlist = !arguments[0] ? ' \\s\u00A0' : (arguments[0] + '').replace(/([\[\]\(\)\.\?\/\*\{\}\+\$\^\:])/g, '\\$1');
	var re = new RegExp('[' + charlist + ']+$', 'g');
	return this.replace(re, '');
}
String.prototype.capitalize = function() {
	return this.replace(/\S+/g, function(a) {
		return a.charAt(0).toUpperCase() + a.slice(1).toLowerCase();
	});
};
String.prototype.stripHTML = function() {
	return this.replace(/<(?:.|\n)*?>/gm, '');
}
String.prototype.toTitleCase = function() {
	return this.replace(/\w\S*/g, function(txt) {
		return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
	});
};
String.prototype.trunc = function(n, useWordBoundary) {
	var tooLong = this.length > n, s_ = tooLong ? this.substr(0, n - 1) : this;
	s_ = useWordBoundary && tooLong ? s_.substr(0, s_.lastIndexOf(' ')) : s_;
	return tooLong ? (s_ + '&hellip;').toString() : s_.toString();
};
Handlebars.registerHelper("debug", function(optionalValue) {
	console.log("Current Context");
	console.log("====================");
	console.log(this);

	if(optionalValue) {
		console.log("Value");
		console.log("====================");
		console.log(optionalValue);
	}
});