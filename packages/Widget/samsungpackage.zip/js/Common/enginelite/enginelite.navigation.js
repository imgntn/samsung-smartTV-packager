/*
	Main Navigation Object, it does a few things

	1. Registers for key events.
	2. Enables and Disables Navigation
	3. Manages Menus


	TODO: The History stack is an incomplete implementation.
*/
TVEngine.Navigation = {
	enabled: true,
	_eventsIHandle: ['onright', 'onleft','onup','ondown','onselect', 'onred', 'onblue', 'ongreen','onyellow', 'onback', 'onfastforward','onrewind', 'onpause', 'onplay'],

	enable: function(){
		this.enabled = true;
		if(!this.currentMenu || !this.currentFocus ) return;
		this.currentMenu.fireItem(this.currentFocus.item, 'onFocus');
	},
	disable: function() {
		this.enabled = false;
		if(!this.currentMenu || !this.currentFocus ) return;
		this.currentMenu.fireItem(this.currentFocus.item, 'onBlur');
	},

	start: function() {
		this.currentMenu.setFocused();
		this.enable();
	},

	// Register with the KeyHandler so we get key events.
	init: function() {
		// $log("<<< INITIALIZING NAVIGATION >>>");
		TVEngine.KeyHandler.bind('all', this.eventHandler, this);
		_.each(this.menus, function(m) {
		  if(_.isFunction(m.init)) m.init();
		})
	},



	menus: {}, currentFocus: null, currentMenu: null, defaultMenu: null,

	addMenu: function(menu) {
	  // $log(" Adding Menu " + menu.name);
		if(!menu.name) throw "Can't add a menu to the navigation without a name";
		this.menus[menu.name] = menu;
		if(menu.defaultMenu) this.defaultMenu = menu;
	},

	bindToMenu: function(menuname, event, callback, context) {
		var menu = this.menus[menuname];
		if(!menu) return;
		menu.on(menuname+":"+event, callback, context);
	},

	bindOnceToMenu: function(menuname, event, callback, context) {
	  var menu = this.menus[menuname];
	  if(!menu) {
	    // $log("Can't bind to a menu thats not registered.");
	    return
    }
	  menu.off( null, callback);
	  this.bindToMenu(menuname, event, callback, context);
	},
	bindAllTargets: function() {
	//$log(" BIND ALL TARGETS ")
	  _.each(this.menus, function(m) {
	    // $log(" BINDING ", m.name, m );
	    m._bindTargets();
	    if(_.isFunction(m.setHandlers)) m.setHandlers();
	  });
	},
	unbindAllTargets: function() {
	  // $log(" BINDING ALL TARGETS ", this.menus)
	  _.each(this.menus, function(m) {
	    // $log(" BINDING ", m.name, m );
	    m._unbindTargets();
	    if(_.isFunction(m.unsetHandlers)) m.unsetHandlers();
	  });
	},
	resetMenus: function() {
		$log(" RESET MENUS CALLED ")
	    _.each(this.menus, function(m) {
	      // $log(" BINDING ", m.name, m );
	      if(_.isFunction(m.reset)) m.reset();
	      m._lastItem = null;
	      m.off();
	    });
	    this.bindAllTargets();
	},
	getMenu: function(menuname) {
	  return this.menus[menuname];
	},

	// Send the key event to the current menu.
	eventHandler: function(event) {
	  	//$log( " NAV EVNET HANDLE " + event)
		var myevent = event.replace("keyhandler:", "");
		// instead of subscribing to each, we filter out the ones we dont' want.
		var ups = _.map(this._eventsIHandle, function(i) { return i + "up"});
		if (!_.include(this._eventsIHandle, myevent.toLowerCase()) && !_.include(ups, myevent.toLowerCase())) return;
		if (!this.currentMenu && this.defaultMenu ) {
			this.currentMenu = this.defaultMenu;
		}
		// $log(" Current Menu: ", this.currentMenu.name + " enabled: " + this.enabled)
		if(this.enabled && this.currentMenu ) {
		   // $log(this.currentMenu)
			this.currentMenu.fireItem(this.currentFocus.item, myevent);
		} else if(!this.currentMenu) {
			$error("<<< NO CURRENT MENU SET >>>");
		}
	},
	isFocused: function(item, menu ) {
	  if(menu) {
	    return (this.currentFocus.menu.name == menu && this.currentFocus.item == item)
	  } else {
	    return (this.currentFocus.item == item );
	  }
	},
	isMenuFocused: function(menu) {
	  return (this.currentFocus.menu.name == menu);
	},

	currentFocusedMenu: function() {
		return this.currentFocus.menu.name;
	},

	setFocus: function( menu,  item, options ) {
		var options = _.defaults(options || {}, {
		  storeInHistory: true,
		})
		// $log(" Setting Focus on " + menu +"/"+item, options);
		if(!this.menus[menu]) {
		  $error("<<< Tried to set menu to a non-existant menu: " + menu);
		  return;
		}
		var item = this.menus[menu].mainOnly() ? "main": (typeof item == "undefined" || _.isNull(item)) ? this.menus[menu].getDefaultItem() : item;


		// $log(" Setting focus to " + menu + " / " + item);
    // if(this.currentFocus && this.currentFocus.menu && this.currentFocus.menu.name == menu
    //     && this.currentFocus.item == item) return;
		// Note we don't add this until we leave it




		// First Blur the current stuff.
		// Menu *only* if menu changed.
		// $log(" DO WE HAVE A CURRENT FOCUS? " + this.currentFocus + " " + _.isNull(this.currentFocus), this.currentFocus);
		if( ! _.isNull(this.currentFocus) ) {
		  // $log(" BLUR?")
		  var currentMenu = this.menus[this.currentFocus.menu.name];
		  // $log(" Firing " + this.currentFocus.menu.name + "/" + this.currentFocus.item +".onBlur")
		  currentMenu.fireItem(this.currentFocus.item, 'onBlur');
		  if(this.currentFocus.storeInHistory)  {
		    // $log(" STORING ITEM IN HisTORY ", this.currentFocus)
		    this.History.addItem(this.currentFocus);
		  } else {
		    // $log("NOT ADDING TO HISTORY", options)
		  }
		}
		var newMenu = (!this.currentFocus || (this.currentFocus && this.currentFocus.menu && menu != this.currentFocus.menu.name));
		// $log(" NEW MENU? " + newMenu)

		if(newMenu && currentMenu && !currentMenu._main) {
			// $log(" Looks like menu changed, so blurring old menu ");
			currentMenu.fire("onBlur");
		}


		this.currentMenu = this.menus[menu];
		this.currentFocus = {menu: this.currentMenu, item: item, storeInHistory: options.storeInHistory};
		if( newMenu && !this.currentMenu._main )  {
			$log("New Menu calling menu focus")
			this.currentMenu.fire("onFocus");
		}

		this.currentMenu.fireItem(item, "onFocus");


	},
	currentMenuIs: function(name) {
	  return (this.currentMenu && _.include(name.split(" "), this.currentMenu.name));
	},
	back: function() {
		var last = this.History.last();
		// $log(" LAST ", last);
		if( last && !_.isEmpty(last) ) this.setFocus(last.menu, last.item);
	},

	History : {
		maxStackLength: 50, _stack: [],
		addItem: function(item) {
		  // $log(" ADDING ITEM TO STACK ", item)
		  if(!item) return;
			if( this._stack.length == this.maxStackLength ) this._stack.shift();
			this._stack.push({menu: item.menu.name, item: item.item });
		},
		// Note this changes the stack.
		last: function() {
			return this._stack.pop();
		},
		clear: function() {
			this._stack = [];
		}
	}
}

TVEngine.getMenu = TVEngine.Navigation.getMenu;

TVEngine.bind("tvengine:starting", function() {
  TVEngine.Navigation.init();
})
/*
 TVEngine Menu Item.
*/

TVEngine.Navigation.Menu = function(name) {
  this.name = name;
	this._focused = false;
	this.items = {};
	this._main = false;
	this._lastItem = null;
	this.defaultItem = null;
	this._targets = {};
	this.init = $noop;
	_.extend(this, Backbone.Events);
}

TVEngine.Navigation.Menu.prototype.setFocused = function() {
	if(!this._focused) {
		this.fire("onFocus");
		this._focused = true
	}
};

TVEngine.Navigation.Menu.prototype.nextDefault = function(item) {
	this._lastItem = null;
	this.defaultItem = item;
}

TVEngine.Navigation.Menu.prototype.focus = function(item) {
	TVEngine.Navigation.setFocus(this.name, item);
}
TVEngine.Navigation.Menu.prototype.setBlurred = function() {
	if(this.focused) {
		this.fire("onBlur"); this._focused = false;
	}
};

TVEngine.Navigation.Menu.prototype.mainOnly = function() {
	return this._main;
};

TVEngine.Navigation.Menu.prototype.menuHandlesEvents = function() {
	this._main = true;
	this.items['main'] = {};
};

TVEngine.Navigation.Menu.prototype.getDefaultItem = function() {
  if(this._lastItem ) return this._lastItem;
	return this.defaultItem || _.first(_.keys(this.items))
};


TVEngine.Navigation.Menu.prototype.fire = function(handler, params) {
  // $log(" Firing:" + handler)
	if(handler == 'onFocus') {
		this._focused = true;
		this.trigger("onfocus", this.name.toLowerCase() + ":" + handler.toLowerCase());
	} else if (handler == 'onBlur') {
	  	this._focused = false;
		this.trigger('onblur', this.name);
	}
	this.trigger(handler.toLowerCase(), this.name.toLowerCase() + ":" + handler.toLowerCase());
	if(_.isFunction(this[handler])) {
		this[handler]();
	}
};

TVEngine.Navigation.Menu.prototype._bindTargets = function() {
  var _t = this;
  this._unbindTargets();
  _.each(this._targets, function(htmlTarget, item) {
    // $log(" BINDING item "+item+" to ", $(htmlTarget))
    $(htmlTarget).on('mouseover', function() {
      if(!_t._main) _t.fireItem(item, 'onMouseover');
      else _t.fire("onMouseover", this);
    });
    $(htmlTarget).on('click', function() {
      // $log(" TARGET GOT CLICK!  ")
      if(!_t._main) _t.fireItem(item, 'onSelect');
      else _t.fire("onSelect", this);
    });
  });
};

TVEngine.Navigation.Menu.prototype._unbindTargets = function() {
  var _t = this;
  _.each(this._targets, function(htmlTarget, item ) {
    $(htmlTarget).off();
    // $(htmlTarget).off('mouseover click');
  })
};
TVEngine.Navigation.Menu.prototype.setTargets = function(targets) {
  _.extend(this._targets, targets);
  this._bindTargets();
};

TVEngine.Navigation.Menu.prototype.clearTargets = function() {
  this._targets = {};
}

TVEngine.Navigation.Menu.prototype.fireItem = function(item, handler, params) {
	this.trigger(item.toLowerCase() + ":" + handler.toLowerCase(), item.toLowerCase() + ":" + handler.toLowerCase());
	if(this._main) {
		this.fire(handler, params);
		return;
	}
	if(this.items[item] && handler == "onFocus") this._lastItem = item;
	if( this.items[item] && _.isFunction(this.items[item][handler])) {
		this.items[item][handler].call(this,params);
	}
};
/* Little dummy menu, can kind of be reused in places that don't need a ton of baggage (like capturing button presses
when hidden, or modals with one button ) just set the focus and then bind to its events.*/
;(function(TVEngine) {
	var menu = new TVEngine.Navigation.Menu("ade:dummymenu");
	menu.menuHandlesEvents();
	TVEngine.Navigation.addMenu(menu);
})(TVEngine);