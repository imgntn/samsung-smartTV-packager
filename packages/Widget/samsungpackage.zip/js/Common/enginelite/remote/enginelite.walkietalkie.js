TVEngine.WalkieTalkie = {
  
  socket: null, registered: null, devicetype: "Browser",
  
  links: {}, currentLink: null,
  
  setLinked: function(data) {
    $log(this.links);
    var name = this.getNewConnectionName();
    $log("Adding link: " + name + " as " + data);
    this.links[name] = data;
    localStorage.setItem("links", JSON.stringify(this.links));
    this.showLinkNameEditor(name);
    this.updateLinksList();
    this.switchLinked(name);
    $log(this.links)
  },
  
  switchLinked: function(name) {
    this.currentLink = name;
    localStorage.setItem("lastLinked", name);
    $log("Switched Linked to: " + name);
  },
  
  getNewConnectionName: function() {
    var name = "Conn";
    var names = _.keys(this.links);
    if(_.contains(names, name))  {
      connStart = "Conn ";
      count = 1;
      name = connStart+count;
      while(_.contains(names, name)) {
        count++;
        name = connStart+count;
      }
    } 
    return name;
  },
  renameLink: function(oldName, newName) {
    $log("renaming link from " + oldName + " to " + newName );
    if( oldName === newName ) return;
    if(!oldName || !newName || newName.length < 4) {
      console.error("Invalid New Name");
    } else {
      $log("Got New Name: " + newName)
      this.links[newName] = this.links[oldName];
      delete this.links[oldName];
      localStorage.setItem("links", JSON.stringify(this.links));
      this.updateLinksList();
      if(this.currentLink === oldName ) {
        this.switchLinked(newName);
      }
      $log(this.links)
   }
  },
  getLinkCode: function() {
    $log("WalkieTalkie sending request for link code")
    this.socket.emit("device:getlinkcode");
  },
  
  showLinkNameEditor: function(name) {
    $("#oldName, #newName").val(name);
    $("#linkName").animate({translateY:'150px'}, 500, 'ease-in-out');
    $("#linkNameForm input").focus();
  },
  
  link: function(code) {
    $log("Got Link code: " + code )
    if(code.length == 4) {
      $log("Trying to link with Code: " + code);
      this.socket.emit("device:link", code);
    }
  },
  updateLinksList: function() {
    $(".linkselect").empty();
    _.each(this.links, function(link, name) {
      $(".linkselect").append($("<li>"+name+"</li>"))
    });
  },
  
  clearLocalStorage: function() {
    localStorage.removeItem("links");
    localStorage.removeItem("deviceid");
    localStorage.removeItem("lastLinked");
    this.currentLink = null;
  },
  
  loadFromLocalStorage: function() {
    this.links = JSON.parse(localStorage.getItem("links")) || {};
    this.deviceid = localStorage.getItem("deviceid");
    this.currentLink = localStorage.getItem("lastLinked") || _.keys(this.links)[0];
  },
  savedMessages: [],
  
  sendMessage: function(type, data, destination) {
    destination = destination || this.links[this.currentLink];
    $log("Trying to send message: " + type  + ":" + data+" to : " + this.links[this.currentLink]);
    if(this.currentLink) {
      this.socket.emit("device:message", {
        token: destination, msg: {
          type: type, data: data
        }
      })
    } else {
      $log("No device linked?");
    }
  },
  
  
  setDeviceId: function(id) {
    $log("Setting device id: " + id);
    this.deviceid = id;
    localStorage.setItem("deviceid", id);
  },
  
  init: function() {
    var _t = this;
    this.loadFromLocal// $log);
    this.updateLinksList();

    // this.socket = io.connect('http://theknot.adifferentengine.com:8124');
    this.socket = io.connect('http://localhost:3000');
    this.socket.on("connect",  function(data) {
      $log("Connected " + _t.deviceid);
      if ( typeof _t.deviceid === 'undefined' || _t.deviceid === null ) {
        $log("Don't have a deviceid, Getting that first ");
        _t.socket.emit("fetch-uuid");
      } else {
        $log("Have a deviceid, "+_t.deviceid+" registering this device ");
        _t.socket.emit("device:register", { devicetype: _t.devicetype, deviceid: _t.deviceid });
      }
    });
  
    this.socket.on("device:register:error", function(data) {
      console.error("Failed to register device.", data);
    });
  
    this.socket.on("newuuid", function(data) {
      $log(" Got new UUID " + data + "now registering ");
      _t.clearLocal// $log);
      _t.setDeviceId(data);
      $log( { deviceid: _t.deviceid, devicetype: _t.devicetype })
      _t.socket.emit("device:register", { deviceid: _t.deviceid, devicetype: _t.devicetype });
    })

    this.socket.on("device:registered", function(data) {
      $log("device:registered");
      _t.registered = true;
      var _this = this;
      // if(TVEngine.util.log.history instanceof Array ) {
      //   _.each(TVEngine.util.log.history, function(log) {
      //     _this.emit("logger", log);
      //   })
      // }
      // 
      
      this.emit("logger", "PLAFTFORM NAME: " + TVEngine.Platforms.platformName());
      TVEngine.bind("tvengine:log", function(data) {
        _this.emit("logger", data);
      })
    });

    
    
    this.socket.on("control", function(data) {
      TVEngine.Keyhandler.trigger('keyhandler:'+data);
    });

    
    this.socket.on("device:linkcode", function(data) {
      $log("device:linkcode", data );
      _t.trigger("device:linkcode", false, data);
    });
    
    this.socket.on("device:linkcode:error", function(data) {
      _t.trigger("device:linkcode", data.msg, data);
    });
    
    this.socket.on("device:message", function(data) {
      console.log("message:", data.type +":" +data.message);
      _t.trigger(data.msg.type, { data: data.msg.data, responseToken: data.token } );
    })

    this.socket.on("device:link", function(data) {
      $log("Got a new device link: " + data);
      _t.setLinked(data);
    })
    this.socket.on("device:link:error", function(data) {
      navigator.notification.alert("Unable to create link, please try again")
    });
  }
}
_.extend(TVEngine.WalkieTalkie, Backbone.Events);
TVEngine.bind("tvengine:starting", function() {
  TVEngine.WalkieTalkie.init();
})
