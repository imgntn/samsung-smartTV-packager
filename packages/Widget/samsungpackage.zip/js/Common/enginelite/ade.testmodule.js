(function(TVEngine){
	$log("ade.testmodule.js ran");

	TVEngine.testmodule = {
		init: function() {
			var _t = this;
			setTimeout(function(){$log('delay load 8000');_t.trigger('loadedmodule')},8000);
		}
	}

	_.extend(TVEngine.testmodule, Backbone.Events);

	TVEngine.addModule("testmodule", TVEngine.testmodule, {
        callbacks: ["loadedmodule"],
    });
})(TVEngine)