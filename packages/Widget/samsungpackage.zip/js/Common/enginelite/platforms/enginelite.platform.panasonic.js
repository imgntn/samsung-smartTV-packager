(function() {
  var platform = new TVEngine.Platform('panasonic');
  platform.setResolution(1280,720);
  //platform.needsProxy = true;
  platform.detectPlatform = function() {
    if(navigator.userAgent.search(/Viera/) > -1) {
      //log("we have a viera");
    return true;

    } else {
      $(document).ready(function() {
       // $("#panasonicMedia").hide();
      })
    }
  }
  platform.needsProxy = true;
  platform.setMediaPlayer("videotag");
  platform.keys = function() {
    return {
      KEY_RETURN: 36,
      KEY_UP: 38,
      KEY_DOWN: 40,
      KEY_LEFT: 37,
      KEY_RIGHT: 39,
      KEY_ENTER: 13,
      KEY_RED: 65,
      KEY_GREEN: 66,
      KEY_YELLOW: 67,
      KEY_BLUE: 68,
      KEY_BACK: 8,
      KEY_PLAY: 80,
    }
  }

  
  platform.deviceId = function() {
     //var device =  document.getElementById("panasonic-device");
     //return device.serialNumber;
    return "aabbaacc";
  }

  platform.deviceType = function() {
    //var device =  document.getElementById("panasonic-device");
    //return device.manufacturer + "  - " + device.modelName;
    return "TV";
  }
  

  TVEngine.Platforms.addSupportedPlatform(platform);

}());