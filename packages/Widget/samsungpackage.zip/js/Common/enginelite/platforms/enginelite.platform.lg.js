(function() {
	var platform = new TVEngine.Platform('lg');
	platform.setResolution(1280,720);
	platform.detectPlatform = function() {
    if(navigator.userAgent.search(/LG Browser/) > -1) {
     return true;
    } else {
      $(document).ready(function() {
        $("#lgMedia").hide();
      })
    }
	}
	platform.needsProxy = true;
	platform.keys = function() {
	  return {
      KEY_RETURN: 36,
      KEY_UP: 38,
      KEY_DOWN: 40,
      KEY_LEFT: 37,
      KEY_RIGHT: 39,
      KEY_ENTER: 13,
      KEY_RED: 65,
      KEY_GREEN: 66,
      KEY_YELLOW: 67,
      KEY_BLUE: 68,
      KEY_BACK: 461,
      KEY_PLAY: 415,
      KEY_PAUSE: 19,
      KEY_FF: 417,
      KEY_RW: 412,
      KEY_STOP: 413,
    }
	}


  platform.deviceId = function() {
     //var device =  document.getElementById("lg-device");
     //return device.serialNumber;
     var device = document.getElementById('device');
     return device.serialNumber;
   }

  platform.deviceType = function() {
    var device =  document.getElementById("device");
    return device.manufacturer+ "  - " + device.modelName;
  }

  platform.uid = function() {

  }
	TVEngine.Platforms.addSupportedPlatform(platform);

}());