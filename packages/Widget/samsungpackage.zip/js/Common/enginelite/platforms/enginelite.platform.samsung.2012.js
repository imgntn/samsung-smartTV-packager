(function() {
	var platform = new TVEngine.Platform('Samsung2012');
	platform.setResolution(1280,720);
	platform.needsProxy = false;
	platform.detectPlatform = function() {
		if(navigator.appVersion.search(/Maple2012/) > -1) {
			return true;
		}

	}
	platform.keys = function() {
		return new Common.API.TVKeyValue();
	}
	platform.setMediaPlayer("samsungnative");

	platform.exitToTv = function(){
		$W.sendExitEvent();
		//$rlog(" CALLING SAMSUNG sendExitEvent EVENT ")
	};
	platform.exitToMenu = function(){
		$W.sendReturnEvent();
		//$rlog(" CALLING SAMSUNG sendReturnEvent EVENT ")
	};
	platform.init = function() {
         if(typeof(Common) != 'undefined' ) {
			window.$W = new Common.API.Widget();
		}
		TVEngine.bind("tvengine:appready", function(){
			$W.sendReadyEvent();
		});

		$(window).bind('unload', function() {
			try{
				var dims = { x: 0, y: 0, w: 960, h: 540 };
				var windowPlugin = document.getElementById("pluginWindow");
		    	windowPlugin.SetScreenRect(dims.x, dims.y, dims.w, dims.h);

			}catch(e){
				// $log(' ON UNLOAD RESET CALLED BUT ERRORED!');
			}
	     	TVEngine.MediaPlayer.stop();
		});
	}

	platform.start = function() {
		var _t = this;
		var showHandler = function(){
				try {
					var pluginAPI = new Common.API.Plugin();
					var tvKey = new Common.API.TVKeyValue();
		    		pluginAPI.unregistKey(tvKey.KEY_VOL_UP);
		    		pluginAPI.unregistKey(tvKey.KEY_VOL_DOWN);
					pluginAPI.unregistKey(tvKey.KEY_MUTE);
					pluginAPI.unregistKey(tvKey.KEY_INFOLINK);
					pluginAPI.unregistKey(tvKey.KEY_WLINK);
					pluginAPI.unregistKey(tvKey.KEY_CONTENT);
					pluginAPI.unregistKey(tvKey.KEY_MENU);
					pluginAPI.unregistKey(tvKey.KEY_SOURCE);

		          	document.getElementById('pluginObjectNNavi').SetBannerState(2);

		          	_t._modifyTVResolution = function() {
						var goodCoords = true;
						_.each(_t.tvCoordinates, function(v){ if(!_.isNumber(v)) goodCoords = false; })

						var arr= document.getElementById("pluginWindow").GetScreenRect().split("/");
						var hash = {x:parseInt(arr[0],10), y:parseInt(arr[1],10), width:parseInt(arr[2],10), height:parseInt(arr[3],10)};
						if(_.isEqual(hash, _t.tvCoordinates)) return;

						if(!goodCoords) {
							$rlog(" TRIED TO SET TV RESOLUTION TO BAD COORDINATES ", this.tvCoordinates);
							return;
						}
						try {
							var windowPlugin = document.getElementById("pluginWindow");
							windowPlugin.SetScreenRect(this.tvCoordinates.x, this.tvCoordinates.y, this.tvCoordinates.width, this.tvCoordinates.height);
						} catch(e) {
							$log(" ERROR SETTING SCREEN DIMENSIONS " + e);
						}
					}
		          	_t._modifyTVResolution();

		   		} catch(e) {
		   			$rlog(" ----- ERROR WITH ON SHOW HANDLER ----- " + e);
		   		}
			}
		window.onShow = showHandler;
	}

	TVEngine.Platforms.addSupportedPlatform(platform);
}());