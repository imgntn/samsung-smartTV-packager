(function() {
    var platform = new TVEngine.Platform('Samsung');
    platform.setResolution(1280, 720);
    platform.needsProxy = false;

    //setting this to true will disable alert logging on samsung
    platform._disableAlerts = false;     

    platform.detectPlatform = function() {
        if(navigator.appCodeName.search(/Maple/) > -1) {
            return true;
        } else if(navigator.appVersion.search(/Maple2012/) > -1) {
            this.name = "Samsung2012";
            return true;
        }
    }

    platform.keys = function() {
        return new Common.API.TVKeyValue();
    }
    platform.setMediaPlayer("samsungnative");
    platform.exitToTv = function() {
        $log(" CALLING SAMSUNG sendExitEvent EVENT ");
        this._exitCoordinates = this._defaultCoordinates;
        $W.sendExitEvent();
    };
    platform.exitToMenu = function() {
        $log(" CALLING SAMSUNG sendReturnEvent EVENT ")
        this._exitCoordinates = this._returnCoordinates;
        $W.sendReturnEvent();
    };
    platform.init = function() {
        TVEngine.on('exit', function() {
            this.exitToTv();
        }, this);
        TVEngine.on('exittomenu', function() {
            this.exitToMenu();
        },this);
        if(typeof(Common) != 'undefined') {
            window.$W = new Common.API.Widget();
        }
        TVEngine.bind("tvengine:appready", function() {
            $log('tvengine:appready caled');
            $W.sendReadyEvent();
        });


        $log('running legacy code to add localStorage');
        //Legacy code?
        if(typeof localStorage == "undefined" && typeof FileSystem == "function") {
            var fileSyObj = new FileSystem();
            var fileName = curWidget.id + "_localStorage.db";
            var lStorage = {};
            var changed = false;

            // load or init localStorage file
            var fileObj = fileSyObj.openCommonFile(fileName, "r+");
            if(fileObj != null) {
                try {
                    lStorage = JSON.parse(fileObj.readAll());
                } catch(e) {}
            } else {
                fileObj = fileSyObj.openCommonFile(fileName, "w")
                fileObj.writeAll("{}");
            }
            fileSyObj.closeCommonFile(fileObj);

            // Save storage
            lStorage.saveFile = function(delay) {
                if(changed && typeof JSON == 'object') {
                    var $self = this;
                    var save = function() {
                            fileObj = fileSyObj.openCommonFile(fileName, "w")
                            fileObj.writeAll(JSON.stringify($self));
                            fileSyObj.closeCommonFile(fileObj);
                            changed = false;
                        }
                    if(typeof delay != 'undefined' && delay) setTimeout(save, 100);
                    else save();
                }
            }

            lStorage.setItem = function(key, value) {
                changed = true;
                this[key] = value;
                this.saveFile(true);
                return this[key];
            }

            lStorage.getItem = function(key) {
                return this[key];
            }

            window.localStorage = lStorage;
            $log('finished loading localStorage');
            $log(_.keys(window.localStorage));
        }
    } //end init
    platform._defaultCoordinates = {
        x: 0,
        y: 0,
        width: 1280,
        height: 720
    }

    platform._returnCoordinates = {
        x: 0,
        y: 0,
        width: 1280,
        height: 720
    }
    
    platform._exitCoordinates = platform._returnCoordinates;
    
    platform.start = function() {
        var _t = this;
        var showHandler = function() {
                try {
                    var pluginAPI = new Common.API.Plugin();
                    var tvKey = new Common.API.TVKeyValue();
                    pluginAPI.unregistKey(tvKey.KEY_VOL_UP);
                    pluginAPI.unregistKey(tvKey.KEY_VOL_DOWN);
                    pluginAPI.unregistKey(tvKey.KEY_MUTE);
                    pluginAPI.unregistKey(tvKey.KEY_INFOLINK);
                    pluginAPI.unregistKey(tvKey.KEY_WLINK);
                    pluginAPI.unregistKey(tvKey.KEY_CONTENT);
                    pluginAPI.unregistKey(tvKey.KEY_MENU);
                    pluginAPI.unregistKey(tvKey.KEY_SOURCE);

                    document.getElementById('pluginObjectNNavi').SetBannerState(2);

                    _t._modifyTVResolution = function() {
                        var goodCoords = true;
                        _.each(_t.tvCoordinates, function(v) {
                            if(!_.isNumber(v)) goodCoords = false;
                        })

                        var arr = document.getElementById("pluginWindow").GetScreenRect().split("/");
                        var hash = {
                            x: parseInt(arr[0], 10),
                            y: parseInt(arr[1], 10),
                            width: parseInt(arr[2], 10),
                            height: parseInt(arr[3], 10)
                        };

                        _t._returnCoordinates = hash;

                        $(window).bind('unload', function() {
                            try {
                                windowPlugin.SetScreenRect(_t._exitCoordinates);
                                TVEngine.MediaPlayer.stop();
                            } catch(e) {
                                $log(' ON UNLOAD RESET CALLED BUT ERRORED!');
                            }
                        });

                        if(_.isEqual(hash, _t.tvCoordinates)) return;

                        if(!goodCoords) {
                            $rlog(" TRIED TO SET TV RESOLUTION TO BAD COORDINATES ", this.tvCoordinates);
                            return;
                        }
                        try {
                            var windowPlugin = document.getElementById("pluginWindow");
                            windowPlugin.SetScreenRect(this.tvCoordinates.x, this.tvCoordinates.y, this.tvCoordinates.width, this.tvCoordinates.height);
                        } catch(e) {
                            $log(" ERROR SETTING SCREEN DIMENSIONS " + e);
                        }
                    }
                    _t._modifyTVResolution();

                    // Done in start instead of init() b/c mediaplayer is not loaded until after init().
                    TVEngine.MediaPlayer.bind('mediaplayer:onplay', function() {
                        //$rlog('got an event mediaplayer:onplay');
                        pluginAPI.setOffScreenSaver();
                    });
                    TVEngine.MediaPlayer.bind('mediaplayer:onresume', function() {
                        //$rlog('got an event mediaplayer:onresume');
                        pluginAPI.setOffScreenSaver();
                    });
                    TVEngine.MediaPlayer.bind('mediaplayer:onpause', function() {
                        //$rlog('got an event mediaplayer:onpause');
                        pluginAPI.setOnScreenSaver();
                    });
                    TVEngine.MediaPlayer.bind('mediaplayer:onstop', function() {
                        //$rlog('got an event mediaplayer:onstop');
                        pluginAPI.setOnScreenSaver();
                    });
                    TVEngine.MediaPlayer.bind('mediaplayer:mediaend', function() {
                        //$rlog('got an event mediaplayer:mediaend');
                        pluginAPI.setOnScreenSaver();
                    });

                    var networkPlugin = document.getElementById('pluginObjectNetwork');
                    var internetConnectionInterval = 2000;

                    function checkConnection() {
                        var physicalConnection = 0,
                            httpStatus = 0;

                        // Get active connection type - wired or wireless.
                        currentInterface = networkPlugin.GetActiveType();

                        // If no active connection.
                        if(currentInterface === -1) {
                            return false;
                        }

                        // Check physical connection of current interface.
                        physicalConnection = networkPlugin.CheckPhysicalConnection(currentInterface);

                        // If not connected or error.
                        if(physicalConnection !== 1) {
                            return false;
                        }

                        // Check HTTP transport.
                        httpStatus = networkPlugin.CheckHTTP(currentInterface);

                        // If HTTP is not avaliable.
                        if(httpStatus !== 1) {
                            return false;
                        }

                        // Everything went OK.
                        return true;
                    }

                    function cyclicInternetConnectionCheck() {
                        if(!checkConnection()) {
                            // no internet connection
                            platform.trigger('network:disconnected');

                        } else {
                            // internet connection
                            platform.trigger('network:connected');
                        }
                    }

                    setInterval(function() {
                        cyclicInternetConnectionCheck()
                    }, internetConnectionInterval);


                    /*TVEngine.MediaPlayer.bind('mediaplayer:onplay mediaplayer:onresume',function(){
                        pluginAPI.setOffScreenSaver();
                        $rlog("TVEngine.MediaPlayer event playing video -> pluginAPI.setOffScreenSaver()")
                    });

                    TVEngine.MediaPlayer.bind('mediaplayer:onpause mediaplayer:onstop mediaplayer:mediaend',function(){
                        pluginAPI.setOnScreenSaver();
                        $rlog("TVEngine.MediaPlayer event playing video -> pluginAPI.setOnScreenSaver()")
                    });*/

                } catch(e) {
                    $rlog(" ----- ERROR WITH ON SHOW HANDLER ----- " + e);
                }
            }
        window.onShow = showHandler;
    } //end platform start

    platform.deviceId = function() {
              
        var MAC;
        var NetworkPlugin = document.getElementById('pluginObjectNetwork');
        var NNaviPlugin = document.getElementById('pluginObjectNNavi');
        MAC = NetworkPlugin.GetMAC(0);
        DUID = NNaviPlugin.GetDUID(MAC);
        return DUID;
    }
        
    platform.deviceType = function() {

        var productHash = {
            0: 'TV',
            1: 'MONITOR',
            2: 'DVD/BD'
        }
        var tvPlugin = document.getElementById('pluginObjectTV');
        var productType = tvPlugin.GetProductType();

        //$log('Device type: ' + tvPlugin.GetProductType());  
        var NNaviPlugin = document.getElementById('pluginObjectNNavi');
        var gm = NNaviPlugin.GetModelCode();

        return ("Manufacturer: Samsung / Model: " + gm + " / Device Type: " + productHash[productType]);

    }

    TVEngine.Platforms.addSupportedPlatform(platform);
}());