/*

VIDEO WRAPPER FOR CUSTOM LG OBJECT VIDEO PLAYER
Currently, this is tested for Surfline's HLS streams and the demo mp4 streams in video.json.
Seeking is available within the mp4 video, with limited accuracy.  
Fastforward and rewind ARE UNAVAILABLE (object.isScannable returns false)
There are 3 events thrown.  I was not able to see buffer events operate correctly.  Error events came up with connectivity issues.  Play events were consistent.

Most documentation is available within the document
lg_web_open_api_reference_guide_v.2.5.4.pdf

*/

LGNativeMediaPlayer = {
	_active: false, active: function() { this._active = true }, deactive: function() { this._active = false },
	_videoElement: null, allowFastFoward: true,
	init: function() {
		this._videoElement = $("#media")[0];
		if(!this._videoElement ) {
			var obj = this._createVideoTag();
			obj.hide();
			obj.trigger("videotagadded");
		}
		this._trackEvents();
		this.speedtest();
	},

	_createVideoTag: function() {
			// $log(" ___ CREATING VIDEO TAG ___ ")
			this.eventsBound = false;
			var obj = $("<object type='application/x-netcast-av' id='media'  autoStart='true' width='100%' height='100%'></object>");
			$("#wrapper").before(obj);
			this._videoElement = $("#media")[0];
			return obj;
	},


	
	play: function() {
		// $log("Playing Media");
		if(!this.playlist) {
			$error(" Can't press play on a mediaplayer without a playlist")
			return;
		}
		this.active();
		if( this._videoElement && !this._videoElement.paused &&  (typeof(this._videoElement.playbackRate) != 'undefined' && this._videoElement.playbackRate != 1) ) {
			// $log(" Restting Playback Rate")
			this._videoElement.speed(1);
		} else if(this._videoElement &&  this.currentStream == null ) {
			this._trackEvents();
			// $log(" Playing NExt File ");
			
			this.currentStream = this.playlist.nextFile();
			this._playVideo();
		} else if (this._videoElement ){
			if( this._videoElement.speed == 0 ) {
				// $log(" Calling Video Element Play")
				this._videoElement.play(1);
			} else {
				// $log(" Calling Video Element Pause ")
				this._videoElement.play(0);
			}
		}
	},
	_playVideo: function()	{
		// $log(" SETTING   STREAM TO: " + this.currentStream.url);
		$("#media").replaceWith("<object type='application/x-netcast-av' id='media' data='" + this.currentStream.url + "' autoStart='true' width='100%' height='100%'></object>");
		this._videoElement =  $("#media")[0];
		$(this._videoElement).show();
		this._trackEvents();
		this._videoElement.play(1);			
		this.wasMuted = this._videoElement.muted;
		
	},
	//IMP
	nextVideo: function() {
		this.currentStream = this.playlist.nextFile()
		if(this.currentStream) {
			this.trigger('onnextvideo', this.playlist.currentItemIndex());
			this._playVideo();
		} else {
			this.trigger("onplaylistend");
		}
	},
	//IMP
	stop: function(forced) {
		if(this._videoElement) {
			try {
				this.currentStream = null;
				this._videoElement.play(0);	
				if(!forced) this.trigger("onstop");
			} catch(e) {} // If this doesn't succeed, it doesn't matter, just die gracefully
			
		}
	},
	pause: function() {
		try {
			this._videoElement.play(0);	
			this.trigger("onpause");
		} catch(e) {
			// $log(" FAILED TO PAUSE VIDEO: " + e);
		}
	},
	fastforward: function() {
		/*NON FUNCTIONAL*/
	},
	rewind: function() {
		/*NON FUNCTIONAL*/
	},
	
	mute: function(muted) {
		/*NA*/
	},
	

	setCoordinates: function(x, y, width, height) {
		$(this._videoElement).css({
			left: x, top: y, width: width, height: height
		})
	},

	
	playing: function() {
		if(this._videoElement == null) return false;
		var test = (this._videoElement.playState != 1) ? false : true;
		return  test
	},
	
	duration: function() {
		if(_.isNaN(this._videoElement.mediaPlayInfo().duration)) {
			return null;
		} else {
			return Math.floor(this._videoElement.mediaPlayInfo().duration);
		}
	},
	
	setVideoElement: function(element) {
		this._videoElement = $(element);
	},
	//LG EVENTS
	wasMuted: false,
	handlePlayState: function() {
	  // $log(" HANDLE PLAY STATE: " +this._videoElement.playState );
		$("#currentUrl").empty().append(this._videoElement.playState);
		switch(this._videoElement.playState) {
			case 0:
				this.trigger("stop");
				break;
			case 1:
				this.trigger("play", this.playlist.currentItemIndex());
				break;
			case 2: //pause
				this.trigger("pause");
				break;
			case 3: //connecting
				break;
			case 4: //buffering
				this.trigger("bufferingstart");
				break;			
			case 5: //finished
				this.trigger("mediaend", this.playlist.currentItemIndex());
				$log(" MEDIA ENDED GOING TO NEXT VIDEO ")
				this.nextVideo();
				break;				
			case 6: //error
				$(this._videoElement).remove();
				this._createVideoTag();
				this.trigger("videoerror");	
				break;			
		}
	},
	handleBufferState: function() {
		//NEVER SAW THIS EVENT FIRE
	},
	handleErrorState: function() {
		$(this._videoElement).remove();
		this._createVideoTag();
		this._trackEvents();
		this.trigger("videoerror");
	},
	_trackEvents: function() {
		// $log("___ TRACK EVENTS CALLED ___ ");
		// if(this.eventsBound) return;
		var player = this;
		// $log(" ___ BINDING EVENTS ___ " + $("object").length);
		// $log($("object")[0]);
		this._videoElement.onPlayStateChange = this.handlePlayState;
		this._videoElement.onBuffering = this.handleBufferState;
		this._videoElement.onError = this.handleErrorState;
		this.eventsBound = true;	
	},
	_stopTrackingEvents: function() {
		// $log(" UNBINDING MEDIA EVENTS TO HTML5 VIDEO PLAYER ")
		this._videoElement.onPlayStateChange = null;
		this._videoElement.onBuffering = null;
		this._videoElement.onError = null;	
		this.eventsBound = false;
	},	
}
_.extend(TVEngine.MediaPlayer, TVEngine.LGNativeMediaPlayer);
TVEngine.addModule("MediaPlayer", TVEngine.MediaPlayer);