// Install a few things globally,
// ImageMagick (install binaries with homebrew)
// ImageMagick Node Module
// sudo npm install imagemagick -g
//
// Walk Node Module
// sudo npm install walk -g
var modules  = "/usr/local/lib/node_modules/"
var fs = require('fs')
    , path = require('path')
    , wrench = require(modules + 'wrench')
    , magick = require(modules + 'imagemagick');



var file1280 = path.normalize("./css/resolutions/1280x720.css");
var imageDirectory1280 = path.normalize("./images/1280x720")
var imageDirectory960 = path.normalize("./images/960x540");

/* Update CSS Files */
fs.readFile(file1280, 'utf8', function(err, data) {
    if(err) console.error(err) && process.exit(1);
    console.log(fs.realpathSync(file1280));

    var fixed = data.replace(/([0-9]+)px/ig, function(match, p1,offset,string) {
        var replacement = Math.round(parseInt(p1,10) * .75) + "px";
        return replacement;
    }).replace(/1280x720/g,"960x540");


    console.log("Creating 960x540 file: " + path.dirname(file1280)+"/960x540.css" );
    fs.writeFile(path.dirname(file1280)+"/960x540.css",fixed,function(err, data) {
        if(err) console.error(err) && process.exit(1);
        console.log("Successfully created file.")
    })
});

/* Create New Images */
wrench.readdirRecursive(imageDirectory1280, function(err, files) {
    if(!files || !files.length) return;
    files.forEach(function(file) {
        if(file.toLowerCase().match(/.*\.(jpeg|jpg|png)$/)) {
            var imagepath = path.normalize(imageDirectory1280 + "/" + file);
            var outdir = path.normalize(imageDirectory960 + "/" + path.dirname(file));
            // console.log(" Checking for and creating Out Dir " + outdir);
            if(! fs.existsSync(outdir)) wrench.mkdirSyncRecursive(outdir);
            var outpath = path.normalize(imageDirectory960 + "/" + file);
            // console.log(" Converting " + imagepath + " to " + outpath);
            if( fs.existsSync(imagepath) && !fs.existsSync(outpath)) {
                magick.convert([imagepath, '-resize', '75%', outpath], function(err, stdout) {
                    if(err) throw err;
                })
            } else {
               // console.log(" Output file already exists ");
            }
        }
    })
})




